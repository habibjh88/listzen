<?php
/**
 * @author        RadiusTheme
 * @package       classified-listing/templates/listing
 * @version       3.0.0
 *
 * @var Form $form
 * @var array $fields
 * @var int $listing_id
 */

use Rtcl\Helpers\Functions;
use Rtcl\Models\Form\Form;
use Rtcl\Services\FormBuilder\FBField;
use Rtcl\Services\FormBuilder\FBHelper;

if ( ! is_a( $form, Form::class ) ) {
	return;
}

$fields = $form->getFieldAsGroup( FBField::CUSTOM );
if ( count( $fields ) ) :
	$fields = FBHelper::reOrderCustomField( $fields );
	ob_start();
	foreach ( $fields as $index => $field ) {
		$field = new FBField( $field );
		if ( ! $field->isSingleViewAble() ) {
			continue;
		}
		$value = $field->getFormattedCustomFieldValue( $listing_id );

		if ( empty( $value ) ) {
			continue;
		}
		if ( 'repeater' === $field->getElement() ) {
			continue;
		}
		$icon = $field->getIconData();
		?>
		<div class="rtcl-cfp-item rtcl-cfp-<?php echo esc_attr( $field->getElement() ); ?>" data-name="<?php echo esc_attr( $field->getName() ); ?>"
			 data-uuid="<?php echo esc_attr( $field->getUuid() ); ?>">
			<?php
			if ( $field->getElement() === 'url' ) {
				$nofollow = ! empty( $field->getNofollow() ) ? ' rel="nofollow"' : '';
				?>
				<a href="<?php echo esc_url( $value ); ?>"
				   target="<?php echo esc_attr( $field->getTarget() ); ?>"<?php echo esc_html( $nofollow ); ?>><?php echo esc_html( $field->getLabel() ); ?></a>
				<?php
			} else {
				if ( ( ! empty( $icon['type'] ) && 'class' === $icon['type'] && ! empty( $icon['class'] ) ) || ! empty( $field->getLabel() ) ) {
					?>
					<div class="rtcl-cfp-label-wrap">
						<?php
						if ( ! empty( $field->getLabel() ) ) {
							?>
							<div class='cfp-label'><?php echo esc_html( $field->getLabel() ); ?><span class="colon">:</span></div>
							<?php
						}
						?>
					</div>
				<?php } ?>
				<div class="cfp-value">
					<?php Functions::print_html( FBHelper::getFormattedFieldHtml( $value, $field ) ); ?>
				</div>
			<?php } ?>
		</div>
		<?php
	}
	$fieldData = ob_get_clean();
	if ( $fieldData ) :
		Functions::print_html( $fieldData, true ); 
	endif;
endif;
