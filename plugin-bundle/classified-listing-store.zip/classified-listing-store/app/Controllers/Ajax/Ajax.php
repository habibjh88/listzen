<?php

namespace RtclStore\Controllers\Ajax;

use RtclStore\Models\MembershipPostingLog;

class Ajax {

	public static function init() {
		Admin::init();
		FrontEnd::init();
		Membership::init();
		ApiRequest::init();
		LoadMore::init();
		MembershipPostingLog::init();
	}

}