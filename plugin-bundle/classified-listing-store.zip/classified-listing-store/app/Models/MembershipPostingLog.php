<?php

namespace RtclStore\Models;

use WP_Query;

class MembershipPostingLog {
	protected static $table;

	/**
	 * Init table name
	 */
	public static function init() {
		global $wpdb;
		self::$table = $wpdb->prefix . 'rtcl_membership_posting_log';
	}

	/**
	 * Insert posting log
	 */
	public static function insert( $data ) {
		global $wpdb;

		$defaults = [
			'membership_id'  => 0,
			'action'         => 'submission', // submission | promotion
			'listing_id'     => 0,
			'promotion_type' => null,
			'cat_id'         => null,
			'created_at'     => current_time( 'mysql', true ),
			'updated_at'     => current_time( 'mysql', true ),
		];

		$data = wp_parse_args( $data, $defaults );

		return $wpdb->insert(
			self::$table,
			[
				'membership_id'  => (int) $data['membership_id'],
				'action'         => $data['action'],
				'listing_id'     => (int) $data['listing_id'],
				'promotion_type' => $data['promotion_type'],
				'cat_id'         => $data['cat_id'],
				'created_at'     => $data['created_at'],
				'updated_at'     => $data['updated_at'],
			],
			[
				'%d',
				'%s',
				'%d',
				'%s',
				'%d',
				'%s',
				'%s',
			],
		);
	}

	/**
	 * Get logs by membership
	 */
	public static function get_by_membership( $membership_id, $args = [] ) {
		global $wpdb;

		$defaults = [
			'action'         => null,
			'promotion_type' => null,
			'limit'          => 0,
			'offset'         => 0,
			'order'          => 'DESC',
		];

		$args = wp_parse_args( $args, $defaults );

		$where  = [ 'membership_id = %d' ];
		$values = [ $membership_id ];

		if ( $args['action'] ) {
			$where[]  = 'action = %s';
			$values[] = $args['action'];
		}

		if ( $args['promotion_type'] ) {
			$where[]  = 'promotion_type = %s';
			$values[] = $args['promotion_type'];
		}

		$sql = "SELECT * FROM " . self::$table;
		$sql .= " WHERE " . implode( ' AND ', $where );
		$sql .= " ORDER BY id " . esc_sql( $args['order'] );

		if ( $args['limit'] > 0 ) {
			$sql .= $wpdb->prepare(
				" LIMIT %d OFFSET %d",
				$args['limit'],
				$args['offset'],
			);
		}

		return $wpdb->get_results(
			$wpdb->prepare( $sql, $values ),
			ARRAY_A,
		);
	}

	/**
	 * Count usage
	 */
	public static function count( $args ) {
		global $wpdb;

		$where  = [ 'membership_id = %d' ];
		$values = [ (int) $args['membership_id'] ];

		if ( ! empty( $args['action'] ) ) {
			$where[]  = 'action = %s';
			$values[] = $args['action'];
		}

		if ( ! empty( $args['promotion_type'] ) ) {
			$where[]  = 'promotion_type = %s';
			$values[] = $args['promotion_type'];
		}

		if ( ! empty( $args['listing_id'] ) ) {
			$where[]  = 'listing_id = %d';
			$values[] = (int) $args['listing_id'];
		}

		$sql = "SELECT COUNT(*) FROM " . self::$table;
		$sql .= " WHERE " . implode( ' AND ', $where );

		return (int) $wpdb->get_var(
			$wpdb->prepare( $sql, $values ),
		);
	}

	/**
	 * Check if promotion already used for a listing
	 */
	public static function promotion_exists( $membership_id, $listing_id, $promotion_type ) {
		global $wpdb;

		$sql = "SELECT id FROM " . self::$table . "
                WHERE membership_id = %d
                AND listing_id = %d
                AND action = 'promotion'
                AND promotion_type = %s
                LIMIT 1";

		return (bool) $wpdb->get_var(
			$wpdb->prepare(
				$sql,
				$membership_id,
				$listing_id,
				$promotion_type,
			),
		);
	}

	/**
	 * Republish listings on membership renewal (unified expiry only)
	 *
	 * @param  int  $membership_id  The membership ID.
	 * @param  Membership|null  $membership  Optional membership object for expiry date.
	 */
	public static function republish_on_membership_renewal( $membership_id, $membership = null ) {
		$listing_ids = self::get_listing_ids_by_membership(
			$membership_id,
			[ 'action' => 'submission' ],
		);

		if ( empty( $listing_ids ) ) {
			return;
		}

		// Query expired/pending/publish listings directly
		// Have to change the expiry date for published listing also
		$query = new WP_Query( [
			'post_type'      => rtcl()->post_type,
			'post__in'       => $listing_ids,
			'post_status'    => [ 'rtcl-expired', 'rtcl-pending', 'publish' ],
			'posts_per_page' => - 1,
			'fields'         => 'ids',
			'no_found_rows'  => true,
		] );

		if ( empty( $query->posts ) ) {
			return;
		}

		// Get membership expiry date for setting listing expiry
		$expiry_date = null;
		if ( $membership && method_exists( $membership, 'get_expiry_date' ) ) {
			$expiry_date = $membership->get_expiry_date();
		}

		foreach ( $query->posts as $listing_id ) {
			wp_update_post( [
				'ID'          => $listing_id,
				'post_status' => 'publish',
			] );

			// Set the listing expiry date to match membership expiry
			if ( $expiry_date ) {
				update_post_meta( $listing_id, 'expiry_date', $expiry_date );
				delete_post_meta( $listing_id, 'never_expires' );
			}
		}

		do_action( 'rtcl_listings_republished_on_subscription_renewal', $membership_id );
	}

	/**
	 * Reactivate promotions on membership renewal.
	 *
	 * @param  int  $membership_id  The membership ID.
	 * @param  Membership|null  $membership  Optional membership object for expiry date.
	 */
	public static function reactivate_promotions_on_membership_renewal( $membership_id, $membership = null ) {
		$promotion_data = self::get_listing_ids_by_membership(
			$membership_id,
			[ 'action' => 'promotion' ],
		);

		if ( empty( $promotion_data ) ) {
			return;
		}

		$promotion_config = [
			'featured' => [ 'meta_key' => 'featured', 'expiry_key' => 'feature_expiry_date' ],
			'_top'     => [ 'meta_key' => '_top', 'expiry_key' => '_top_expiry_date' ],
			'_bump_up' => [ 'meta_key' => '_bump_up', 'expiry_key' => '_bump_up_expiry_date' ],
		];

		// Use membership expiry date if available, otherwise fallback to 5 days
		if ( $membership && method_exists( $membership, 'get_expiry_date' ) && $membership->get_expiry_date() ) {
			$expiry_date_format = $membership->get_expiry_date();
		} else {
			$expiry_date = new \DateTime( current_time( 'mysql' ) );
			$expiry_date->add( new \DateInterval( 'P5D' ) );
			$expiry_date_format = $expiry_date->format( 'Y-m-d H:i:s' );
		}

		foreach ( $promotion_config as $type => $config ) {
			if ( empty( $promotion_data[ $type ] ) ) {
				continue;
			}

			foreach ( $promotion_data[ $type ] as $listing_id ) {
				update_post_meta( $listing_id, $config['meta_key'], 1 );
				update_post_meta( $listing_id, $config['expiry_key'], $expiry_date_format );
			}

			do_action( "rtcl_{$type}_reactivated_on_subscription_renewal", $membership_id );
		}
	}

	/**
	 * Get listing IDs by membership.
	 *
	 * @param  int  $membership_id  The membership ID.
	 * @param  array  $args  Optional arguments: 'action' (submission|promotion), 'promotion_type' (featured|top|bump_up).
	 *
	 * @return array Flat array for submission, structured array for promotion grouped by promotion_type.
	 */
	public static function get_listing_ids_by_membership( $membership_id, $args = [] ) {
		global $wpdb;

		$defaults = [
			'action'         => null, // submission | promotion
			'promotion_type' => null, // featured | top | bump_up
		];

		$args = wp_parse_args( $args, $defaults );

		$where  = [ 'membership_id = %d' ];
		$values = [ (int) $membership_id ];

		$action         = $args['action'];
		$promotion_type = $args['promotion_type'];

		if ( $action === 'submission' ) {
			$where[] = "action = 'submission'";
			$where[] = 'promotion_type IS NULL';

			$sql = 'SELECT DISTINCT listing_id FROM ' . self::$table .
			       ' WHERE ' . implode( ' AND ', $where ) .
			       ' ORDER BY listing_id DESC';

			return array_map( 'intval', $wpdb->get_col( $wpdb->prepare( $sql, $values ) ) );
		}

		if ( $action === 'promotion' ) {
			$where[] = "action = 'promotion'";

			if ( ! empty( $promotion_type ) ) {
				$where[]  = 'promotion_type = %s';
				$values[] = $promotion_type;
			}

			$sql = 'SELECT DISTINCT listing_id, promotion_type FROM ' . self::$table .
			       ' WHERE ' . implode( ' AND ', $where ) .
			       ' ORDER BY listing_id DESC';

			$results = $wpdb->get_results( $wpdb->prepare( $sql, $values ), ARRAY_A );

			if ( empty( $results ) ) {
				return [];
			}

			$data = [];
			foreach ( $results as $row ) {
				$key            = $row['promotion_type'] ?: 'unknown';
				$data[ $key ][] = (int) $row['listing_id'];
			}

			return $data;
		}

		// No action filter - return all data structured
		$sql = 'SELECT DISTINCT listing_id, action, promotion_type FROM ' . self::$table .
		       ' WHERE ' . implode( ' AND ', $where ) .
		       ' ORDER BY listing_id DESC';

		$results = $wpdb->get_results( $wpdb->prepare( $sql, $values ), ARRAY_A );

		if ( empty( $results ) ) {
			return [];
		}

		$data = [];
		foreach ( $results as $row ) {
			$listing_id     = (int) $row['listing_id'];
			$row_action     = $row['action'];
			$row_promo_type = $row['promotion_type'];

			if ( $row_action === 'submission' ) {
				$data['submission'][] = $listing_id;
			} elseif ( $row_action === 'promotion' && $row_promo_type ) {
				$data['promotion'][ $row_promo_type ][] = $listing_id;
			}
		}

		return $data;
	}

}
