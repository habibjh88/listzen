<?php
/**
 * @package ListzenCore
 * Plugin Name:       Listzen Core
 * Description:       Listzen Theme Core Plugin.
 * Version:           1.0.2
 * Requires at least: 6.7
 * Requires PHP:      7.4
 * Author:            RadiusTheme
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Author URI:        https://radiustheme.com
 * Text Domain:       listzen-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'LISTZEN_CORE' ) ) {
	define( 'LISTZEN_CORE', '1.0.2' );
	define( 'LISTZEN_CORE_PREFIX', 'listzen' );
	define( 'LISTZEN_CORE_BASE_URL', plugin_dir_url( __FILE__ ) );
	define( 'LISTZEN_CORE_BASE_DIR', plugin_dir_path( __FILE__ ) );
	define( 'LISTZEN_CORE_BASE_FILE_NAME', plugin_basename( __FILE__ ) );
}

if ( file_exists( dirname( __FILE__ ) . '/vendor/autoload.php' ) ) :
	require_once dirname( __FILE__ ) . '/vendor/autoload.php';
endif;

if ( class_exists( 'ListzenCore\\Init' ) ) :
	ListzenCore\Init::instance();
endif;