<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package blusho
 */
use Listzen\Options\Opt;use ListzenCore\Builder\Builder;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">

	<?php wp_head(); ?>
</head>

<body <?php body_class('blusho-header-footer'); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site">

	<?php

    //do_action( 'rt_hf_header_markup' );


//	if ( false == apply_filters( 'listzen_header_builder_enable', true ) ) {
//		return;
//	}
	?>
    <header id="masthead" class="site-header listzen-header-builder" role="banner" style="opacity:0;transition: 0.4s 0.1s;">
		<?php Builder::get_elementor_content( 'header' ); ?>
    </header>
	<?php
	if ( class_exists( 'Listzen\Options\Opt' ) ) {
		get_template_part( 'template-parts/header/nav-drawer', Opt::$nav_drawer_style );
	}

    ?>

    <div id="content" class="site-content">
		<?php get_template_part( 'views/content', 'banner' ); ?>
