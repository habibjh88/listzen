<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 *
 * @var $args ;
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
$image_size = $args['thumbnail_size'] ?: 'thumbnail';
?>
<div class="testimonial-item">
	<div class="testimonial-inner-wrap">

		<?php if ( $args['quote_visibility'] ) : ?>
			<div class="quote-icon-wrap">
				<i class="rt-icon-quote-right-alt"></i>
			</div>
		<?php endif; ?>

		<?php
		if ( 'top' === $args['image_position'] ) :
			if ( ! empty( $args['image']['id'] ) ) {
				?>
				<div class='testimonial-img'>
					<?php listzen_html( wp_get_attachment_image( $args['image']['id'], $image_size ) ); ?>
				</div>
				<?php
			}
		endif;
		?>
		<div class="testimonial-content">

			<?php if ( $args['rating'] ) : ?>
				<div class="star-rating">★★★★★</div>
			<?php endif; ?>

			<div class="description">
				<?php listzen_html( $args['content'], 'default' ); ?>
			</div>

			<div class="bottom-content">
				<div class="name-designation">
					<?php
					if ( 'with-name' === $args['image_position'] ) :
						if ( ! empty( $args['image']['id'] ) ) {
							?>
							<div class='image-wrap'>
								<?php listzen_html( wp_get_attachment_image( $args['image']['id'], $image_size ) ); ?>
							</div>
							<?php
						}
					endif;
					?>

					<div class="name-info">
						<h3 class="item-title"><?php echo esc_html( $args['name'] ); ?></h3>

						<?php if ( $args['designation'] ) : ?>
							<div class="designation">
								<span><?php echo esc_html( $args['designation'] ); ?></span>
							</div>
						<?php endif; ?>
					</div>
				</div>
			</div>


		</div>


	</div>
</div>