<?php
/**
 * Grid Layout 1
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 *
 * @var  $thumbnail
 * @var  $post_meta
 * @var  $post_meta
 * @var  $title_tag
 * @var  $post_meta
 * @var  $post_type
 * @var  $entry_content
 * @var  $entry_footer
 */

use Listzen\Modules\Thumbnail;
use ListzenCore\Helper\Fns;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
?>

<div class="article-inner-wrapper">
	<?php
	if ( 'yes' === $thumbnail['thumbnail_visibility'] ) {
		Thumbnail::get_thumbnail( $thumbnail['thumbnail_size'] );
	}
	?>
    <div class="entry-wrapper">
        <header class="entry-header">
			<?php
			Fns::separate_meta( $post_meta );

			the_title( sprintf( '<h3 class="entry-title default-max-width"><a href="%s">', esc_url( get_permalink() ) ), '</a></h3>' );
			?>
        </header>
		<?php
		Fns::entry_meta( $post_meta );

		Fns::entry_content( $entry_content );

		Fns::entry_footer( $entry_footer );
		?>
    </div>
</div>