<?php
/**
 * @var $heading_tag
 * @var $marquee_direction
 * @var $icon_type
 * @var $marquee_icon
 * @var $image
 * @var $items
 * @var $gradient_display
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// phpcs:disable
?>

<div class="listzen-marquee-slider">
    <div class="listzen-marquee-inner <?php echo esc_attr( $marquee_direction ); ?>">
        <?php for ( $i = 1;
        $i <= 2;
        $i ++ ) : ?>
        <div class="listzen-marquee-item">
            <?php
            foreach ( $items2

            as $item ) :

            $attr   = '';
            $before = $after = '';

            if ( ! empty( $item['link']['url'] ) ) {
                $attr   = 'href="' . esc_url( $item['link']['url'] ) . '"';
                $attr   .= ! empty( $item['link']['is_external'] ) ? ' target="_blank"' : '';
                $attr   .= ! empty( $item['link']['nofollow'] ) ? ' rel="nofollow"' : '';
                $before = '<a ' . $attr . '>';
                $after  = '</a>';
            }

            $image_url = ! empty( $item['image']['url'] ) ? $item['image']['url'] : '';
            $image_alt = esc_attr( $item['title'] );
            $title     = $item['title'];
            if ( $image_url ) :
            ?>
            <div class="marquee-logo">
                <?php listzen_html( $before, 'link' ); ?>

                <div class="image-wrap">
                    <span class="overlay"></span>
                    <img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $image_alt ); ?>">
                </div>

                <?php if ( $title ) : ?>
                <<?php echo esc_attr( $heading_tag ); ?> class="entry-title">
                <span class="title"><?php listzen_html( $title ); ?></span>
            </<?php echo esc_attr( $heading_tag ); ?>>
        <?php endif; ?>

            <?php listzen_html( $after, 'link' ); ?>
        </div>
    <?php
    endif;
    endforeach;
    ?>
    </div>
    <?php endfor; ?>
</div>
</div>
