<?php
/**
 * @var $heading_tag
 * @var $marquee_direction
 * @var $icon_type
 * @var $marquee_icon
 * @var $image
 * @var $items
 * @var $gradient_display
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use Elementor\Icons_Manager;
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
?>

<div class="listzen-marquee-slider">
	<div class="listzen-marquee-inner <?php echo esc_attr( $marquee_direction ); ?>">
		<?php for ( $i = 1; $i <= 2; $i++ ) { ?>
			<div class="listzen-marquee-item">
				<?php
				foreach ( $items as $item ) {
					$attr = '';
					if ( ! empty( $item['link']['url'] ) ) {
						$attr  = 'href="' . $item['link']['url'] . '"';
						$attr .= ! empty( $item['link']['is_external'] ) ? ' target="_blank"' : '';
						$attr .= ! empty( $item['link']['nofollow'] ) ? ' rel="nofollow"' : '';
						$title = '<a ' . $attr . '>' . $item['title'] . '</a>';
					} else {
						$title = $item['title'];
					}
					$style = $item['style'];
					?>
					<<?php echo esc_attr( $heading_tag ); ?> class="entry-title">
						<span class="icon-holder">
							<?php Icons_Manager::render_icon( $marquee_icon ); ?>
						</span>
						<?php if ( $title ) : ?>
							<span class="title <?php echo esc_attr( $style ); ?>"><?php listzen_html( $title ); ?></span>
						<?php endif; ?>
					</<?php echo esc_attr( $heading_tag ); ?>>
				<?php } ?>
			</div>
		<?php } ?>
	</div>
</div>