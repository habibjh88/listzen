<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use Listzen\Modules\PostMeta;
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
$post_classes = 'listzen-blog-post';
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( $post_classes ); ?>>
    <div class="article-inner-wrapper">
		<?php //listzen_post_thumbnail('listzen-size4'); ?>
        <div class="entry-wrapper">
				<?php
				if ( ! empty( $meta_list ) ) {
                    PostMeta::get_meta('post',[
                        'with_list'     => true,
                        'include'       => $meta_list,
                    ]);
				}
				the_title( sprintf( '<h4 class="entry-title default-max-width"><a href="%s">', esc_url( get_permalink() ) ), '</a></h4>' );
				?>

			<?php
            if( $content ):
				echo "<div class='entry-content'>";
				listzen_html( wp_trim_words( get_the_excerpt(), 15 ) );
				echo "</div>";
                endif;
			?>
        </div>
    </div>
</article>