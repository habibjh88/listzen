
(function ($) {
    jQuery(document).ready(function ($) {

        'use strict';
        // ColorPicker, Datepicker, Timepicker
        $(".listzen-metabox-picker").each(function () {
            // Exclude first hidden repeater field
            if (!$(this).parents('.listzen-postmeta-repeater.repeater-init').length) {
                executePickers($(this));
            }
        });

        // Multi Select
        $(".listzen-multi-select").select2();
        $(document).on('widget-updated', function (event) {
            $(".listzen-multi-select").select2();
        });


        // initialize conditionals
        $(".listzen-postmeta-container .listzen-postmeta-dependent").each(function () {
            var name = $(this).data('required');
            var value = $(this).data('required-value');
            let newName = name.replace(/\[/g, '\\[').replace(/\]/g, '\\]');
            var fieldValue = $(".listzen-meta-field[name=" + newName + "]").val();
            //action
            if (value != fieldValue) {
                $(this).hide();
            }
        });

        // radio field onchange conditional
        $(".listzen-postmeta-container .has-condition .listzen-meta-field").on('change', function () {
            var name = $(this).attr('name');
            var value = $(this).val();

            // hide
            $('.listzen-postmeta-container tr[data-required="' + name + '"]')
                .filter(function () {
                    return $(this).data("required-value") != value;
                }).hide();

            // show
            $('.listzen-postmeta-container tr[data-required="' + name + '"]')
                .filter(function () {
                    return $(this).data("required-value") == value;
                }).show();

        });

        /*

 $(".listzen-postmeta-container .listzen-postmeta-dependent").each(function () {
            var name = $(this).data('required');
            var value = $(this).data('required-value');

            var $input = $("input[name=" + name + "]");
            var inputType = $input.attr('type');

            var fieldValue = null;

            // radio
            if (inputType == 'radio') {
                fieldValue = $("input[name=" + name + "]:checked").val();
            }

            //action
            if (value != fieldValue) {
                $(this).hide();
            }
        });


        $(".listzen-postmeta-container input[type=radio]").on('change', function () {
            var name = $(this).attr('name');
            var value = $(this).val();

            // hide
            $('.listzen-postmeta-container tr[data-required="' + name + '"]')
                .filter(function () {
                    return $(this).data("required-value") != value;
                }).hide();

            // show
            $('.listzen-postmeta-container tr[data-required="' + name + '"]')
                .filter(function () {
                    return $(this).data("required-value") == value;
                }).show();

        });
*/
        /*Repeater*/

        // Generate close button
        var repeaterCloseHtml = '<a class="listzen-postmeta-repeater-close"></a>'
        $(".listzen-postmeta-repeater tr:last-child td").append(repeaterCloseHtml);

        // Close button action
        $(".listzen-postmeta-repeater-wrap").on('click', '.listzen-postmeta-repeater-close', function (event) {
            $(this).closest('.listzen-postmeta-repeater').fadeOut("fast", function () {
                $(this).remove();
            })
        });

        // Add more button action
        $(".listzen-postmeta-container .listzen-postmeta-repeater-addmore").on('click', 'button', function (event) {

            // Num Data
            var $wrapper = $(this).closest('.listzen-postmeta-repeater-wrap');
            var oldNum = $wrapper.data('num');
            var newNum = oldNum + 1;
            $wrapper.data('num', newNum);

            // Generate contents
            var $repeaterContent = $wrapper.find(".listzen-postmeta-repeater.repeater-init");

            var inputField = $wrapper.data('fieldname');
            ;

            inputField = inputField.split('[')[0];
            var replaceString = inputField + '\\[hidden\\]';
            var replaceWith = inputField + '[' + oldNum + ']';
            var replaceString = new RegExp(replaceString, "g");

            var repeaterHtml = $repeaterContent[0].innerHTML.replace(replaceString, replaceWith);

            var newElement = document.createElement('table');
            newElement.className = 'listzen-postmeta-repeater';
            newElement.innerHTML = repeaterHtml;

            // Execute contents
            $(this).closest('.listzen-postmeta-repeater-addmore').before(newElement);

            // Execute Pickers
            $(newElement).find(".listzen-metabox-picker").each(function () {
                executePickers($(this));
            });

            return false;
        });

        // Enable Sortable
        $(".listzen-postmeta-repeater-wrap").sortable({
            items: '.listzen-postmeta-repeater',
            cursor: "move"
        });

        // Image upload field
        $("body").on('click', '.listzen_upload_image', function (event) {
            var btnClicked = $(this);
            var custom_uploader = wp.media({
                multiple: false
            }).on("select", function () {
                var attachment = custom_uploader.state().get("selection").first().toJSON();
                btnClicked.closest(".listzen_metabox_image").find(".custom_upload_image").val(attachment.id).trigger('change');
                btnClicked.closest(".listzen_metabox_image").find(".custom_preview_image").attr("src", attachment.url).show();
                btnClicked.closest(".listzen_metabox_image").find(".listzen_remove_image_wrap").show();

            }).open();
        });
        $("body").on('click', '.listzen_remove_image', function (event) {
            event.preventDefault();
            remove_uploaded_image($(this).closest(".listzen_metabox_image"));
            return false;
        });

        // Gallery upload field
        var rtMetaGalleryFrame;
        var rtMetaGalleryBtn;

        $("body").on('click', '.listzen_upload_gallery', function (event) {
            rtMetaGalleryBtn = $(this);
            if (rtMetaGalleryFrame) {
                rtMetaGalleryFrame.open();
                return false;
            }

            rtMetaGalleryFrame = wp.media({
                title: "Select Image",
                button: {
                    text: "Insert Image"
                },
                multiple: true
            });

            rtMetaGalleryFrame.on("select", function () {
                var selection = rtMetaGalleryFrame.state().get('selection');
                var existing_ids = rtMetaGalleryBtn.closest(".listzen_metabox_gallery").find(".custom_upload_image").val();
                var ids = [];
                if(existing_ids) {
                    ids = rtMetaGalleryBtn.closest(".listzen_metabox_gallery").find(".custom_upload_image").val().split(',');
                }

                //rtMetaGalleryBtn.closest(".listzen_metabox_gallery").find(".custom_preview_images").html('');

                selection.map(function (attachment) {
                    attachment = attachment.toJSON();
                    ids.push(attachment.id);
                    rtMetaGalleryBtn.closest(".listzen_metabox_gallery").find(".custom_preview_images").append("<img src=" + attachment.sizes.thumbnail.url + ">");
                });

                rtMetaGalleryBtn.closest(".listzen_metabox_gallery").find(".custom_upload_image").val(ids);
                rtMetaGalleryBtn.closest(".listzen_metabox_gallery").find(".listzen_remove_gallery").show();
            });

            rtMetaGalleryFrame.open();
            return false;
        });


        /*
            rtMetaGalleryFrame.on('open', function (event) {
                var selection = rtMetaGalleryFrame.state().get('selection');
                var ids = rtMetaGalleryBtn.closest(".listzen_metabox_gallery").find(".custom_upload_image").val().split(',');

                ids.forEach(function (id) {
                    var attachment = wp.media.attachment(id);
                    attachment.fetch();
                    selection.add(attachment ? [attachment] : []);
                });
            });*/


        $("body").on('click', '.listzen_remove_gallery', function (event) {
            event.preventDefault();
            $(this).closest(".listzen_metabox_gallery").find(".custom_upload_image").val("");
            $(this).closest(".listzen_metabox_gallery").find(".custom_preview_images").html('');
            $(this).closest(".listzen_metabox_gallery").find(".listzen_remove_gallery").hide();
            return false;
        });


        // File upload field
        $("body").on('click', '.listzen_upload_file', function (event) {
            var btnClicked = $(this);
            var custom_uploader = wp.media({
                multiple: false
            }).on("select", function () {
                var attachment = custom_uploader.state().get("selection").first().toJSON();
                console.log(attachment);
                btnClicked.closest(".listzen_metabox_file").find(".custom_upload_file").val(attachment.id);
                btnClicked.closest(".listzen_metabox_file").find(".custom_preview_file").attr("href", attachment.url).html(attachment.title).show();
                btnClicked.closest(".listzen_metabox_file").find(".listzen_remove_file_wrap").show();
            }).open();

        });
        $("body").on('click', '.listzen_remove_file', function (event) {
            event.preventDefault();
            $(this).closest(".listzen_metabox_file").find(".custom_upload_file").val("");
            $(this).closest(".listzen_metabox_file").find(".custom_preview_file").attr("href", "#").html("").hide();
            $(this).closest(".listzen_metabox_file").find(".listzen_remove_file_wrap").hide();
            return false;
        });
    });

    function executePickers($item) {
        if ($item.hasClass('listzen-metabox-colorpicker')) {
            $item.wpColorPicker();
        } else if ($item.hasClass('listzen-metabox-datepicker')) {
            var options = $.extend(
                {},
                $.datepicker.regional["en-US"],
                {dateFormat: $item.data('format')}
            );
            $item.datepicker(options);
        } else if ($item.hasClass('listzen-metabox-timepicker')) {
            $item.timepicker();
        } else if ($item.hasClass('listzen-metabox-timepicker-24')) {
            $item.timepicker({'timeFormat': 'H:i'});
        }
    }

    function remove_uploaded_image($item) {
        $item.find(".custom_upload_image").val("").trigger('change');
        $item.find(".custom_preview_image").attr("src", "").hide();
        $item.find(".listzen_remove_image_wrap").hide();
    }

    /* Taxonomy Fields adding items ajax fix */
    $(document).ajaxComplete(function (event, request, options) {
        if (request && 4 === request.readyState && 200 === request.status
            && options.data) {

            if (typeof options.data.indexOf == 'undefined') {
                return;
            }

            if (options.data.indexOf('action=add-tag') < 0) {
                return;
            }

            if (typeof wpAjax == 'undefined') {
                return;
            }

            var res = wpAjax.parseAjaxResponse(request.responseXML, 'ajax-response');
            if (!res || res.errors) {
                return;
            }

            // Image upload field
            $("#addtag .listzen_metabox_image").each(function () {
                remove_uploaded_image($(this));
            });

            // Number
            $('#addtag input[type="number"]').val('');

            // Select
            $('#addtag select.listzen-meta-field').each(function () {
                var value = $(this).find('[selected="selected"]').val();
                if (value) {
                    $(this).val(value);
                }
            });


            return;
        }
    });

    jQuery(document).ready(function ($) {

        /* var checkSlectVal =  $('.rt-header-footer-select').val()
         if (checkSlectVal.includes('custom')) {
             $('.rt_el_builder_meta-choose_post').show();
         }
         $('.rt-header-footer-select').on("change", function (event) {
             var selectValue = $(this).val();
             if (selectValue.includes('custom')) {
                 $(this).closest('tr').next().show();
             } else {
                 $(this).closest('tr').next().hide();
             }
         });
 */
        $(".listzen-ajax-multi-select").select2({
            ajax: {
                url: listzenObj.rest_url + "rt/v1/all-posts",
                dataType: "json",
                delay: 250,
                data: function (params) {
                    return {
                        search: params.term,
                        page: params.page,
                    };
                },
                processResults: function (data, params) {
                    params.page = params.page || 1;
                    return {
                        results: data,
                        pagination: {
                            more: params.page * 15 < data.length
                        }
                    };
                },
                success: function (data) {
                    // for debug purposes
                    console.log("SUCCESS: ");
                },
                error: function (data) {
                    // for debug purposes
                    console.log("ERROR: ");
                },
                cache: true
            },
            placeholder: "Search...",
            minimumInputLength: 1,
            templateResult: formatRepo,
            templateSelection: formatRepoSelection
        });

        function formatRepo(data) {
            if (data.loading) {
                return data.text;
            }
            var $container = $(
                "<div class='select2-result-repository clearfix'>" +
                "<div class='select2-result-repository__name'></div>" +
                "</div>"
            );

            $container.find(".select2-result-repository__name").text('[' + data.id + ']' + ' ' + data.text);

            return $container;
        }

        function formatRepoSelection(data) {
            return data.text || data.id;
        }
    });
}(jQuery));