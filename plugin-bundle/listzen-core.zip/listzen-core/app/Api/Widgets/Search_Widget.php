<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Api\Widgets;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
use ListzenCore\Generator\WidgetFieldsGenerator;
use \WP_Widget;

class Search_Widget extends WP_Widget {

	public function __construct() {
		$id    = LISTZEN_CORE_PREFIX . '_search';
		$title = __( 'Listzen: Search', 'listzen-core' );
		$args  = [
			'description' => __( 'Displays Search Field', 'listzen-core' ),
		];
		parent::__construct( $id, $title, $args );
	}

	public function widget( $args, $instance ) {
		listzen_html( $args['before_widget'] );
		$title = apply_filters( 'widget_title', $instance['title'] );
		if ( ! empty( $title ) ) {
			listzen_html( $args['before_title'] . $title . $args['after_title'] );
		}
		?>
        <div class="quaxa-search-form">
			<?php listzen_html( get_search_form() ) ?>
        </div>
		<?php
		listzen_html( $args['after_widget'] );
	}

	public function update( $new_instance, $old_instance ) {
		$instance          = [];
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';

		return $instance;
	}

	public function form( $instance ) {
		$defaults = [
			'title' => '',
		];
		$instance = wp_parse_args( (array) $instance, $defaults );

		$fields = [
			'title' => [
				'label' => esc_html__( 'Title', 'listzen-core' ),
				'type'  => 'text',
			],
		];

		WidgetFieldsGenerator::display( $fields, $instance, $this );
	}

}