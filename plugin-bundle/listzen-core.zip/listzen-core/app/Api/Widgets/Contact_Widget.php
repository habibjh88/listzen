<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Api\Widgets;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use ListzenCore\Generator\WidgetFieldsGenerator;
use ListzenCore\Helper\Fns;
use \WP_Widget;

//---------------------------------------------------------------------------
// Flickr widget
//---------------------------------------------------------------------------

class Contact_Widget extends WP_Widget {

	public function __construct() {
		$id    = LISTZEN_CORE_PREFIX . '_contact';
		$title = __( 'Listzen: Contact', 'listzen-core' );
		$args  = [
			'description' => esc_html__( 'Displays Contact Info', 'listzen-core' )
		];
		parent::__construct( $id, $title, $args );
	}


	public function form( $instance ) {
		$defaults = [
			'address' => listzen_option( 'listzen_contact_address' ),
			'mail'    => listzen_option( 'listzen_email' ),
			'phone'   => listzen_option( 'listzen_phone' ),
			'website' => listzen_option( 'listzen_website' ),
		];

		$instance = wp_parse_args( (array) $instance, $defaults );

		$fields = [
			'title'   => [
				'label' => esc_html__( 'Title', 'listzen-core' ),
				'type'  => 'text',
			],
			'address' => [
				'label' => esc_html__( 'Address', 'listzen-core' ),
				'type'  => 'textarea',
			],
			'mail'    => [
				'label' => esc_html__( 'Mail', 'listzen-core' ),
				'type'  => 'text',
			],
			'phone'   => [
				'label' => esc_html__( 'Phone', 'listzen-core' ),
				'type'  => 'text',
			],
			'website' => [
				'label' => esc_html__( 'Website', 'listzen-core' ),
				'type'  => 'text',
			],
		];

		WidgetFieldsGenerator::display( $fields, $instance, $this );
	}

	public function update( $new_instance, $old_instance ) {

		$instance = $old_instance;

		$instance['title']   = ( ! empty( $new_instance['title'] ) ) ? wp_strip_all_tags( $new_instance['title'] ) : '';
		$instance['address'] = ( ! empty( $new_instance['address'] ) ) ? wp_strip_all_tags( $new_instance['address'] ) : '';
		$instance['mail']    = ( ! empty( $new_instance['mail'] ) ) ? wp_strip_all_tags( $new_instance['mail'] ) : '';
		$instance['phone']   = ( ! empty( $new_instance['phone'] ) ) ? wp_strip_all_tags( $new_instance['phone'] ) : '';
		$instance['website'] = ( ! empty( $new_instance['website'] ) ) ? wp_strip_all_tags( $new_instance['website'] ) : '';

		return $instance;
	}

	public function widget( $args, $instance ) {
		//phpcs:disable
		echo $args['before_widget'];
		$title = apply_filters( 'widget_title', $instance['title'] );
		if ( ! empty( $title ) ) {
			echo $args['before_title'] . $title . $args['after_title'];
		}
		$output = Fns::contact_render( $instance );
		listzen_html( $output );
		echo $args['after_widget'];
		//phpcs:enable
	}
}