<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Api\Widgets;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use ListzenCore\Generator\WidgetFieldsGenerator;
use \WP_Widget;

class About_Widget extends WP_Widget {

	public function __construct() {

		$id    = LISTZEN_CORE_PREFIX . '_about';
		$title = __( 'Listzen: About', 'listzen-core' );
		$args  = [
			'description' => __( 'Displays About Info', 'listzen-core' ),
		];
		parent::__construct( $id, $title, $args );
	}

	public function widget( $args, $instance ) {

		listzen_html( $args['before_widget'] );

		$title = apply_filters( 'widget_title', $instance['title'] );
		if ( ! empty( $title ) ) {
			$title_markup = $args['before_title'] . $title . $args['after_title'];
			listzen_html( $title_markup );
		}

		if ( ! empty( $instance['description'] ) ) {
			echo "<p>";
			listzen_html( $instance['description'] );
			echo "</p>";
		}
//		listzen_about_social( $instance );
		listzen_html( $args['after_widget'] );
	}

	public function update( $new_instance, $old_instance ) {
		$instance                = [];
		$instance['title']       = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
		$instance['description'] = ( ! empty( $new_instance['description'] ) ) ? listzen_html( $new_instance['description'], '', false ) : '';
		$instance['facebook']    = ( ! empty( $new_instance['facebook'] ) ) ? sanitize_text_field( $new_instance['facebook'] ) : '';
		$instance['twitter']     = ( ! empty( $new_instance['twitter'] ) ) ? sanitize_text_field( $new_instance['twitter'] ) : '';
		$instance['linkedin']    = ( ! empty( $new_instance['linkedin'] ) ) ? sanitize_text_field( $new_instance['linkedin'] ) : '';
		$instance['pinterest']   = ( ! empty( $new_instance['pinterest'] ) ) ? sanitize_text_field( $new_instance['pinterest'] ) : '';
		$instance['instagram']   = ( ! empty( $new_instance['instagram'] ) ) ? sanitize_text_field( $new_instance['instagram'] ) : '';
		$instance['youtube']     = ( ! empty( $new_instance['youtube'] ) ) ? sanitize_text_field( $new_instance['youtube'] ) : '';
		$instance['rss']         = ( ! empty( $new_instance['rss'] ) ) ? sanitize_text_field( $new_instance['rss'] ) : '';
		$instance['zalo']        = ( ! empty( $new_instance['zalo'] ) ) ? sanitize_text_field( $new_instance['zalo'] ) : '';
		$instance['telegram']    = ( ! empty( $new_instance['telegram'] ) ) ? sanitize_text_field( $new_instance['telegram'] ) : '';

		return $instance;
	}

	public function form( $instance ) {
		$defaults = [
			'title'       => '',
			'description' => '',
			'facebook'    => '',
			'twitter'     => '',
			'linkedin'    => '',
			'pinterest'   => '',
			'instagram'   => '',
			'youtube'     => '',
			'rss'         => '',
			'zalo'        => '',
			'telegram'    => '',
		];
		$instance = wp_parse_args( (array) $instance, $defaults );

		$fields = [
			'title'       => [
				'label' => esc_html__( 'Title', 'listzen-core' ),
				'type'  => 'text',
			],
			'description' => [
				'label' => esc_html__( 'Description', 'listzen-core' ),
				'type'  => 'textarea',
			],
			'facebook'    => [
				'label' => esc_html__( 'Facebook URL', 'listzen-core' ),
				'type'  => 'url',
			],
			'twitter'     => [
				'label' => esc_html__( 'Twitter URL', 'listzen-core' ),
				'type'  => 'url',
			],
			'linkedin'    => [
				'label' => esc_html__( 'Linkedin URL', 'listzen-core' ),
				'type'  => 'url',
			],
			'pinterest'   => [
				'label' => esc_html__( 'Pinterest URL', 'listzen-core' ),
				'type'  => 'url',
			],
			'instagram'   => [
				'label' => esc_html__( 'Instagram URL', 'listzen-core' ),
				'type'  => 'url',
			],
			'youtube'     => [
				'label' => esc_html__( 'YouTube URL', 'listzen-core' ),
				'type'  => 'url',
			],
			'rss'         => [
				'label' => esc_html__( 'Rss Feed URL', 'listzen-core' ),
				'type'  => 'url',
			],
			'zalo'        => [
				'label' => esc_html__( 'Zalo Feed URL', 'listzen-core' ),
				'type'  => 'url',
			],
			'telegram'    => [
				'label' => esc_html__( 'Telegram Feed URL', 'listzen-core' ),
				'type'  => 'url',
			],
		];

		WidgetFieldsGenerator::display( $fields, $instance, $this );
	}

}