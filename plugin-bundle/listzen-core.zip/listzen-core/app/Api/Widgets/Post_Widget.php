<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Api\Widgets;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use ListzenCore\Generator\WidgetFieldsGenerator;
use ListzenCore\Helper\Fns;
use Listzen\Helpers\Fns as ThemeFns;
use \WP_Widget;
class Post_Widget extends WP_Widget {

	public function __construct() {
		$id    = LISTZEN_CORE_PREFIX . '_blog_post';
		$title = __( 'Listzen: Blog Post', 'listzen-core' );
		$args  = [
			'description' => esc_html__( 'Displays Blog Post', 'listzen-core' )
		];
		parent::__construct( $id, $title, $args );
	}


	public function form( $instance ) {
		$defaults = [
			'title'          => __( 'Latest Posts', 'listzen-core' ),
			'posts_type'     => 'post',
			'posts_per_page' => 5,
			'orderby'        => 'date',
			'order'          => 'DESC',
		];

		$instance = wp_parse_args( (array) $instance, $defaults );

		$fields = [
			'title'          => [
				'label' => esc_html__( 'Title', 'listzen-core' ),
				'type'  => 'text',
			],
			'layout'         => [
				'label'   => esc_html__( 'Layout Style', 'listzen-core' ),
				'type'    => 'select',
				'options' => [
					'blog-list-style'      => __( 'List', 'listzen-core' ),
					'blog-grid-style'      => __( 'Grid', 'listzen-core' ),
				]
			],
			'query_title'    => [
				'label' => esc_html__( 'QUERY', 'listzen-core' ),
				'type'  => 'heading',
			],
			'posts_type'     => [
				'label'   => esc_html__( 'Post Type', 'listzen-core' ),
				'type'    => 'select',
				'options' => ThemeFns::get_post_types()
			],
			'posts_per_page' => [
				'label' => esc_html__( 'Posts Per Page', 'listzen-core' ),
				'type'  => 'number',
			],
			'orderby'        => [
				'label'   => esc_html__( 'Order by', 'listzen-core' ),
				'type'    => 'select',
				'options' => [
					'date'          => __( 'Date', 'listzen-core' ),
					'author'        => __( 'Author', 'listzen-core' ),
					'title'         => __( 'Title', 'listzen-core' ),
					'modified'      => __( 'Last modified date', 'listzen-core' ),
					'parent'        => __( 'Post parent ID', 'listzen-core' ),
					'comment_count' => __( 'Number of comments', 'listzen-core' ),
					'menu_order'    => __( 'Menu order', 'listzen-core' ),
					'rand'          => __( 'Random order', 'listzen-core' ),
					'popular'       => __( 'Popular Post', 'listzen-core' ),
				]
			],
			'order'          => [
				'label'   => esc_html__( 'Order', 'listzen-core' ),
				'type'    => 'select',
				'options' => [
					'ASC'  => __( 'ASC', 'listzen-core' ),
					'DESC' => __( 'DESC', 'listzen-core' ),
				]
			],
			'post_id'        => [
				'label' => esc_html__( 'Post by ID', 'listzen-core' ),
				'type'  => 'text',
				'desc'  => esc_html__( 'Enter post id by comma (,) separator.', 'listzen-core' ),
			],

			'meta_title'         => [
				'label' => esc_html__( 'Choose Meta', 'listzen-core' ),
				'type'  => 'heading',
			],
			'category'           => [
				'label' => esc_html__( 'Category', 'listzen-core' ),
				'type'  => 'checkbox',
			],
			'author'             => [
				'label' => esc_html__( 'Author', 'listzen-core' ),
				'type'  => 'checkbox',
			],
			'date'               => [
				'label' => esc_html__( 'Date', 'listzen-core' ),
				'type'  => 'checkbox',
			],
			'content'               => [
				'label' => esc_html__( 'Content', 'listzen-core' ),
				'type'  => 'checkbox',
			],
		];

		WidgetFieldsGenerator::display( $fields, $instance, $this );
	}

	public function update( $new_instance, $old_instance ) {

		$instance = $old_instance;
		$instance['title']              = $new_instance['title'] ?? __( 'Latest Post', 'listzen-core' );
		$instance['layout']             = $new_instance['layout'] ?? 'blog-list-style';
		$instance['posts_type']         = $new_instance['posts_type'] ?? 'post';
		$instance['posts_per_page']     = $new_instance['posts_per_page'] ?? 5;
		$instance['orderby']            = $new_instance['orderby'] ?? 'date';
		$instance['order']              = $new_instance['order'] ?? 'DESC';
		$instance['post_id']            = $new_instance['post_id'] ?? '';
		$instance['category']           = $new_instance['category'] ?? '';
		$instance['author']             = $new_instance['author'] ?? '';
		$instance['date']               = $new_instance['date'] ?? '';
		$instance['content']            = $new_instance['content'] ?? '';

		return $instance;
	}

	public function widget( $args, $instance ) {

		listzen_html( $args['before_widget'] );
		$title = apply_filters( 'widget_title', $instance['title']??'' );
		if ( ! empty( $title ) ) {
			listzen_html( $args['before_title'] . $title . $args['after_title'] );
		}

		$postArgs = [
			'post_type'           => $instance['posts_type'] ?? 'post',
			'ignore_sticky_posts' => 1,
			'posts_per_page'      => $instance['posts_per_page'] ?? 5,
			'post_status'         => 'publish',
		];

		if ( ! empty( $instance['orderby'] ) ) {
			$postArgs['orderby'] = $instance['orderby'];
		}

		if ( ! empty( $instance['order'] ) ) {
			$postArgs['order'] = $instance['order'];
		}

		if ( ! empty( $instance['post_id'] ) ) :
			$post_ids             = explode( ',', $instance['post_id'] );
			$postArgs['post__in'] = $post_ids;
		endif;

		$query = new \WP_Query( $postArgs );

		$meta_list  = [];
		$_meta_list = listzen_option( 'listzen_blog_meta', false, true );
		foreach ( $_meta_list as $meta ) {
			if ( ! empty( $instance[ $meta ] ) ) {
				$meta_list[] = $meta;
			}
		}

		$data       = [
			'meta_list'          => $meta_list,
			'content' => $instance['content']??'',
		];
		$layout     = $instance['layout'] ?? 'blog-list-style';
		$post_count = 1;
		if ( $query->have_posts() ) :
			echo "<div class='listzen-widdget-post " . esc_attr( $layout ) . "'>";
			while ( $query->have_posts() ) : $query->the_post();
				set_query_var( 'post_count', $post_count );
				Fns::get_template( "widgets/latest-posts", $data );
				$post_count ++;
			endwhile;
			echo "</div>";
			wp_reset_postdata();
		endif;

		listzen_html( $args['after_widget'] );
	}
}