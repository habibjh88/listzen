<?php
/**
 * Initializes all API endpoints for the Listzen plugin.
 *
 * @package ListzenCore\Api
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Api;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use ListzenCore\Traits\SingletonTraits;
use ListzenCore\Api\Rest\PostsRestApi;
use ListzenCore\Api\Rest\AjaxMetaPostSearch;
use ListzenCore\Api\Rest\ImageSizeRestApi;
use ListzenCore\Api\Settings\SettingsApi;
use ListzenCore\Api\Widgets\WidgetsApi;

/**
 * Class Api
 *
 * Central manager class for registering all custom Listzen API endpoints.
 */
class Api {
	use SingletonTraits;

	/**
	 * Api constructor.
	 *
	 * Initializes all related API classes.
	 * Each class handles its own specific route or API concern.
	 */
	public function __construct() {
		PostsRestApi::instance();
		AjaxMetaPostSearch::instance();
		ImageSizeRestApi::instance();
		SettingsApi::instance();
		WidgetsApi::instance();
	}
}