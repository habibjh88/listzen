<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Api\Settings;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
use ListzenCore\Traits\SingletonTraits;

class SettingsApi {
	use SingletonTraits;

	public function __construct() {
		add_action( 'admin_init', [ $this, 'register_settings' ] );
	}

	function register_settings() {
		// Register the setting so WordPress knows about it
		register_setting( 'general', 'listzen_gfonts_option', [
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_text_field',
			'default'           => 'no',
		] );

		// Add the field to the General Settings page
		add_settings_field(
			'listzen_gfonts_option', // ID
			'Listzen Google Fonts',   // Title
			[$this, 'gfonts_option_callback'], // Callback function to output the field
			'general'           // Page (General Settings)
		);
	}

	// Output the select field
	public function gfonts_option_callback() {
		$value = get_option( 'listzen_gfonts_option', 'no' );
		?>
		<select name="listzen_gfonts_option">
            <option value="no" <?php selected( $value, 'no' ); ?>><?php echo esc_html__( 'Load all fonts', 'listzen-core' ) ?></option>
            <option value="yes" <?php selected( $value, 'yes' ); ?>><?php echo esc_html__( 'Load popular fonts only', 'listzen-core' ) ?></option>
		</select>
		<p class="description">
			<?php echo esc_html__( "If the Customizer is not loading correctly, you can choose to load only popular Google Fonts from here to improve performance.", "listzen-core" ) ?>
		</p>
		<?php
	}
}