<?php
/**
 * REST API integration for Listzen blocks.
 *
 * @package ListzenCore\Api
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Api\Rest;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use ListzenCore\Blocks\Renderer\PostRenderer;
use ListzenCore\Traits\SingletonTraits;

/**
 * Class RestApi
 *
 * Handles custom REST API routes for Listzen.
 */
class PostsRestApi {
	use SingletonTraits;

	/**
	 * Class constructor.
	 *
	 * Hooks the REST API route registration into WordPress.
	 */
	public function __construct() {
		add_action( 'rest_api_init', [ $this, 'init_rest_routes' ], 99 );
	}

	/**
	 * Registers custom REST API routes.
	 *
	 * @return void
	 */
	public function init_rest_routes() {
		register_rest_route( 'listzen/v2', '/posts', [
			'methods'             => 'POST',
			'callback'            => [ $this, 'listzen_get_posts' ],
			'permission_callback' => '__return_true',
		] );
	}

	/**
	 * Handles the `/listzen/v2/posts` REST request.
	 *
	 * @param \WP_REST_Request $request Incoming REST request.
	 *
	 * @return \WP_REST_Response
	 */
	public function listzen_get_posts( $request ) {
		$attributes        = $request->get_params();
		$postRender        = new PostRenderer( $attributes );
		$send_data['html'] = $postRender->render();

		return rest_ensure_response( $send_data );
	}
}