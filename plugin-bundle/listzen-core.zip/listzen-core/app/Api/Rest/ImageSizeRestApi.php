<?php
/**
 * Registers a REST API endpoint for retrieving all registered image sizes.
 *
 * @package RT\ThePostGrid\Controllers\Api
 */

namespace ListzenCore\Api\Rest;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use ListzenCore\Traits\SingletonTraits;
use RT\ThePostGrid\Helpers\Fns;

/**
 * Class ImageSizeRestApi
 *
 * Handles the REST API route for retrieving image size information.
 */
class ImageSizeRestApi {
	use SingletonTraits;

	/**
	 * Class constructor.
	 *
	 * Hooks into the WordPress REST API initialization to register the image size route.
	 */
	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_image_size_route' ) );
	}

	/**
	 * Registers the REST API route for image sizes.
	 *
	 * Endpoint: /rttpg/v1/image-size
	 *
	 * @return void
	 */
	public function register_image_size_route() {
		register_rest_route(
			'listzen/v2', 'image-size',
			[
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_image_sizes' ),
				'permission_callback' => function () {
					return current_user_can( 'edit_posts' );
				},
			]
		);
	}

	/**
	 * Callback for the /rttpg/v1/image-size REST endpoint.
	 *
	 * Retrieves all registered image sizes using a helper method.
	 *
	 * @return \WP_REST_Response REST-formatted response with image size data.
	 */
	public function get_image_sizes() {

		global $_wp_additional_image_sizes;

		$sizes       = get_intermediate_image_sizes();
		$image_sizes = [];

		$image_sizes[] = [
			'value' => 'full',
			'label' => esc_html__( 'Full', 'listzen-core' ),
		];

		foreach ( $sizes as $size ) {
			if ( in_array( $size, [ 'thumbnail', 'medium', 'medium_large', 'large' ], true ) ) {
				$image_sizes[] = [
					'value' => $size,
					'label' => ucwords( trim( str_replace( [ '-', '_' ], [ ' ', ' ' ], $size ) ) ),
				];
			} else {
				$image_sizes[] = [
					'value' => $size,
					'label' => sprintf(
						'%1$s (%2$sx%3$s)',
						ucwords( trim( str_replace( [ '-', '_' ], [ ' ', ' ' ], $size ) ) ),
						$_wp_additional_image_sizes[ $size ]['width'],
						$_wp_additional_image_sizes[ $size ]['height']
					),
				];
			}
		}

		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
		return rest_ensure_response( apply_filters( 'homlisti_mage_size_guten', $image_sizes ) );
	}
}