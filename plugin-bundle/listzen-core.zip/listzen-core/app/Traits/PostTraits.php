<?php
/**
 * PostTraits
 */

namespace ListzenCore\Traits;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use Listzen\Helpers\Fns as ThemeFns;
use ListzenCore\Helper\Fns;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;

trait PostTraits {


	/**
	 * Content Tab
	 *
	 * @param $this
	 *
	 * @return void
	 */
	protected function layout() {
		// widget title
		$this->start_controls_section(
			'listzen_post_grid',
			[
				'label' => esc_html__( 'Post Grid', 'listzen-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);


		$this->add_control(
			'layout',
			[
				'label'        => esc_html__( 'Choose Layout', 'listzen-core' ),
				'type'         => \Elementor\Controls_Manager::VISUAL_CHOICE,
				'label_block'  => true,
				'options'      => $this->grid_layout(),
				'default'      => 'grid-1',
				'columns'      => 2,
				'prefix_class' => 'layout-',
				'render_type'  => 'template',
			]
		);

		$this->add_responsive_control(
			'grid_column',
			[
				'label'          => esc_html__( 'Grid Column', 'listzen-core' ),
				'type'           => Controls_Manager::SELECT,
				'default'        => '',
				'tablet_default' => '',
				'mobile_default' => '',
				'options'        => Fns::column_list(),
			]
		);

		$this->add_control(
			'masonry_layout',
			[
				'label'        => esc_html__( 'Masonry Layout', 'listzen-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => false,
				'description'  => esc_html__( 'Masonry works only for front-end', 'listzen-core' ),
				'condition'    => [
					'layout' => [ 'grid-1' ],
				],
			]
		);


		$this->add_responsive_control(
			'alignment',
			[
				'label'     => __( 'Alignment', 'listzen-core' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => __( 'Left', 'listzen-core' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'listzen-core' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => __( 'Right', 'listzen-core' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .article-inner-wrapper' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'field_selection',
			[
				'label'     => __( 'Field Selection', 'listzen-core' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);


		$this->add_control(
			'thumbnail_visibility',
			[
				'label'        => esc_html__( 'Thumbnail Visibility', 'listzen-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'excerpt_visibility',
			[
				'label'        => esc_html__( 'Excerpt Visibility', 'listzen-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'meta_visibility',
			[
				'label'        => esc_html__( 'Meta Visibility', 'listzen-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			]
		);
		$this->add_control(
			'separate_meta_visibility',
			[
				'label'        => esc_html__( 'Separate Meta Visibility', 'listzen-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'readmore_visibility',
			[
				'label'        => esc_html__( 'Read More Visibility', 'listzen-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			]
		);


		$this->end_controls_section();
	}

	protected function query() {
		$this->start_controls_section(
			'listzen_post_grid_query',
			[
				'label' => esc_html__( 'Query', 'listzen-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$post_types     = Fns::get_post_types();
		$singlePostType = $post_types + [ 'current_query' => __( 'Current Query', 'listzen-core' ) ];

		$this->add_control(
			'post_type',
			[
				'label'     => esc_html__( 'Post Type', 'listzen-core' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => $singlePostType,
				'default'   => 'post',
				'condition' => [
					'multi_post_type!' => 'on',
				],
			]
		);
		$this->add_control(
			'post_limit',
			[
				'label'       => __( 'Post Per Page', 'listzen-core' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter Post Limit', 'listzen-core' ),
				'description' => __( 'Enter number of post to show.', 'listzen-core' ),
				'default'     => '12',
			]
		);

		$this->add_control(
			'category',
			[
				'type'                 => 'listzen-select2',
				'label'                => esc_html__( 'By Categories', 'listzen-core' ),
				'source_name'          => 'taxonomy',
				'source_type'          => 'category',
				'multiple'             => true,
				'label_block'          => true,
				'minimum_input_length' => 1,
			]
		);

		$this->add_control(
			'post_tag',
			[
				'type'                 => 'listzen-select2',
				'label'                => esc_html__( 'By Tags', 'listzen-core' ),
				'source_name'          => 'taxonomy',
				'source_type'          => 'post_tag',
				'multiple'             => true,
				'label_block'          => true,
				'minimum_input_length' => 1,
			]
		);

		$this->add_control(
			'tax_relation',
			[
				'label'   => __( 'Taxonomy Relation', 'listzen-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'OR'  => __( 'OR', 'listzen-core' ),
					'AND' => __( 'AND', 'listzen-core' ),
				],
				'default' => 'OR',
			]
		);

		$this->add_control(
			'offset',
			[
				'label'       => __( 'Post offset', 'listzen-core' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter Post offset', 'listzen-core' ),
				'description' => __( 'Number of post to displace or pass over. The offset parameter is ignored when post limit => -1 (show all posts) is used.', 'listzen-core' ),
			]
		);

		$this->add_control(
			'exclude',
			[
				'type'                 => 'listzen-select2',
				'label'                => __( 'Exclude posts', 'listzen-core' ),
				'description'          => __( 'Choose posts for exclude', 'listzen-core' ),
				'source_name'          => 'post',
				'source_type'          => 'post',
				'multiple'             => true,
				'label_block'          => true,
				'minimum_input_length' => 1,
			]
		);

		$this->add_control(
			'orderby',
			[
				'label'   => __( 'Order by', 'listzen-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
					'date'           => __( 'Date', 'listzen-core' ),
					'ID'             => __( 'Order by post ID', 'listzen-core' ),
					'author'         => __( 'Author', 'listzen-core' ),
					'title'          => __( 'Title', 'listzen-core' ),
					'modified'       => __( 'Last modified date', 'listzen-core' ),
					'parent'         => __( 'Post parent ID', 'listzen-core' ),
					'comment_count'  => __( 'Number of comments', 'listzen-core' ),
					'menu_order'     => __( 'Menu order', 'listzen-core' ),
					'meta_value'     => __( 'Meta value', 'listzen-core' ), // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
					'meta_value_num' => __( 'Meta value number', 'listzen-core' ),
					'rand'           => __( 'Random order', 'listzen-core' ),
				],
			]
		);

		$this->add_control(
			'order',
			[
				'label'   => __( 'Sort order', 'listzen-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => [
					'ASC'  => __( 'ASC', 'listzen-core' ),
					'DESC' => __( 'DESC', 'listzen-core' ),
				],
			]
		);

		$this->add_control(
			'ignore_sticky_posts',
			[
				'label'        => __( 'Ignore sticky post', 'listzen-core' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'On', 'listzen-core' ),
				'label_off'    => __( 'Off', 'listzen-core' ),
				'return_value' => 'on',
				'default'      => 'on',
			]
		);
		$this->end_controls_section();
	}


	/**
	 * Section Title
	 *
	 * @param $this
	 *
	 * @return void
	 */
	protected function section_title() {

		$this->start_controls_section(
			'section_title_settings',
			[
				'label'     => __( 'Section Title', 'listzen-core' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'section_title_visibility' => 'yes'
				]
			]
		);

		$this->add_control(
			'section_title',
			[
				'label'   => __( 'Enter Title', 'listzen-core' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Latest Post', 'listzen-core' ),
			]
		);

		$this->add_control(
			'section_title_tag',
			[
				'label'   => esc_html__( 'Title Tag', 'listzen-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'h3',
				'options' => [
					'h1' => esc_html__( 'H1', 'listzen-core' ),
					'h2' => esc_html__( 'H2', 'listzen-core' ),
					'h3' => esc_html__( 'H3', 'listzen-core' ),
					'h4' => esc_html__( 'H4', 'listzen-core' ),
					'h5' => esc_html__( 'H5', 'listzen-core' ),
					'h6' => esc_html__( 'H6', 'listzen-core' ),
				],
			]
		);

		$this->add_control(
			'section_title_link',
			[
				'label'         => __( 'Link', 'listzen-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'listzen-core' ),
				'show_external' => true,
				'dynamic'       => [
					'active' => true,
				],
				'default'       => [
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				],
			]
		);


		$this->end_controls_section();
	}

	/**
	 * Slider Settings
	 *
	 * @param $this
	 *
	 * @return void
	 */
	protected function slider_settings() {

		$this->start_controls_section(
			'slider_settings',
			[
				'label' => __( 'Slider Settigns', 'listzen-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'slider_column',
			[
				'label'          => esc_html__( 'Slider Column', 'listzen-core' ),
				'type'           => Controls_Manager::SELECT,
				'default'        => '',
				'tablet_default' => '',
				'mobile_default' => '',
				'options'        => Fns::slider_list(),
				'condition'      => [
					'fade!' => 'yes'
				]
			]
		);

		$this->add_control(
			'fade',
			[
				'label'   => esc_html__( 'Fade?', 'listzen-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'dots',
			[
				'label'   => esc_html__( 'Dots?', 'listzen-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'arrows',
			[
				'label'   => esc_html__( 'Arrows?', 'listzen-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'   => esc_html__( 'Autoplay?', 'listzen-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'adaptiveHeight',
			[
				'label'   => esc_html__( 'AdaptiveHeight?', 'listzen-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'infinite',
			[
				'label'   => esc_html__( 'Infinite?', 'listzen-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->add_control(
			'draggable',
			[
				'label'   => esc_html__( 'Draggable?', 'listzen-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);


		$this->add_control(
			'speed',
			[
				'label'   => __( 'speed', 'listzen-core' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 300,
			]
		);

		$this->add_control(
			'autoplaySpeed',
			[
				'label'   => __( 'autoplaySpeed', 'listzen-core' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 3000,
			]
		);


		$this->end_controls_section();
	}


	/**
	 * Thumbnail Settings
	 *
	 * @param $this
	 *
	 * @return void
	 */
	protected function thumbnail_settings() {

		$this->start_controls_section(
			'thumbnail_style',
			[
				'label'     => __( 'Thumbnail Style', 'listzen-core' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'thumbnail_visibility' => 'yes'
				]
			]
		);

		$this->add_control(
			'thumbnail_size',
			[
				'label'   => esc_html__( 'Image Size', 'listzen-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'large',
				'options' => Fns::image_size_lists(),
			]
		);

		$this->add_responsive_control(
			'image_height',
			[
				'label'      => __( 'Image Height Ratio', 'listzen-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 1,
						'max'  => 20,
						'step' => .5,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .post-thumbnail-wrap.post-grid .post-thumbnail' => 'aspect-ratio: 10 / {{SIZE}};',
				],
			]
		);

		$this->add_control(
			'thumb_box_radius',
			[
				'label'      => __( 'Thumbnail Radius', 'listzen-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .post-thumbnail-wrap .post-thumbnail, {{WRAPPER}} .post-thumbnail-wrap .post-thumbnail img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Start Icon Style Tab.
		$this->start_controls_tabs(
			'icon_style_tabs'
		);

		// Normal Style.
		$this->start_controls_tab(
			'icon_style_normal_tab',
			[
				'label' => __( 'Normal', 'listzen-core' ),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'           => 'overlay_bg',
				'fields_options' => [
					'background' => [
						'label' => esc_html__( 'Overlay Background', 'listzen-core' ),
					],
				],
				'types'          => [ 'classic', 'gradient' ],
				'selector'       => '{{WRAPPER}} .post-thumbnail-wrap .post-thumbnail::before',
			]
		);

		$this->end_controls_tab();

		// Hover Style
		$this->start_controls_tab(
			'icon_style_hover_tab',
			[
				'label' => __( 'Hover', 'listzen-core' ),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'           => 'overlay_bg_hover',
				'fields_options' => [
					'background' => [
						'label' => esc_html__( 'Overlay Background:hover', 'listzen-core' ),
					],
				],
				'types'          => [ 'classic', 'gradient' ],
				'selector'       => '{{WRAPPER}} .post-thumbnail-wrap .post-thumbnail::after',
			]
		);
		$this->end_controls_tab();

		$this->end_controls_tabs();
		// End Icon Style Tab.


		$this->end_controls_section();
	}

	/**
	 * Title Settings
	 *
	 * @param $this
	 *
	 * @return void
	 */
	protected function title_settings() {

		// Title Settings
		//=====================================================================
		$this->start_controls_section(
			'title_style',
			[
				'label' => __( 'Title Style', 'listzen-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);


		$this->add_control(
			'title_line_number',
			[
				'label'        => esc_html__( 'Title line number', 'listzen-core' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'full',
				'options'      => [
					'full'       => esc_html__( '-Select-', 'listzen-core' ),
					'one-line'   => esc_html__( 'One line', 'listzen-core' ),
					'tow-line'   => esc_html__( 'Tow line', 'listzen-core' ),
					'three-line' => esc_html__( 'Three line', 'listzen-core' ),
				],
				'prefix_class' => 'title-',
				'render_type'  => 'content'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .blog-post-card .entry-title',
			]
		);

		$this->add_control(
			'title_spacing',
			[
				'label'      => __( 'Title Spacing', 'listzen-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .blog-post-card .entry-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
				],
			]
		);

		$this->start_controls_tabs(
			'title_style_tabs'
		);

		$this->start_controls_tab(
			'title_normal_tab',
			[
				'label' => __( 'Normal', 'listzen-core' ),
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => __( 'Title Color', 'listzen-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .blog-post-card .entry-title a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'title_hover_tab',
			[
				'label' => __( 'Hover', 'listzen-core' ),
			]
		);

		$this->add_control(
			'title_hover_color',
			[
				'label'     => __( 'Title Hover Color', 'listzen-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .blog-post-card .entry-title a:hover' => 'color: {{VALUE}} !important',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Excerpt Settings
	 *
	 * @param $this
	 *
	 * @return void
	 */
	protected function excerpt_settings() {
		// Content Settings
		//=====================================================================

		$this->start_controls_section(
			'content_style',
			[
				'label'     => __( 'Excerpt Style', 'listzen-core' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'excerpt_visibility' => 'yes'
				]
			]
		);

		$this->add_control(
			'content_limit',
			[
				'label'   => __( 'Excerpt Limit', 'listzen-core' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '15',
			]
		);

		$this->add_control(
			'excerpt_more',
			[
				'label'   => __( 'Excerpt Ending Text', 'listzen-core' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '...',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'content_typography',
				'selector' => '{{WRAPPER}} .article-inner-wrapper .entry-content',
			]
		);

		$this->add_control(
			'content_spacing',
			[
				'label'      => __( 'Excerpt Spacing', 'listzen-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .article-inner-wrapper .entry-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'content_color',
			[
				'label'     => __( 'Content Color', 'listzen-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .article-inner-wrapper .entry-content' => 'color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Meta Settings
	 *
	 * @param $this
	 *
	 * @return void
	 */
	protected function meta_settings() {


		$this->start_controls_section(
			'meta_info_style',
			[
				'label'     => __( 'Meta Settings', 'listzen-core' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'meta_visibility' => 'yes'
				]
			]
		);

		$this->add_control(
			'meta_list',
			[
				'label'       => __( 'Choose Meta', 'listzen-core' ),
				'type'        => Controls_Manager::SELECT2,
				'multiple'    => true,
				'options'     => ThemeFns::blog_meta_list(),
				'label_block' => true,
				'default'     => [ 'author', 'date' ],
				'description' => __( 'Select post meta.', 'listzen-core' ),
			]
		);

		$this->add_control(
			'separate_meta_list',
			[
				'label'       => __( 'Choose Separate Meta', 'listzen-core' ),
				'type'        => Controls_Manager::SELECT2,
				'multiple'    => true,
				'options'     => ThemeFns::blog_meta_list(),
				'label_block' => true,
				'default'     => [ 'category' ],
				'description' => __( 'Select post meta.', 'listzen-core' ),
			]
		);

		$this->add_control(
			'meta_style',
			[
				'label'       => __( 'Meta Style', 'listzen-core' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => ThemeFns::meta_style(),
				'default'     => 'meta-style-default',
				'render_type' => 'template',
				'description' => __( 'Select post meta.', 'listzen-core' ),
			]
		);

		$this->add_control(
			'author_avatar',
			[
				'label'   => esc_html__( 'Author Avatar', 'listzen-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => false,
			]
		);
		$this->add_control(
			'author_prefix',
			[
				'label' => esc_html__( 'Author Prefix', 'listzen-core' ),
				'type'  => Controls_Manager::TEXT,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'post_meta_typography',
				'selector' => '{{WRAPPER}} .blog-post-meta',
			]
		);


		$this->start_controls_tabs(
			'post_meta_style_tabs'
		);

		$this->start_controls_tab(
			'post_meta_normal_tab',
			[
				'label' => __( 'Normal', 'listzen-core' ),
			]
		);


		$this->add_control(
			'meta_color',
			[
				'label'     => __( 'Meta Color', 'listzen-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .blog-post-meta' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'meta_link_color',
			[
				'label'     => __( 'Meta Link Color', 'listzen-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .blog-post-meta a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'meta_icon_color',
			[
				'label'     => __( 'Meta Icon Color', 'listzen-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .blog-post-meta i' => 'color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'post_meta_hover_tab',
			[
				'label' => __( 'Hover', 'listzen-core' ),
			]
		);

		$this->add_control(
			'link_hover_color',
			[
				'label'     => __( 'Meta Color:hover', 'listzen-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .blog-post-meta a:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Read More Settings
	 *
	 * @param $this
	 *
	 * @return void
	 */
	protected function readmore_settings() {

		//Read More Style
		//====================

		$this->start_controls_section(
			'readmore_style',
			[
				'label'     => __( 'Read More Style', 'listzen-core' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'readmore_visibility' => 'yes'
				]
			]
		);


		$this->add_control(
			'readmore_text',
			[
				'label'       => __( 'Button Text', 'listzen-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Read More', 'listzen-core' ),
				'placeholder' => __( 'Type your title here', 'listzen-core' ),
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'readmore_typography',
				'selector' => '{{WRAPPER}} .blog-post-card .entry-footer .btn',
			]
		);

		$this->add_control(
			'readmore_spacing',
			[
				'label'      => __( 'Button Spacing', 'listzen-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .blog-post-card .entry-footer' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'readmore_padding',
			[
				'label'      => __( 'Button Padding', 'listzen-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .blog-post-card .entry-footer .btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->add_control(
			'btn_border_radius',
			[
				'label'      => __( 'Border Radius', 'listzen-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .blog-post-card .entry-footer .btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'show_btn_icon',
			[
				'label'        => __( 'Show Button Icon', 'listzen-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'listzen-core' ),
				'label_off'    => __( 'Hide', 'listzen-core' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		//Button style Tabs
		$this->start_controls_tabs(
			'readmore_style_tabs'
		);

		$this->start_controls_tab(
			'readmore_style_normal_tab',
			[
				'label' => __( 'Normal', 'listzen-core' ),
			]
		);

		$this->add_control(
			'readmore_color',
			[
				'label'     => __( 'Text Color', 'listzen-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .blog-post-card .entry-footer .btn' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label'     => __( 'Icon Color', 'listzen-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .blog-post-card .entry-footer .btn :is(i, svg)' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'readmore_bg',
			[
				'label'     => __( 'Background Color', 'listzen-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .blog-post-card .entry-footer .btn' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'readmore_style_hover_tab',
			[
				'label' => __( 'Hover', 'listzen-core' ),
			]
		);

		$this->add_control(
			'readmore_color_hover',
			[
				'label'     => __( 'Text Color:hover', 'listzen-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .blog-post-card .entry-footer .btn:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'icon_color_hover',
			[
				'label'     => __( 'Icon Color:hover', 'listzen-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .blog-post-card .entry-footer .btn:hover :is(i, svg)' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'readmore_bg_hover',
			[
				'label'     => __( 'Background Color:hover', 'listzen-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .blog-post-card .entry-footer .btn:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();
		$this->end_controls_section();

	}

	/**
	 * Post Card Styles
	 *
	 * @param $this
	 *
	 * @return void
	 */
	protected function post_card_settings() {
		$this->start_controls_section(
			'post_card_style',
			[
				'label' => __( 'Post Card Style', 'listzen-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'           => 'card_bg',
				'selector'       => '{{WRAPPER}} .article-inner-wrapper',
				'types'          => [ 'classic', 'gradient' ],
				'exclude'        => [ 'image' ], // phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_exclude
				'fields_options' => [
					'background' => [
						'label' => esc_html__( 'Card Background', 'listzen-core' ),
					],
					'color'      => [
						'label' => 'Background Color',
					],
					'color_b'    => [
						'label' => 'Background Color 2',
					],
				],
			]
		);


		$this->add_responsive_control(
			'card_padding',
			[
				'label'      => __( 'Card Padding', 'listzen-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .article-inner-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
			]
		);

		$this->add_responsive_control(
			'content_padding',
			[
				'label'      => __( 'Content Padding', 'listzen-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .article-inner-wrapper .entry-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'box_shadow',
				'label'    => __( 'Box Shadow', 'listzen-core' ),
				'selector' => '{{WRAPPER}} .article-inner-wrapper',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'button_border',
				'label'    => __( 'Border', 'listzen-core' ),
				'selector' => '{{WRAPPER}} .article-inner-wrapper',
			]
		);

		$this->add_control(
			'main_box_radius',
			[
				'label'      => __( 'Border Radius', 'listzen-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .article-inner-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}


	/**
	 * Grid Layout
	 *
	 * @return array[]
	 */
	protected function grid_layout() {
		return [
			'grid-1' => [
				'title' => esc_html__( 'Layout 2', 'listzen-core' ),
				'image' => esc_url( Fns::get_assets_url( 'images/layout/grid-1.svg' ) ),
			],
			'grid-2' => [
				'title' => esc_html__( 'Layout 2', 'listzen-core' ),
				'image' => esc_url( Fns::get_assets_url( 'images/layout/grid-2.svg' ) ),
			],
			'list-1' => [
				'title' => esc_html__( 'Layout 3', 'listzen-core' ),
				'image' => esc_url( Fns::get_assets_url( 'images/layout/list-1.svg' ) ),
			],
		];
	}
}