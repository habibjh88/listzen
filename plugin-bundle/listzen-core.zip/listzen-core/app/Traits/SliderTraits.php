<?php
/**
 * SliderTraits
 */

namespace ListzenCore\Traits;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Box_Shadow;

trait SliderTraits {


	protected function slider_settings() {
		$this->start_controls_section(
			'slider_settings',
			[
				'label' => __( 'Slider Settings', 'listzen-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'fade',
			[
				'label'        => esc_html__( 'Fade?', 'listzen-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => false,
				'return_value' => 'yes',
				'description'  => esc_html__( 'This option works only for the single column.', 'listzen-core' ),
			]
		);

		$this->add_control( 'spaceBetween', [
			'label'   => __( 'spaceBetween', 'listzen-core' ),
			'type'    => Controls_Manager::NUMBER,
			'min'     => 0,
			'max'     => 100,
			'step'    => 1,
			'default' => 30,
		] );

		$this->add_control(
			'direction',
			[
				'label'     => esc_html__( 'Direction', 'listzen-core' ),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 'horizontal',
				'condition' => [
					'fade!' => 'yes',
				],
				'options'   => [
					'horizontal' => esc_html__( 'Horizontal', 'listzen-core' ),
					'vertical'   => esc_html__( 'Vertical', 'listzen-core' ),
				],
			]
		);

		$this->add_responsive_control(
			'slider_height',
			[
				'label'      => esc_html__( 'Height', 'listzen-core' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 2000,
						'step' => 5,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 400,
				],
				'condition'  => [
					'direction' => 'vertical',
				],
				'selectors'  => [
					'{{WRAPPER}} .listzen-testimonial-slider .swiper-vertical .swiper-wrapper' => 'height: {{SIZE}}px !important;',
				],
			]
		);

		$this->add_control(
			'dots',
			[
				'label'        => esc_html__( 'Dots?', 'listzen-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
				'prefix_class' => 'slider-dot-',
			]
		);

		$this->add_control(
			'dynamicBullets',
			[
				'label'        => esc_html__( 'DynamicBullets?', 'listzen-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
				'condition'    => [
					'dots' => 'yes',
				],
			]
		);


		$this->add_control(
			'arrows',
			[
				'label'        => esc_html__( 'Arrows?', 'listzen-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
				'render_type'  => 'template',
				'prefix_class' => 'slider-arrow-',
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'        => esc_html__( 'Autoplay?', 'listzen-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'autoplaySpeed',
			[
				'label'     => __( 'autoplaySpeed', 'listzen-core' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 3000,
				'condition' => [
					'autoplay' => 'yes',
				]
			]
		);

		$this->add_control(
			'adaptiveHeight',
			[
				'label'        => esc_html__( 'AdaptiveHeight?', 'listzen-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'infinite',
			[
				'label'        => esc_html__( 'Infinite?', 'listzen-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			]
		);
		$this->add_control(
			'draggable',
			[
				'label'        => esc_html__( 'Draggable?', 'listzen-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'speed',
			[
				'label'   => __( 'speed', 'listzen-core' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 300,
			]
		);


		$this->end_controls_section();

	}

	/**
	 * Slider Settings
	 *
	 * @param $this
	 *
	 * @return void
	 */
	protected function slider_style() {

		$this->start_controls_section(
			'slider_style',
			[
				'label' => __( 'Slider Style', 'listzen-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'arrow_style',
			[
				'label'     => __( 'Arrow Style', 'listzen-core' ),
				'type'      => Controls_Manager::HEADING,
				'condition' => [
					'arrows' => 'yes'
				]
			]
		);

		$this->add_control(
			'arrow_position',
			[
				'label'        => esc_html__( 'Arrow Position', 'listzen-core' ),
				'type'         => Controls_Manager::SELECT,
				'options'      => [
					'default'      => esc_html__( 'Center Inside', 'listzen-core' ),
					'outside'      => esc_html__( 'Center Outside', 'listzen-core' ),
					'top-left'     => esc_html__( 'Top Left', 'listzen-core' ),
					'top-center'   => esc_html__( 'Top Center', 'listzen-core' ),
					'top-right'    => esc_html__( 'Top Right', 'listzen-core' ),
					'center-right' => esc_html__( 'Center Right', 'listzen-core' ),
				],
				'prefix_class' => 'arrow-',
				'render_type'  => 'template',
				'default'      => 'default',
				'condition'    => [
					'arrows'    => 'yes',
					'direction' => 'horizontal',
				]
			]
		);


		$this->add_responsive_control(
			'arrow_size',
			[
				'label'      => __( 'Arrow Size', 'listzen-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 30,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .listzen-testimonial-slider .swiper-arrow'         => '--arrowBtnWidth: {{SIZE}}px;',
					'{{WRAPPER}} .listzen-testimonial-slider .swiper-arrow::before' => 'transform: scale(calc(({{SIZE}} * 0.8) / 50));',
				],
				'condition'  => [
					'arrows' => 'yes'
				]
			]
		);


		$this->add_responsive_control(
			'arrow_radius',
			[
				'label'      => __( 'Border Radius', 'listzen-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .listzen-testimonial-slider .swiper-arrow' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
				'condition'  => [
					'arrows' => 'yes'
				]
			]
		);
		$this->start_controls_tabs(
			'arrow_tabs', [
				'condition' => [
					'arrows' => 'yes'
				]
			]
		);

		$this->start_controls_tab(
			'arrow_normal_tab',
			[
				'label' => __( 'Normal', 'listzen-core' ),
			]
		);

		$this->add_control(
			'arrow_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Arrow Color', 'listzen-core' ),
				'selectors' => [
					'{{WRAPPER}} .listzen-testimonial-slider .swiper-arrow' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'arrow_bg',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Arrow Background', 'listzen-core' ),
				'selectors' => [
					'{{WRAPPER}} .listzen-testimonial-slider .swiper-arrow' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'arrow_box_shadow',
				'selector' => '{{WRAPPER}} .listzen-testimonial-slider .swiper-arrow',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name'     => 'arrow_border',
				'label'    => __( 'Icon Border', 'listzen-core' ),
				'selector' => '{{WRAPPER}} .listzen-testimonial-slider .swiper-arrow',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'arrow_hover_tab',
			[
				'label' => __( 'Hover', 'listzen-core' ),
			]
		);

		$this->add_control(
			'arrow_color_h',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Arrow Color:hover', 'listzen-core' ),
				'selectors' => [
					'{{WRAPPER}} .listzen-testimonial-slider .swiper-arrow:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'arrow_bg_h',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Arrow Background:hover', 'listzen-core' ),
				'selectors' => [
					'{{WRAPPER}} .listzen-testimonial-slider .swiper-arrow:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'arrow_box_shadow_hover',
				'selector' => '{{WRAPPER}} .listzen-testimonial-slider .swiper-arrow:hover',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name'     => 'arrow_border_hover',
				'label'    => __( 'Icon Border:hover', 'listzen-core' ),
				'selector' => '{{WRAPPER}} .listzen-testimonial-slider .swiper-arrow',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'dots_style',
			[
				'label'     => __( 'Dots Style', 'listzen-core' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'dots' => 'yes'
				]
			]
		);

		$this->add_control(
			'dot_layout',
			[
				'label'        => esc_html__( 'Layout', 'listzen-core' ),
				'type'         => \Elementor\Controls_Manager::SELECT,
				'default'      => '1',
				'options'      => [
					'1' => esc_html__( 'Layout 1', 'listzen-core' ),
					'2' => esc_html__( 'Layout 2', 'listzen-core' ),
				],
				'prefix_class' => 'dots-layout-',
				'render_type'  => 'template',
				'condition'    => [
					'dynamicBullets!' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'dots_size',
			[
				'label'      => __( 'Dots Size', 'listzen-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 5,
						'max' => 40,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .listzen-testimonial-slider .swiper-pagination-bullet' => '--swiper-pagination-bullet-size: {{SIZE}}px;',
				],
				'condition'  => [
					'dots' => 'yes'
				]
			]
		);


		$this->add_responsive_control(
			'dots_radius',
			[
				'label'      => __( 'Border Radius', 'listzen-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .listzen-testimonial-slider .swiper-pagination-bullet' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
				'condition'  => [
					'dots' => 'yes'
				]
			]
		);

		$this->add_control(
			'dots_bg_active',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Dots Active', 'listzen-core' ),
				'selectors' => [
					'{{WRAPPER}} .listzen-testimonial-slider .swiper-pagination-bullet' => '--swiper-dots-active-color: {{VALUE}};',
				],
				'condition' => [
					'dots' => 'yes'
				]
			]
		);

		$this->add_control(
			'dots_bg',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Dots Color', 'listzen-core' ),
				'selectors' => [
					'{{WRAPPER}} .listzen-testimonial-slider .swiper-pagination-bullet' => '--swiper-dots-color: {{VALUE}};',
				],
				'condition' => [
					'dots' => 'yes'
				]
			]
		);


		$this->end_controls_section();
	}

}