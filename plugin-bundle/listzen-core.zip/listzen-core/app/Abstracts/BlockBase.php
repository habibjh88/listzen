<?php
/**
 * Abstract base class for all Listzen Gutenberg blocks.
 *
 * @package ListzenCore\Abstracts
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Abstracts;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BlockBase
 *
 * Defines the required structure for any Gutenberg block implementation.
 */
abstract class BlockBase {

	/**
	 * Returns the block's attribute definitions.
	 *
	 * @return array<string, array{type: string, default: mixed}>
	 */
	abstract public function get_attributes();

	/**
	 * Registers the block type with WordPress.
	 *
	 * @return void
	 */
	abstract public function register_blocks();

	/**
	 * Renders the block output on the front-end.
	 *
	 * @param array $data Block attributes passed from the frontend/editor.
	 *
	 * @return string Rendered HTML.
	 */
	abstract public function render_block( $data );
}