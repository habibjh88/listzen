<?php
/**
 * Base class for Listzen Elementor widgets.
 *
 * @package ListzenCore\Abstracts
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Abstracts;

use Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class ElementorBase
 *
 * Abstract base class to standardize Listzen Elementor widgets.
 */
abstract class ElementorBase extends Widget_Base {

	/**
	 * Widget display name.
	 *
	 * @var string
	 */
	public $listzen_name;

	/**
	 * Unique widget identifier (slug).
	 *
	 * @var string
	 */
	public $listzen_base;

	/**
	 * Widget category slug.
	 *
	 * @var string
	 */
	public $listzen_category;

	/**
	 * Icon class for the Elementor editor.
	 *
	 * @var string
	 */
	public $listzen_icon;

	/**
	 * Whether the widget supports translation.
	 *
	 * @var bool
	 */
	public $listzen_translate;

	/**
	 * ElementorBase constructor.
	 *
	 * @param array $data Optional widget data.
	 * @param array|null $args Optional widget arguments.
	 */
	public function __construct( $data = [], $args = null ) {
		$this->listzen_category = LISTZEN_CORE_PREFIX . '-widgets';
		$this->listzen_icon     = 'rdtheme-el-custom';

		parent::__construct( $data, $args );
	}

	/**
	 * Returns the widget's unique name/slug.
	 *
	 * @return string
	 */
	public function get_name() {
		return $this->listzen_base;
	}

	/**
	 * Returns the widget's display title.
	 *
	 * @return string
	 */
	public function get_title() {
		return $this->listzen_name;
	}

	/**
	 * Returns the widget's icon class for Elementor UI.
	 *
	 * @return string
	 */
	public function get_icon() {
		return $this->listzen_icon;
	}

	/**
	 * Returns the category/categories the widget belongs to.
	 *
	 * @return string[]
	 */
	public function get_categories() {
		return [ $this->listzen_category ];
	}
}