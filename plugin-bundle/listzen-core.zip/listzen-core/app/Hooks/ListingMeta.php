<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Hooks;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use ListzenCore\Traits\SingletonTraits;

class ListingMeta {
    use SingletonTraits;

    public function __construct() {
        add_action( 'init', [ $this, 'register_meta_field' ] );
        /**
         * This actions needs to for share same gallery for multiple listings
         */
        // add_action( 'add_meta_boxes', [ $this, 'conditionally_add_meta_box' ] );
        // add_action( 'save_post_rtcl_listing', [ $this, 'save_gallery_meta' ] );
    }

    public function register_meta_field() {
        register_post_meta(
                'rtcl_listing',
                'rtcl_share_gallery',
                [
                        'type'              => 'string',
                        'single'            => true,
                        'show_in_rest'      => true,
                        'sanitize_callback' => 'sanitize_text_field',
                        'auth_callback'     => function () {
                            return current_user_can( 'edit_posts' );
                        },
                ]
        );

        register_post_meta(
                'rtcl_listing',
                'rtcl_custom_thumb',
                [
                        'type'              => 'integer',
                        'single'            => true,
                        'show_in_rest'      => true,
                        'sanitize_callback' => 'absint',
                        'auth_callback'     => function () {
                            return current_user_can( 'edit_posts' );
                        },
                ]
        );
    }

    public function conditionally_add_meta_box() {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if ( is_admin() && isset( $_GET['rtcl-gallery'] ) && $_GET['rtcl-gallery'] == '1' ) {
            add_meta_box(
                    'rtcl_gallery_share_meta',
                    __( 'Share Gallery With Listing', 'listzen-core' ),
                    [ $this, 'render_rtcl_gallery_share_meta_box' ],
                    'rtcl_listing',
                    'side',
                    'default'
            );
        }
    }

    public function render_rtcl_gallery_share_meta_box( $post ) {
        // Nonce for security
        wp_nonce_field( 'rtcl_save_gallery_meta', 'rtcl_gallery_meta_nonce' );

        $value    = get_post_meta( $post->ID, 'rtcl_share_gallery', true );
        $thumb_id = get_post_meta( $post->ID, 'rtcl_custom_thumb', true );
        ?>
        <p>
            <label for="rtcl_share_gallery"><?php esc_html_e( 'Listing Id (where from share)', 'listzen-core' ); ?></label>
            <input type="text" name="rtcl_share_gallery" id="rtcl_share_gallery" value="<?php echo esc_attr( $value ); ?>" style="width: 100%;"/>
        </p>
        <p>
            <label for="rtcl_custom_thumb"><?php esc_html_e( 'Attachment ID for thumbnail', 'listzen-core' ); ?></label>
            <input type="number" name="rtcl_custom_thumb" id="rtcl_custom_thumb" value="<?php echo esc_attr( $thumb_id ); ?>" style="width: 100%;"/>
        </p>
        <?php
    }

    public function save_gallery_meta( $post_id ) {
        // Bail out if this is an autosave
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        // Verify nonce
        if (
                ! isset( $_POST['rtcl_gallery_meta_nonce'] ) ||
                ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['rtcl_gallery_meta_nonce'] ) ), 'rtcl_save_gallery_meta' )
        ) {
            return;
        }

        // Check user capability
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        // Save gallery URLs
        if ( isset( $_POST['rtcl_share_gallery'] ) ) {
            update_post_meta( $post_id, 'rtcl_share_gallery', sanitize_text_field( wp_unslash( $_POST['rtcl_share_gallery'] ) ) );
        }

        // Save custom thumbnail ID and set as featured image
        if ( isset( $_POST['rtcl_custom_thumb'] ) ) {
            $attach_id = absint( $_POST['rtcl_custom_thumb'] );
            update_post_meta( $post_id, 'rtcl_custom_thumb', $attach_id );

            if ( $attach_id > 0 ) {
                set_post_thumbnail( $post_id, $attach_id );
            } else {
                delete_post_thumbnail( $post_id );
            }
        }
    }
}