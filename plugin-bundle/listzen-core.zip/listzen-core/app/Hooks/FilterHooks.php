<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Hooks;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Listzen\Modules\Svg;
use ListzenCore\Traits\SingletonTraits;

class FilterHooks {
	use SingletonTraits;


	public function __construct() {
		//Add user contact info
		add_filter( 'the_password_form', [ __CLASS__, 'post_password_form' ] );
		add_filter( 'upload_mimes', [ $this, 'mime_types_support' ] );
		add_filter( 'wp_head', [ __CLASS__, 'set_post_view_count' ], 9999 );
	}


	/*
	 * change post password from
	 */

	public static function post_password_form() {
		global $post;

		$label = 'pwbox-' . ( empty( $post->ID ) ? wp_rand() : $post->ID );

		$output = '<form action="' . esc_url( home_url( 'wp-login.php?action=postpass', 'login_post' ) ) . '"';
		$output .= ' class="post-password-form" method="post">';
		$output .= '<p>' . __( 'This content is password protected. To view it please enter your password below:', 'listzen-core' ) . '</p>';
		$output .= '<p>';
		$output .= '<label for="' . esc_attr( $label ) . '">';
		$output .= '<span class="pass-label">' . __( 'Password:', 'listzen-core' ) . ' </span>';
		$output .= '<input name="post_password" id="' . esc_attr( $label ) . '" type="password" size="20" />';
		$output .= ' <input type="submit" name="Submit" value="' . esc_attr_x( 'Enter', 'post password form', 'listzen-core' ) . '" />';
		$output .= '</label>';
		$output .= '</p>';
		$output .= '</form>';

		return $output;
	}

	/**
	 * Enable svg upload
	 *
	 * @param $mimes
	 *
	 * @return mixed
	 */
	function mime_types_support( $mimes ) {
		if ( ! listzen_option( 'listzen_svg_enable' ) ) {
			return $mimes;
		}
		$mimes['svg'] = 'image/svg+xml';

		return $mimes;
	}

	/**
	 * Set view count
	 *
	 * @param string $content Content.
	 *
	 * @return string
	 */
	public static function set_post_view_count( $content ) {
		if ( is_single() ) {
			$post_id = get_the_ID();


			if ( ! $post_id && is_admin() ) {
				return $content;
			}


			$user_ip = ! empty( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'noip'; // retrieve the current IP address of the visitor.
			$key     = 'listzen_cache_' . $user_ip . '_' . $post_id;
			$value   = [ $user_ip, $post_id ];
			$visited = get_transient( $key );

			if ( false === $visited ) {
				// set_transient( $key, $value, HOUR_IN_SECONDS * 12 ); // store the unique key, Post ID & IP address for 12 hours if it does not exist.
				set_transient( $key, $value, HOUR_IN_SECONDS * 12 ); // store the unique key, Post ID & IP address for 12 hours if it does not exist.

				// now run post views function.
				$count_key = listzen_utils( 'post_view_key' );
				$count     = get_post_meta( $post_id, $count_key, true );

				if ( '' == $count ) {
					update_post_meta( $post_id, $count_key, 1 );
				} else {
					$count = absint( $count );
					$count ++;

					update_post_meta( $post_id, $count_key, $count );
				}
			}
		}

		return $content;
	}

}