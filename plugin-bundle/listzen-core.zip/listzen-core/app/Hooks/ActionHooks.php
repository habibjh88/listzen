<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Hooks;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use ListzenCore\Traits\SingletonTraits;
use Rtcl\Helpers\Functions;

class ActionHooks {
    use SingletonTraits;

    public function __construct() {
        add_action( 'init', [ __CLASS__, '__init' ] );
        add_action( 'after_setup_theme', [ $this, 'remove_admin_bar' ], 999 );
        add_action( 'wp_head', [ $this, 'wp_head_script' ], 0 );
        // Enqueue custom script only on single rtcl-listing
        add_action( 'wp_footer', [ $this, 'footer_script' ] );
        add_action( 'admin_footer', [ $this, 'admin_footer_script' ] );
    }

    public static function __init() {
        if ( ! listzen_option( 'listzen_image_srcset' ) ) {
            add_filter( 'wp_calculate_image_srcset_meta', '__return_false' );
        }
    }

    //Remove admin bar
    public function remove_admin_bar() {
        if ( listzen_option( 'listzen_remove_admin_bar' ) && ! current_user_can( 'administrator' ) && ! is_admin() ) {
            show_admin_bar( false );
        }
    }

    public function wp_head_script() {
        ?>
        <style>
            .rtcl-ajax-filter-wrap {
                opacity: 0;
                transition: opacity 1s;
            }
        </style>
        <?php
    }

    public static function footer_script() {
        if ( is_singular( 'rtcl_listing' ) ) {
            ?>
            <script type="text/javascript">
                jQuery(document).ready(function ($) {
                    var $form = $("#rtcl-contact-form");
                    var $checkbox = $("#rtcl-terms-condition");

                    if ($form.length && $checkbox.length) {
                        $form.on("submit", function (e) {
                            if (!$checkbox.is(":checked")) {
                                e.preventDefault();
                                $checkbox.focus();
                                $checkbox.parent().addClass("shake");
                            }
                        });
                    }
                });
            </script>
            <?php
        }
    }

    public static function admin_footer_script() {
        ?>
        <style>
            .rtcl-checkbox-group.horizontal {
                display: grid;
                gap: 5px;

                @media (min-width: 600px) {
                    grid-template-columns: 1fr 1fr;
                }
                @media (min-width: 1200px) {
                    grid-template-columns: 1fr 1fr 1fr;
                }
            }
        </style>
        <?php
    }
}