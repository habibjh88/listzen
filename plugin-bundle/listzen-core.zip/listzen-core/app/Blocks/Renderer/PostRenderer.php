<?php
/**
 * Class PostRenderer
 *
 * Renders the post layout for the Listzen Gutenberg block based on passed attributes.
 * Handles WP_Query setup, post metadata display, content rendering, and output buffering.
 *
 * @package ListzenCore\Blocks\Renderer
 */

namespace ListzenCore\Blocks\Renderer;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
use ListzenCore\Helper\Fns;
use ListzenCore\Traits\SingletonTraits;
use Listzen\Modules\PostMeta;
use Listzen\Modules\Thumbnail;
use Listzen\Helpers\Fns as ThemeFns;

/**
 * Class PostRenderer
 */
class PostRenderer {
	use SingletonTraits;

	/**
	 * Block attributes from the editor.
	 *
	 * @var array
	 */
	private $attributes;

	/**
	 * WordPress Query object.
	 *
	 * @var \WP_Query
	 */
	private $query;

	/**
	 * PostRenderer constructor.
	 *
	 * @param array $attributes Block attributes passed from the editor.
	 */

	public function __construct( $attributes ) {
		$this->attributes = $attributes;
		$this->setup_query();
	}

	/**
	 * Sets up WP_Query arguments based on block attributes.
	 *
	 * @return void
	 */
	private function setup_query() {
		$attributes     = $this->attributes;
		$post_type      = sanitize_text_field( $attributes['postType'] ?? 'post' );
		$posts_per_page = intval( $attributes['postsPerPage'] ?? 4 );
		$orderby        = sanitize_text_field( $attributes['orderBy'] ?? 'date' );
		$order          = sanitize_text_field( $attributes['order'] ?? 'DESC' );
		$post_id        = ! empty( $attributes['postId'] ) ? explode( ',', $attributes['postId'] ) : [];
		$quick_query    = sanitize_text_field( $attributes['quickQuery'] ?? '' );

		$args = [
			'post_type'          => $post_type,
			'posts_per_page'     => $posts_per_page,
			'ignore_sticky_posts' => 1,
		];

		if ( $orderby ) {
			$args['orderby'] = $orderby;
		}

		if ( $order ) {
			$args['order'] = $order;
		}

		if ( $quick_query ) {
			$args = Fns::get_quick_query( $quick_query, $args );
		}

		if ( ! empty( $post_id ) ) {
			$ids = array_filter( array_map( 'intval', explode( ',', $post_id ) ) );
			if ( ! empty( $ids ) ) {
				$args['post__in'] = $ids;
				$args['orderby']  = 'post__in';
			}
		}

		$this->query = new \WP_Query( $args );
	}

	/**
	 * Builds the class list for the post container.
	 *
	 * @return string Compiled CSS classes.
	 */
	private function post_clsss() {
		$layout              = 'layout-' . $this->attributes['layout'];
		$blog_meta_style     = 'meta-style-default';//listzen_option( 'listzen_blog_meta_style' );
		$different_cat_color = listzen_option( 'listzen_different_category_color' );
		$cat_class           = $different_cat_color ? 'cat-different-color' : '';

		return ThemeFns::class_list( [
			'listzen-post-card blog-list is-above-meta col-lg-12',
			$layout,
			$cat_class,
			$blog_meta_style
		] );
	}

	/**
	 * Determines which metadata to include based on attributes.
	 *
	 * @return array|false Array of metadata keys or false if none.
	 */
	private function meta_include() {
		$metaMap = [
			'showMetaUser' => 'author',
			'showMetaDate' => 'date',
			'showMetaCat'  => 'category',
		];

		$metaInclude = [];

		foreach ( $metaMap as $key => $value ) {
			if ( isset( $this->attributes[ $key ] ) && $this->attributes[ $key ] === 'on' ) {
				$metaInclude[] = $value;
			}
		}

		return empty( $metaInclude ) ? false : $metaInclude;
	}

	/**
	 * Renders the individual post article markup.
	 *
	 * @return void
	 */
	private function render_article() {


		$size           = $this->attributes['imageSize'] ?? 'large';
		$show_thumbnail = $this->attributes['showThumbnail'] ?? '';
		$show_content   = $this->attributes['showContent'] ?? '';
		$show_category  = $this->attributes['showCategory'] ?? '';
		$content_limit  = $this->attributes['contentLimit'] ?? 15;
		?>
        <article
                data-post-id="<?php the_ID(); ?>" <?php post_class( $this->post_clsss() ); ?>>
            <div class="article-inner-wrapper">

				<?php
				if ( 'on' === $show_thumbnail ) {
					Thumbnail::get_thumbnail( $size );
				}
				?>

                <div class="entry-wrapper">
                    <header class="entry-header">
						<?php
						if ( 'on' === $show_category ) {
							listzen_separate_meta( $this->attributes['postType'], [ 'category' ] );
						}

						the_title( sprintf( '<h3 class="entry-title default-max-width"><a href="%s">', esc_url( get_permalink() ) ), '</a></h3>' );
						?>
                    </header>
					<?php

					if ( $this->meta_include() ) {
						PostMeta::get_meta( $this->attributes['postType'], [
							'with_icon' => boolval( $this->attributes['showMetaIcon'] ),
							'include'   => $this->meta_include(),
						] );
					}

					if ( 'on' === $show_content ) : ?>
                        <div class="entry-content">
							<?php listzen_entry_content( $content_limit ) ?>
                        </div>
					<?php endif; ?>
                </div>
            </div>
        </article>
		<?php
	}


	/**
	 * Renders the final HTML output for the block.
	 *
	 * @return string HTML output of the block.
	 */
	public function render() {
		ob_start();
		if ( $this->query->have_posts() ) {
			echo "<div class='listzen-post-widget'>";
			while ( $this->query->have_posts() ) {
				$this->query->the_post();
				$this->render_article();
			}
			echo "</div>";
		} else {
			echo '<p>' . esc_html__( "No posts found.", "listzen-core" ) . '</p>';
		}

		wp_reset_postdata();

		return ob_get_clean();
	}
}