<?php

namespace ListzenCore\Blocks;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use ListzenCore\Blocks\Renderer\PostRenderer;
use ListzenCore\Traits\SingletonTraits;
use ListzenCore\Abstracts\BlockBase;

/**
 * Class PostGrid
 *
 * Handles registration and rendering of the "listzen/post-block" Gutenberg block.
 */
class PostGrid extends BlockBase {
	/**
	 * Include Singleton trait to ensure a single instance.
	 */
	use SingletonTraits;

	/**
	 * PostGrid constructor.
	 *
	 * Hooks into WordPress 'init' action to register the block.
	 */
	public function __construct() {
		add_action( 'init', [ $this, 'register_blocks' ] );
	}

	/**
	 * Registers the custom Gutenberg block with render callback and attributes.
	 *
	 * @return void
	 */
	public function register_blocks() {
		if ( ! function_exists( 'register_block_type' ) ) {
			return;
		}
		register_block_type(
			'listzen/post-block',
			[
				'attributes'      => $this->get_attributes(),
				'render_callback' => [ $this, 'render_block' ],
			]
		);
	}


	/**
	 * Returns the list of attributes used by the block.
	 *
	 * @return array<string, array{type: string, default: mixed}>
	 */
	public function get_attributes() {
		return [
			'layout'     => [
				'type'    => 'string',
				'default' => 'default',
			],
			'postType'     => [
				'type'    => 'string',
				'default' => 'post',
			],
			'postsPerPage' => [
				'type'    => 'number',
				'default' => 4,
			],
			'orderBy'      => [
				'type'    => 'string',
				'default' => 'date',
			],
			'order'        => [
				'type'    => 'string',
				'default' => 'DESC',
			],
			'postId'       => [
				'type'    => 'string',
				'default' => '',
			],
			'quickQuery'   => [
				'type'    => 'string',
				'default' => '',
			],
			'imageSize'    => [
				'type'    => 'string',
				'default' => '',
			],

			'showThumbnail' => [
				'type'    => 'string',
				'default' => 'on',
			],
			'showContent'   => [
				'type'    => 'string',
				'default' => '',
			],
			'contentLimit'  => [
				'type'    => 'string',
				'default' => '15',
			],
			'showCategory'  => [
				'type'    => 'string',
				'default' => '',
			],
			'showMetaCat'   => [
				'type'    => 'string',
				'default' => '',
			],
			'showMetaDate'  => [
				'type'    => 'string',
				'default' => 'on',
			],
			'showMetaUser'  => [
				'type'    => 'string',
				'default' => '',
			],
			'showMetaIcon'  => [
				'type'    => 'string',
				'default' => 'on',
			],
		];
	}


	/**
	 * Callback for rendering the block on the front-end.
	 *
	 * @param array $data The block attributes.
	 *
	 * @return string The HTML output of the block.
	 */
	public function render_block( $data ) {
		$postRender = new PostRenderer( $data );

		return $postRender->render();
	}
}