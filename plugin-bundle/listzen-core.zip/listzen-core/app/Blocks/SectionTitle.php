<?php

namespace ListzenCore\Blocks;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use ListzenCore\Blocks\Renderer\PostRenderer;
use ListzenCore\Traits\SingletonTraits;
use ListzenCore\Abstracts\BlockBase;

/**
 * Class PostGrid
 *
 * Handles registration and rendering of the "listzen/post-block" Gutenberg block.
 */
class SectionTitle {
	/**
	 * Include Singleton trait to ensure a single instance.
	 */
	use SingletonTraits;

	/**
	 * PostGrid constructor.
	 *
	 * Hooks into WordPress 'init' action to register the block.
	 */
	public function __construct() {
		add_action( 'init', [ $this, 'register_blocks' ] );
	}

	/**
	 * Registers the custom Gutenberg block with render callback and attributes.
	 *
	 * @return void
	 */
	public function register_blocks() {
		if ( ! function_exists( 'register_block_type' ) ) {
			return;
		}
		register_block_type(
			'listzen/section-title',
			[
				'attributes'      => [],
				'render_callback' => null,
			]
		);
	}
}