<?php
/**
 *
 * This theme uses PSR-4 and OOP logic instead of procedural coding
 * Every function, hook and action is properly divided and organized inside related folders and files
 * Use the file `config/custom/custom.php` to write your custom functions
 *
 * @package listzen
 */

namespace ListzenCore;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use ListzenCore\Helper\Install;
use ListzenCore\Traits\SingletonTraits;

final class Init {

	use SingletonTraits;

	/**
	 * Class constructor
	 */
	public function __construct() {
		add_action( 'listzen_theme_init', [ $this, 'after_theme_loaded' ] );
		add_action( 'plugins_loaded', [ $this, 'demo_importer' ], 17 );

		register_activation_hook( LISTZEN_CORE_BASE_FILE_NAME, [ Install::class, 'activate' ] );
		register_deactivation_hook( LISTZEN_CORE_BASE_FILE_NAME, [ Install::class, 'deactivate' ] );

	}

	/**
	 * Instantiate all class
	 * @return void
	 */
	public function after_theme_loaded() {
		Hooks\CategoryHooks::instance();
		Hooks\FilterHooks::instance();
		Hooks\ActionHooks::instance();
		Hooks\ListingMeta::instance();
		Generator\CPTGenerator::instance();
		Modules\WidgetOverwrite::instance();
		Modules\PostAttribute::instance();
		Api\Api::instance();
		Controllers\ScriptController::instance();
		Controllers\GutenbergController::instance();
		Controllers\FrameworkController::instance();
		Controllers\PostMetaController::instance();
		Controllers\CustomCSSMeta::instance();

		if ( did_action( 'elementor/loaded' ) ) {
			Controllers\ElementorController::instance();
			Controllers\ElmentorBuilderController::instance();
		}

	}

	public function demo_importer() {
		Controllers\DemoImportController::instance();
	}
}
