<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Elementor\Custom;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use Elementor\Controls_Manager;

use ListzenCore\Traits\SingletonTraits;

class ElementorCore {
	use SingletonTraits;

	public function __construct() {
		//Container Layout
		add_action( 'elementor/frontend/before_render', [ $this, 'render_parallax_background' ] );

		add_action( 'elementor/element/container/section_layout/after_section_end', [ $this, 'add_elementor_section_background_controls' ], 1 );
		add_action( 'elementor/element/section/section_advanced/after_section_end', [ $this, 'add_elementor_section_background_controls' ], 1 );
		add_action( 'elementor/element/common/_section_style/after_section_end', [ $this, 'add_elementor_section_background_controls' ], 1 );

		add_action( 'elementor/element/nested-accordion/section_items/after_section_start', function ( $element, $args ) {

			$element->add_control(
				'listzen_accordion_style',
				[
					'label'        => __( 'Choose Style', 'listzen-core' ),
					'type'         => \Elementor\Controls_Manager::SELECT,
					'options'      => [
						'default' => __( 'Default', 'listzen-core' ),
						'style-2' => __( 'Style 2', 'listzen-core' ),
					],
					'default'      => 'default',
					'prefix_class' => 'custom-',
				]
			);

		}, 10, 2 );

		add_action( 'elementor/element/heading/section_title/after_section_start', function ( $element, $args ) {

			$element->add_control(
				'listzen_heading_style',
				[
					'label'        => __( 'Choose Style', 'listzen-core' ),
					'type'         => \Elementor\Controls_Manager::SELECT,
					'options'      => [
						'default'         => __( 'Default', 'listzen-core' ),
						'listzen-style' => __( 'Listzen Style', 'listzen-core' ),
					],
					'default'      => 'default',
					'prefix_class' => 'custom-',
				]
			);

			$element->add_control(
				'custom_heading_alert',
				[
					'type'       => \Elementor\Controls_Manager::ALERT,
					'alert_type' => 'warning',
					'content'    => esc_html__( 'Bar works only for text-align left.', 'listzen-core' ),
					'condition'  => [
						'listzen_heading_style' => 'listzen-style',
					],
				]
			);

			$element->add_control(
				'listzen_bar_width',
				[
					'label'     => __( 'Bar Width', 'listzen-core' ),
					'type'      => \Elementor\Controls_Manager::NUMBER,
					'condition' => [
						'listzen_heading_style' => 'listzen-style',
					],
					'selectors' => [
						'{{WRAPPER}} .elementor-widget-container' => '--heading-bar-width: {{VALUE}}px;',
					],
				]
			);
			$element->add_control(
				'listzen_bar_height',
				[
					'label'     => __( 'Bar Height', 'listzen-core' ),
					'type'      => \Elementor\Controls_Manager::NUMBER,
					'condition' => [
						'listzen_heading_style' => 'listzen-style',
					],
					'selectors' => [
						'{{WRAPPER}} .elementor-widget-container' => '--heading-bar-height: {{VALUE}}px;',
					],
				]
			);
			$element->add_control(
				'listzen_bar_color',
				[
					'label'     => __( 'Bar Color', 'listzen-core' ),
					'type'      => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .elementor-widget-container' => '--heading-bar-color: {{VALUE}};',
					],
					'condition' => [
						'listzen_heading_style' => 'listzen-style',
					],
				]
			);


		}, 10, 2 );
	}


	public function add_elementor_section_background_controls( $element ) {
		$element->start_controls_section(
			'listzen_custom_section',
			[
				'label' => __( 'Listzen Settings', 'listzen-core' ),
				'tab'   => Controls_Manager::TAB_ADVANCED,
			]
		);
		$element->add_control(
			'listzen_section_parallax',
			[
				'label'        => __( 'Parallax', 'listzen-core' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_off'    => __( 'Off', 'listzen-core' ),
				'label_on'     => __( 'On', 'listzen-core' ),
				'default'      => 'no',
				'description'  => 'First choose background image from above to enbale this feature.',
				'prefix_class' => 'listzen-parallax-bg-',
			]
		);

		$element->add_control(
			'listzen_parallax_direction',
			[
				'label'      => __( 'Parallax Direction', 'listzen-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'default'    => [
					'unit' => 'px',
					'size' => - 0.5,
				],
				'range'      => [
					'px' => [
						'min'  => - 5,
						'max'  => 5,
						'step' => 0.1,
					],
				],
				'condition'  => [
					'listzen_section_parallax' => 'yes',
				],
			]
		);

		$element->add_control(
			'listzen_backdrop_filter',
			[
				'label'      => __( 'Backdrop Filter', 'listzen-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 20,
						'step' => 0.1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}}' => 'backdrop-filter: blur({{SIZE}}px);-webkit-backdrop-filter: blur({{SIZE}}px);',
				],
			]
		);

		$element->add_control(
			'more_options',
			[
				'label'     => esc_html__( 'RTL Support', 'listzen-core' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$element->add_control(
			'rtl_flip',
			[
				'label'        => esc_html__( 'Flip horizontally RTL', 'listzen-core' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'On', 'listzen-core' ),
				'label_off'    => esc_html__( 'Off', 'listzen-core' ),
				'return_value' => 'yes',
				'prefix_class' => 'rtl-flip-',
			]
		);
		$element->add_control(
			'rtl_bg',
			[
				'label'        => esc_html__( 'Flip Overly BG', 'listzen-core' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'On', 'listzen-core' ),
				'label_off'    => esc_html__( 'Off', 'listzen-core' ),
				'return_value' => 'yes',
				'prefix_class' => 'rtl-flip-bg-',
			]
		);

		$element->add_responsive_control( 'listzen_margin_left', [
			'label'     => is_rtl() ? __( 'Margin Right (PX)', 'listzen-core' ) : __( 'Margin Left (PX)', 'listzen-core' ),
			'type'      => Controls_Manager::NUMBER,
			'step'      => 1,
			'selectors' => [
				'{{WRAPPER}}'             => 'margin-left:{{VALUE}}px;',
				'[dir="rtl"] {{WRAPPER}}' => 'margin-right:{{VALUE}}px;',
			],
		] );

		$element->add_responsive_control( 'listzen_margin_right', [
			'label'     => is_rtl() ? __( 'Margin Left (PX)', 'listzen-core' ) : __( 'Margin Right (PX)', 'listzen-core' ),
			'type'      => Controls_Manager::NUMBER,
			'step'      => 1,
			'selectors' => [
				'{{WRAPPER}}'             => 'margin-right:{{VALUE}}px;',
				'[dir="rtl"] {{WRAPPER}}' => 'margin-left:{{VALUE}}px;',
			],
		] );
		$element->add_responsive_control( 'listzen_padding_left', [
			'label'     => is_rtl() ? __( 'Padding Right (PX)', 'listzen-core' ) : __( 'Padding Left (PX)', 'listzen-core' ),
			'type'      => Controls_Manager::NUMBER,
			'step'      => 1,
			'selectors' => [
				'{{WRAPPER}}'             => 'padding-left:{{VALUE}}px;',
				'[dir="rtl"] {{WRAPPER}}' => 'padding-right:{{VALUE}}px;',
			],
		] );

		$element->add_responsive_control( 'listzen_padding_right', [
			'label'     => is_rtl() ? __( 'Padding Left (PX)', 'listzen-core' ) : __( 'Padding Right (PX)', 'listzen-core' ),
			'type'      => Controls_Manager::NUMBER,
			'step'      => 1,
			'selectors' => [
				'{{WRAPPER}}'             => 'padding-right:{{VALUE}}px;',
				'[dir="rtl"] {{WRAPPER}}' => 'padding-left:{{VALUE}}px;',
			],
		] );


		$element->end_controls_section();
	}

	// Render section background parallax
	public function render_parallax_background( $element ) {
		$settings = $element->get_settings();

		$is_paralax_enable = $settings['listzen_section_parallax'] ?? '';

		if ( 'yes' === $is_paralax_enable ) {
			wp_enqueue_script( 'listzen-enllax' );
			$listzen_parallax_direction = $settings['listzen_parallax_direction']['size'] ?? '';

			if ( $listzen_parallax_direction ) {
				$element->add_render_attribute( '_wrapper', 'data-enllax-ratio', $listzen_parallax_direction );
			}
		}
	}

}