<?php

namespace ListzenCore\Elementor\Renderers;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use Elementor\Plugin;
use ListzenCore\Helper\Fns;
use ListzenCore\Modules\PostQuery;

/**
 * Class PostGridRenderer
 *
 * Responsible for rendering the post grid layout, handling queries,
 * layout settings, AJAX filters, and markup.
 */
class PostGridRenderer {

	/**
	 * Settings for rendering the grid.
	 *
	 * @var array
	 */
	protected $settings;

	/**
	 * WP_Query instance used to retrieve posts.
	 *
	 * @var \WP_Query
	 */
	protected $query;

	/**
	 * CSS classes applied to each post item.
	 *
	 * @var array
	 */
	protected $post_classes;

	/**
	 * Layout-specific settings derived from the main settings.
	 *
	 * @var array
	 */
	protected $layout_settings;

	/**
	 * CSS class for the main grid wrapper.
	 *
	 * @var string
	 */
	protected $main_wrapper_class;


	/**
	 * PostGridRenderer constructor.
	 *
	 * @param array $settings Settings for the grid rendering.
	 */
	public function __construct( $settings ) {
		$this->settings           = $settings;
		$this->query              = PostQuery::query( $this->settings );
		$this->main_wrapper_class = $this->main_wrapper_class();
		$this->post_classes       = $this->build_post_classes();
		$this->layout_settings    = Fns::post_layout_settings( $this->settings, $this->post_classes );
	}


	/**
	 * Get the main wrapper class based on masonry layout and editor mode.
	 *
	 * @return string
	 */
	protected function main_wrapper_class() {
		return ( ! Plugin::$instance->editor->is_edit_mode() && $this->settings['masonry_layout'] ) ? 'listzen-masonry-grid' : '';
	}


	/**
	 * Build and return the list of CSS classes for each post.
	 *
	 * @return string
	 */
	protected function build_post_classes() {
		$common_class = 'listzen-post-card blog-post-card';
		$common_class .= ' ' . $this->settings['meta_style'];
		$common_class .= $this->settings['separate_meta_visibility'] ? ' is-above-meta' : ' no-above-meta';
		$common_class .= ( ! Plugin::$instance->editor->is_edit_mode() && $this->settings['masonry_layout'] ) ? ' masonry-item' : " animate-up";

		return Fns::class_list(
			[
				$common_class,
				Fns::layout_prefix( $this->settings['layout'] ),
				Fns::grid_column( $this->settings ),
			]
		);
	}


	/**
	 * Render the loop of post articles.
	 *
	 * @return void
	 */
	protected function render_posts() {
		$count = 1;
		while ( $this->query->have_posts() ) {
			$this->query->the_post();
			$this->layout_settings['post_type'] = get_post_type( get_the_ID() );
			$this->layout_settings['count']     = $count;


			$post_class = get_post_class( $this->post_classes );

			if ( 'yes' !== $this->settings['thumbnail_visibility'] ) {
				$post_class = array_diff( $post_class, [ 'has-post-thumbnail' ] );
			}


			echo '<article data-post-id="' . esc_attr( get_the_ID() ) . '" class="' . esc_attr( implode( ' ', $post_class ) ) . '">';
			Fns::get_template( "elementor/post-grid/{$this->layout_settings['layout']}", $this->layout_settings );
			echo '</article>';
			$count ++;
		}
	}

	/**
	 * Render the full post grid including filters, posts, and loader.
	 *
	 * @return void
	 */
	public function render() {
		do_action( 'listzen_core_before_post_grid', $this->layout_settings );

		echo '<div class="listzen-el-post-wrapper blog-grid">';

		if ( $this->query->have_posts() ) {
			echo '<div class="listzen-article-main">';

			echo '<div class="row blog-wrapper-row ' . esc_attr( $this->main_wrapper_class ) . '">';
			$this->render_posts();
			echo '</div></div>';
		} else {
			echo '<p>' . esc_html__( 'No posts found', 'listzen-core' ) . '</p>';
		}

		wp_reset_postdata();

		echo '</div>';

		do_action( 'listzen_core_after_post_grid', $this->layout_settings );
	}
}
