<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Elementor\Addons;

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use ListzenCore\Abstracts\ElementorBase;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PageList extends ElementorBase {

	public function __construct( $data = [], $args = null ) {
		$this->listzen_name = esc_html__( 'Page List', 'listzen-core' );
		$this->listzen_base = 'listzen-page-list';
		parent::__construct( $data, $args );
	}

	protected function register_controls() {
		$this->general();
	}

	protected function general() {
		$this->start_controls_section(
			'sec_general',
			[
				'label' => esc_html__( 'Pages List', 'listzen-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		// Page select
		$repeater->add_control(
			'page_id',
			[
				'label'   => esc_html__( 'Select Page', 'listzen-core' ),
				'type'    => Controls_Manager::SELECT2,
				'options' => $this->get_all_pages(),
				'default' => '',
			]
		);

		// Custom title
		$repeater->add_control(
			'custom_title',
			[
				'label'       => esc_html__( 'Custom Title', 'listzen-core' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Leave blank to use page title', 'listzen-core' ),
			]
		);

		// Custom URL
		$repeater->add_control(
			'custom_url',
			[
				'label'         => esc_html__( 'Custom URL', 'listzen-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_html__( 'Leave blank to use page link', 'listzen-core' ),
				'show_external' => true,
			]
		);

		// Icon
		$repeater->add_control(
			'item_icon',
			[
				'label' => esc_html__( 'Icon', 'listzen-core' ),
				'type'  => Controls_Manager::ICONS,
			]
		);

		$this->add_control(
			'pages_list',
			[
				'label'       => esc_html__( 'Pages', 'listzen-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ custom_title || (page_id && "Page ID: " + page_id) || "Untitled" }}}',
			]
		);

		// === Extra fields after repeater ===

		$this->add_control(
			'columns',
			[
				'label'     => esc_html__( 'Columns', 'listzen-core' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '1',
				'options'   => [
					'1' => esc_html__( '1 Column', 'listzen-core' ),
					'2' => esc_html__( '2 Columns', 'listzen-core' ),
					'3' => esc_html__( '3 Columns', 'listzen-core' ),
				],
				'selectors' => [
					'{{WRAPPER}} .listzen-page-list' => 'grid-template-columns: repeat({{VALUE}}, 1fr);',
				],
			]
		);


		$this->add_responsive_control(
			'row_gap',
			[
				'label'      => esc_html__( 'Row Gap', 'listzen-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .listzen-page-list' => 'row-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'column_gap',
			[
				'label'      => esc_html__( 'Column Gap', 'listzen-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .listzen-page-list' => 'column-gap: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'columns!' => '1',
				],
			]
		);

		$this->add_control(
			'link_style_heading',
			[
				'label'     => esc_html__( 'Link Style', 'listzen-core' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);


		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'link_typography',
				'label'    => esc_html__( 'Typography', 'listzen-core' ),
				'selector' => '{{WRAPPER}} .listzen-page-list .page-item a',
			]
		);


		$this->add_control(
			'link_color',
			[
				'label'     => esc_html__( 'Link Color', 'listzen-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .listzen-page-list .page-item a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'link_hover_color',
			[
				'label'     => esc_html__( 'Link Hover Color', 'listzen-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .listzen-page-list .page-item a:hover' => 'color: {{VALUE}};',
				],
			]
		);


		$this->add_control(
			'icon_settings_heading',
			[
				'label'     => esc_html__( 'Icon Settings', 'listzen-core' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'icon_show_on',
			[
				'label'     => esc_html__( 'Icon Show', 'listzen-core' ),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 'always',
				'options'   => [
					'always'       => esc_html__( 'Always', 'listzen-core' ),
					'on-hover'   => esc_html__( 'On Hover', 'listzen-core' ),
				],
				'prefix_class' => 'icon-show-'
			]
		);

		$this->add_control(
			'icon_left_pos',
			[
				'label'      => esc_html__( 'Icon negative position', 'listzen-core' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
				],
				'condition' => [
					'icon_show_on' => 'on-hover',
				],
				'selectors'  => [
					'{{WRAPPER}} .listzen-page-list .elementor-icon' => 'margin-left: -{{SIZE}}px; margin-right: 0;',
					'[dir="rtl"] {{WRAPPER}} .listzen-page-list .elementor-icon' => 'margin-right: -{{SIZE}}px; margin-left: 0;',
				],
			]
		);

		$this->add_responsive_control(
			'icon_between',
			[
				'label'      => esc_html__( 'Icon Space', 'listzen-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .listzen-page-list .page-item' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'icon_size',
			[
				'label'      => esc_html__( 'Icon Size', 'listzen-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .listzen-page-list .page-item :is(i, svg)' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label'     => esc_html__( 'Icon Color', 'listzen-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .listzen-page-list .page-item i'   => 'color: {{VALUE}};',
					'{{WRAPPER}} .listzen-page-list .page-item svg' => 'fill: {{VALUE}};',
				],
			]
		);


		$this->end_controls_section();
	}

	private function get_all_pages() {
		$pages   = get_pages();
		$options = [];
		if ( ! empty( $pages ) ) {
			foreach ( $pages as $page ) {
				$options[ $page->ID ] = $page->post_title;
			}
		}

		return $options;
	}

	protected function render() {
		$data = $this->get_settings_for_display();

		if ( empty( $data['pages_list'] ) ) {
			return;
		}

		$columns = ! empty( $data['columns'] ) ? intval( $data['columns'] ) : 3;

		echo '<div class="listzen-page-list">';
		foreach ( $data['pages_list'] as $item ) {
			$page_title = ! empty( $item['custom_title'] ) ? $item['custom_title'] : get_the_title( $item['page_id'] );
			if ( ! empty( $item['custom_url']['url'] ) ) {
				$custom_url = trim( $item['custom_url']['url'] );

				// If missing leading slash, add it for relative URLs
				if ( strpos( $custom_url, '/' ) !== 0 && strpos( $custom_url, 'http' ) !== 0 ) {
					$custom_url = '/' . $custom_url;
				}

				// If it's relative, prepend home_url()
				if ( strpos( $custom_url, 'http' ) !== 0 ) {
					$page_url = home_url( $custom_url );
				} else {
					$page_url = $custom_url;
				}
			} else {
				$page_url = get_permalink( $item['page_id'] );
			}
			if ( ! $page_title || ! $page_url ) {
				continue;
			}

			$target   = $item['custom_url']['is_external'] ? '_blank' : '';
			$nofollow = $item['custom_url']['nofollow'] ? 'nofollow' : '';

			echo '<div class="page-item">';
			if ( ! empty( $item['item_icon']['value'] ) ) {
				echo "<div class='elementor-icon'>";
				Icons_Manager::render_icon( $item['item_icon'], [ 'aria-hidden' => 'true' ] );
				echo "</div>";
			}
			printf(
				'<a href="%s"%s%s>%s</a>',
				esc_url( $page_url ),
				$target ? ' target="' . esc_attr( $target ) . '"' : '',
				$nofollow ? ' rel="' . esc_attr( $nofollow ) . '"' : '',
				esc_html( $page_title )
			);
			echo '</div>';
		}
		echo '</div>';
	}

}