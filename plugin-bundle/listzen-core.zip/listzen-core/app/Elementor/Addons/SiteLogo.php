<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Elementor\Addons;

use Elementor\Group_Control_Border;
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use ListzenCore\Helper\Fns;
use ListzenCore\Abstracts\ElementorBase;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Marquee Class
 */
class SiteLogo extends ElementorBase {

	/**
	 * Class Constructor
	 *
	 * @param $data
	 * @param $args
	 *
	 * @throws \Exception
	 */
	public function __construct( $data = [], $args = null ) {
		$this->listzen_name = esc_html__( 'Site Logo', 'listzen-core' );
		$this->listzen_base = 'listzen-logo';
		parent::__construct( $data, $args );
	}

	/**
	 * Register Controls
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->general();
	}

	protected function general() {
		$this->start_controls_section(
			'sec_general',
			[
				'label' => esc_html__( 'Settings', 'listzen-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'logo_type',
			[
				'label'       => __( 'Logo Type', 'listzen-core' ),
				'description' => __( 'Choose which version of the site logo to display. Logos must be uploaded via Appearance → Customize → Site Identity.', 'listzen-core' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'dark',
				'options'     => [
					'dark'   => __( 'Dark Logo', 'listzen-core' ),
					'light'  => __( 'Light Logo', 'listzen-core' ),
					'mobile' => __( 'Mobile Logo', 'listzen-core' ),
				],
			]
		);

		$this->add_responsive_control(
			'logo_height',
			[
				'label'       => esc_html__( 'Logo Height', 'listzen-core' ),
				'description' => esc_html__( 'Adjust the logo height. Width is set automatically.', 'listzen-core' ),
				'type'        => \Elementor\Controls_Manager::SLIDER,
				'size_units'  => [ 'px' ],
				'range'       => [
					'px' => [
						'min'  => 30,
						'max'  => 300,
						'step' => 1,
					],
				],
				'selectors'   => [
					'{{WRAPPER}} .el-site-logo-wrapper.site-branding .site-logo' => 'height: {{SIZE}}{{UNIT}};max-height:inherit;width:auto;',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Content Render
	 *
	 * @return void
	 */
	protected function render() {
		$data      = $this->get_settings();
		$logo_type = $data['logo_type'];
		if ( function_exists( 'listzen_site_logo' ) ) {
			?>
            <div class="site-branding el-site-logo-wrapper">
				<?php listzen_site_logo( $logo_type ); ?>
            </div>
			<?php
		}
	}

}
