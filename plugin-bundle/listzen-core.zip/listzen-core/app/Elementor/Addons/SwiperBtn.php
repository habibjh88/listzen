<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Elementor\Addons;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Utils;
use ListzenCore\Abstracts\ElementorBase;
use ListzenCore\Helper\Fns;
use ListzenCore\Traits\SliderTraits;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SwiperBtn extends ElementorBase {


	/**
	 * Class constructor
	 *
	 * @param $data
	 * @param $args
	 *
	 * @throws \Exception
	 */
	public function __construct( $data = [], $args = null ) {
		$this->listzen_name = esc_html__( 'Swiper button', 'listzen-core' );
		$this->listzen_base = 'listzen-swiper-button';
		parent::__construct( $data, $args );
	}


	/**
	 * Register Controls
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->general_settings();
	}

	/**
	 * General Settings
	 *
	 * @return void
	 */
	protected function general_settings() {
		$this->start_controls_section(
			'sec_general',
			[
				'label' => esc_html__( 'General', 'listzen-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'panel_alert',
			[
				'type' => \Elementor\Controls_Manager::ALERT,
				'alert_type' => 'warning',
				'heading' => esc_html__( 'Custom Alert', 'listzen-core' ),
				'content' => esc_html__( 'This widget works only for swiper Testimonial Slider', 'listzen-core' ),
			]
		);

		$this->add_responsive_control(
			'space_between',
			[
				'label'      => __( 'Space Between', 'listzen-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .listzen-testimonial-slider'         => 'gap: {{SIZE}}px;',
				],
				
			]
		);

		$this->add_responsive_control(
			'alignment',
			[
				'label'     => esc_html__( 'Alignment', 'listzen-core' ),
				'type'      => \Elementor\Controls_Manager::CHOOSE,
				'options'   => [
					'flex-start'   => [
						'title' => esc_html__( 'Left', 'listzen-core' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'listzen-core' ),
						'icon'  => 'eicon-text-align-center',
					],
					'flex-end'  => [
						'title' => esc_html__( 'Right', 'listzen-core' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .listzen-testimonial-slider' => 'justify-content: {{VALUE}};',
				],
			]
		);
        $this->add_responsive_control(
			'arrow_size',
			[
				'label'      => __( 'Arrow Size', 'listzen-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 30,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .listzen-testimonial-slider .swiper-arrow'         => '--arrowBtnWidth: {{SIZE}}px;',
					'{{WRAPPER}} .listzen-testimonial-slider .swiper-arrow::before' => 'transform: scale(calc(({{SIZE}} * 0.8) / 50));',
				],

			]
		);


		$this->add_responsive_control(
			'arrow_radius',
			[
				'label'      => __( 'Border Radius', 'listzen-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .listzen-testimonial-slider .swiper-arrow' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
				
			]
		);
		$this->start_controls_tabs(
			'arrow_tabs', [
			]
		);

		$this->start_controls_tab(
			'arrow_normal_tab',
			[
				'label' => __( 'Normal', 'listzen-core' ),
			]
		);

		$this->add_control(
			'arrow_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Arrow Color', 'listzen-core' ),
				'selectors' => [
					'{{WRAPPER}} .listzen-testimonial-slider .swiper-arrow' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'arrow_bg',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Arrow Background', 'listzen-core' ),
				'selectors' => [
					'{{WRAPPER}} .listzen-testimonial-slider .swiper-arrow' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'arrow_box_shadow',
				'selector' => '{{WRAPPER}} .listzen-testimonial-slider .swiper-arrow',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name'     => 'arrow_border',
				'label'    => __( 'Icon Border', 'listzen-core' ),
				'selector' => '{{WRAPPER}} .listzen-testimonial-slider .swiper-arrow',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'arrow_hover_tab',
			[
				'label' => __( 'Hover', 'listzen-core' ),
			]
		);

		$this->add_control(
			'arrow_color_h',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Arrow Color:hover', 'listzen-core' ),
				'selectors' => [
					'{{WRAPPER}} .listzen-testimonial-slider .swiper-arrow:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'arrow_bg_h',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Arrow Background:hover', 'listzen-core' ),
				'selectors' => [
					'{{WRAPPER}} .listzen-testimonial-slider .swiper-arrow:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'arrow_box_shadow_hover',
				'selector' => '{{WRAPPER}} .listzen-testimonial-slider .swiper-arrow:hover',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name'     => 'arrow_border_hover',
				'label'    => __( 'Icon Border:hover', 'listzen-core' ),
				'selector' => '{{WRAPPER}} .listzen-testimonial-slider .swiper-arrow',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}


	/**
	 * Render Content
	 *
	 * @return void
	 */
	protected function render() {
		$data      = $this->get_settings();

		?>


		<div class="listzen-testimonial-slider custom-arrow">
			<div class="swiper-arrow swiper-button-prev" tabindex="0" role="button" aria-label="Prev slide"><i class="rt-icon-arrow-small-left"></i></div>
            <div class="swiper-arrow swiper-button-next" tabindex="0" role="button" aria-label="Next slide"><i class="rt-icon-arrow-small-right"></i></div>
        </div>
		<?php
	}
}

