<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Elementor\Addons;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use ListzenCore\Helper\Fns;
use ListzenCore\Abstracts\ElementorBase;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Marquee Class
 */
class SiteMenu extends ElementorBase {

	/**
	 * Class Constructor
	 *
	 * @param $data
	 * @param $args
	 *
	 * @throws \Exception
	 */
	public function __construct( $data = [], $args = null ) {
		$this->listzen_name = esc_html__( 'Site Menu', 'listzen-core' );
		$this->listzen_base = 'listzen-menu';
		parent::__construct( $data, $args );
	}

	/**
	 * Register Controls
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->general();
		$this->style_tab();
	}

	protected function general() {
		$this->start_controls_section(
			'sec_general',
			[
				'label' => esc_html__( 'Settings', 'listzen-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$menus        = wp_get_nav_menus();
		$menu_options = [];

		if ( ! empty( $menus ) && ! is_wp_error( $menus ) ) {
			foreach ( $menus as $menu ) {
				$menu_options[ $menu->term_id ] = $menu->name;
			}
		}

		$this->add_control(
			'select_menu',
			[
				'label'   => esc_html__( 'Select Menu', 'listzen-core' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => '',
				'options' => $menu_options,
			]
		);

		$this->add_responsive_control(
			'alignment',
			[
				'label'   => __( 'Alignment', 'listzen-core' ),
				'type'    => Controls_Manager::CHOOSE,
				'default' => 'start',
				'options' => [
					'start'  => [
						'title' => __( 'Left', 'listzen-core' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'listzen-core' ),
						'icon'  => 'eicon-text-align-center',
					],
					'end'    => [
						'title' => __( 'Right', 'listzen-core' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
			]
		);

		$this->end_controls_section();
	}

	protected function style_tab() {
		$this->start_controls_section(
			'icon_group_style',
			[
				'label' => esc_html__( 'Style', 'listzen-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'main_menu_style',
			[
				'label'     => esc_html__( 'Main Menu', 'listzen-core' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'dropdown_typography',
				'label'    => esc_html__( 'Menu Typography', 'listzen-core' ),
				'selector' => '{{WRAPPER}} .el-header-menu-wrap .listzen-navigation ul.listzen-navbar > li > a',
			]
		);

		$this->add_responsive_control(
			'menu_padding',
			[
				'label'      => esc_html__( 'Item Padding', 'listzen-core' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .el-header-menu-wrap .listzen-navigation ul.listzen-navbar > li > a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control( 'menu_color', [
			'label'     => __( 'Menu Color', 'listzen-core' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .el-header-menu-wrap' => '--listzen-menu-color: {{VALUE}}',
			],
		] );
		$this->add_control( 'menu_active_color', [
			'label'     => __( 'Menu Active Color', 'listzen-core' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .el-header-menu-wrap' => '--listzen-menu-active-color: {{VALUE}}',
			],
		] );

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name'     => 'main_menu_bg',
				'label'    => __( 'Main Menu Background', 'listzen-core' ),
				'types'    => [ 'classic', 'gradient'],
				'selector' => '{{WRAPPER}} .menu-primary-menu-container',
			]
		);

		$this->add_control( //add_responsive_control
			'menu_radius',
			[
				'label'      => esc_html__( 'Main Menu Border Radius', 'listzen-core' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .menu-primary-menu-container' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'dropdown_menu_style',
			[
				'label'     => esc_html__( 'Dropdown Menu', 'listzen-core' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'dropdown_menu_typography',
				'label'    => esc_html__( 'Dropdown Menu Typography', 'listzen-core' ),
				'selector' => '{{WRAPPER}} .el-header-menu-wrap .listzen-navigation ul li ul li a',
			]
		);

		$this->add_control(
			'dropdown_menu_width',
			[
				'label'      => esc_html__( 'Dwopdown Width', 'listzen-core' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 5,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .el-header-menu-wrap .listzen-navigation ul > li > ul' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'dropdown_menu_color', [
			'label'     => __( 'Dropdown menu color', 'listzen-core' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .el-header-menu-wrap .listzen-navigation ul li ul li a' => '--listzen-body-color: {{VALUE}}',
			],
		] );
		$this->add_control( 'dropdown_menu_active_color', [
			'label'     => __( 'Dropdown menu Active color', 'listzen-core' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .el-header-menu-wrap .listzen-navigation ul li ul li a' => '--listzen-menu-active-color: {{VALUE}}',
			],
		] );
		$this->add_control( 'dropdown_menu_bg', [
			'label'     => __( 'Dropdown menu background', 'listzen-core' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .el-header-menu-wrap .listzen-navigation ul li > ul.dropdown-menu' => 'background-color: {{VALUE}}',
			],
		] );

		$this->end_controls_section();
	}

	/**
	 * Content Render
	 *
	 * @return void
	 */
	protected function render() {
		$settings      = $this->get_settings();
		$default_align = "justify-content-" . $settings['alignment'];
		?>
        <div class="el-header-menu-wrap">
            <div class="navigation-menu-wrap">
                <nav class="listzen-navigation  <?php echo esc_attr( $default_align ) ?>" role="navigation">
					<?php
					if ( ! empty( $settings['select_menu'] ) ) {
						wp_nav_menu( [
							'menu'        => intval( $settings['select_menu'] ), // Selected menu ID
							'menu_class'  => 'listzen-navbar',
							'items_wrap'  => '<ul class="%2$s">%3$s</ul>',
							'fallback_cb' => 'listzen_custom_menu_cb',
							'walker'      => new \Listzen\Core\WalkerNav(),
						] );
					}
					?>
                </nav><!-- .listzen-navigation -->
            </div>
        </div>
		<?php
	}

}
