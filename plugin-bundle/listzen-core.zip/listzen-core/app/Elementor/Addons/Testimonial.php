<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Elementor\Addons;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Utils;
use ListzenCore\Abstracts\ElementorBase;
use ListzenCore\Helper\Fns;
use ListzenCore\Traits\SliderTraits;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Testimonial extends ElementorBase {
	use SliderTraits;

	/**
	 * Class constructor
	 *
	 * @param $data
	 * @param $args
	 *
	 * @throws \Exception
	 */
	public function __construct( $data = [], $args = null ) {
		$this->listzen_name = esc_html__( 'Testimonial Slider', 'listzen-core' );
		$this->listzen_base = 'listzen-testimonial-slider';
		parent::__construct( $data, $args );
	}

	public function get_script_depends() {
		return [ 'swiper' ];
	}

	public function get_style_depends() {
		return [ 'swiper' ];
	}

	/**
	 * Register Controls
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->general_settings();
		$this->slider_settings();

		$this->card_settings();
		$this->image_settings();
		$this->quote_settings();
		$this->content_settings();
		$this->slider_style();
	}

	/**
	 * General Settings
	 *
	 * @return void
	 */
	protected function general_settings() {
		$this->start_controls_section(
			'sec_general',
			[
				'label' => esc_html__( 'General', 'listzen-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'layout',
			[
				'label'       => esc_html__( 'Choose Layout', 'listzen-core' ),
				'type'        => \Elementor\Controls_Manager::VISUAL_CHOICE,
				'label_block' => true,
				'options'     => [
					'style-1' => [
						'title' => esc_attr__( 'Layout 1', 'listzen-core' ),
						'image' => esc_url( Fns::get_assets_url( 'images/layout/testimonial-1.svg' ) ),
					],
					'style-2' => [
						'title' => esc_attr__( 'Layout 2', 'listzen-core' ),
						'image' => esc_url( Fns::get_assets_url( 'images/layout/testimonial-2.svg' ) ),
					],
					'style-3' => [
						'title' => esc_attr__( 'Layout 3', 'listzen-core' ),
						'image' => esc_url( Fns::get_assets_url( 'images/layout/testimonial-1.svg' ) ),
					],
				],
				'default'     => 'style-1',
				'columns'     => 2,
			]
		);

		$this->add_control(
			'image_position',
			[
				'label'        => esc_html__( 'Image Position', 'listzen-core' ),
				'type'         => \Elementor\Controls_Manager::SELECT,
				'default'      => 'top',
				'options'      => [
					'top'       => esc_html__( 'Default', 'listzen-core' ),
					'with-name' => esc_html__( 'With Name', 'listzen-core' ),
				],
				'render_type'  => 'template',
				'prefix_class' => 'image-position-',
			]
		);

		$this->add_responsive_control(
			'slider_column',
			[
				'label'          => esc_html__( 'Slider Column', 'listzen-core' ),
				'type'           => Controls_Manager::SELECT,
				'default'        => '',
				'tablet_default' => '',
				'mobile_default' => '',
				'options'        => Fns::slider_list(),
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'image',
			[
				'label'   => __( 'Choose Image', 'listzen-core' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'name',
			[
				'label'       => __( 'Name', 'listzen-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Enter Name', 'listzen-core' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'designation',
			[
				'label'       => __( 'Designation', 'listzen-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Enter Designation', 'listzen-core' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'content',
			[
				'label'   => __( 'Content', 'listzen-core' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => __( 'Enter Designation', 'listzen-core' ),
			]
		);

		$this->add_control(
			'items',
			[
				'label'       => __( 'Testimonial List', 'listzen-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'name'        => __( 'Maria Zokatti', 'listzen-core' ),
						'designation' => __( 'CEO, PSDBOSS', 'listzen-core' ),
						'content'     => __(
							'Engage with our professional real estate agents sell Following buy or rent your home.Get emails directly to your area reach inbox and manage the lead with.',
							'listzen-core'
						),
					],
					[
						'name'        => __( 'John Doe', 'listzen-core' ),
						'designation' => __( 'WordPress Developer', 'listzen-core' ),
						'content'     => __(
							'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Aliquid expedita recusandae ipsam quas fugit aperiam nihil nemo delectus laudantium? Enim est quibusdam dicta a',
							'listzen-core'
						),
					],
					[
						'name'        => __( 'Kent Odeldan', 'listzen-core' ),
						'designation' => __( 'Web Designer', 'listzen-core' ),
						'content'     => __( 'Aliquid expedita recusandae ipsam quas fugit aperiam nihil nemo delectus laudantium? Enim est quibusdam dicta a', 'listzen-core' ),
					],

				],
				'title_field' => '{{{ name }}}',
			]
		);

		$this->add_responsive_control(
			'alignment',
			[
				'label'     => __( 'Alignment', 'listzen-core' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => __( 'Left', 'listzen-core' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'listzen-core' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => __( 'Right', 'listzen-core' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .listzen-testimonial-slider' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'field_visibility',
			[
				'label'     => esc_html__( 'Fields Visibility', 'listzen-core' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'thumbnail_visibility',
			[
				'label'        => __( 'Thumbnail Visibility', 'listzen-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'listzen-core' ),
				'label_off'    => __( 'Hide', 'listzen-core' ),
				'return_value' => 'on',
				'default'      => 'on',
			]
		);

		$this->add_control(
			'rating',
			[
				'label'        => __( 'Rating', 'listzen-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'listzen-core' ),
				'label_off'    => __( 'Hide', 'listzen-core' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'quote_visibility',
			[
				'label'        => __( 'Quote Icon Visibility', 'listzen-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'listzen-core' ),
				'label_off'    => __( 'Hide', 'listzen-core' ),
				'return_value' => 'yes',
				'default'      => false,
			]
		);

		$this->end_controls_section();
	}

	protected function quote_settings() {
		$this->start_controls_section(
			'quote_style',
			[
				'label'     => esc_html__( 'Quote Style', 'listzen-core' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'quote_visibility' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'quote_size',
			[
				'label'      => esc_html__( 'Quote Size', 'listzen-core' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 5,
					],
					'%'  => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .quote-icon-wrap' => 'font-size: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_responsive_control(
			'quote_position',
			[
				'label'      => esc_html__( 'Quote Icon (X) Position', 'listzen-core' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 5,
					],
					'%'  => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .quote-icon-wrap' => 'left: {{SIZE}}{{UNIT}};right:auto;',
					'[dir="rtl"] {{WRAPPER}} .quote-icon-wrap' => 'right: {{SIZE}}{{UNIT}};left:auto;',
				],
			]
		);
		$this->add_responsive_control(
			'quote_position_top',
			[
				'label'      => esc_html__( 'Quote Icon (Y) Position', 'listzen-core' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 5,
					],
					'%'  => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .quote-icon-wrap' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control( 'quote_color', [
			'label'     => __( 'Quote Color', 'listzen-core' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .quote-icon-wrap' => 'color: {{VALUE}}',
			],
		] );

		$this->end_controls_section();
	}

	protected function image_settings() {
		$this->start_controls_section(
			'image_style',
			[
				'label' => esc_html__( 'Image Style', 'listzen-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'thumbnail_size',
			[
				'label'   => esc_html__( 'Image Size', 'listzen-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => Fns::image_size_lists(),
			]
		);

		$this->add_control(
			'image_width',
			[
				'label'      => __( 'Custom Width', 'listzen-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 50,
						'max'  => 500,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .listzen-testimonial-slider .testimonial-img img' => 'width: {{SIZE}}{{UNIT}};height:auto;',
				],
				'condition'  => [
					'layout!' => [ 'style-3' ],
				],
			]
		);

		$this->add_control(
			'image_height',
			[
				'label'      => __( 'Custom Height', 'listzen-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 50,
						'max'  => 500,
						'step' => 1,
					],
				],
				'selectors'  => [
					'body {{WRAPPER}} .listzen-testimonial-slider .testimonial-img img' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'layout!' => [ 'style-3' ],
				],
			]
		);

		$this->add_control(
			'image3_width',
			[
				'label'      => __( 'Custom Width', 'listzen-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 50,
						'max'  => 500,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .listzen-testimonial-slider .testimonial-img' => 'max-width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'layout' => [ 'style-3' ],
				],
			]
		);

		$this->add_responsive_control(
			'img_radius',
			[
				'label'      => __( 'Border Radius', 'listzen-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .listzen-testimonial-slider :is(.testimonial-img, .testimonial-img img)' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'image_box_shadow',
				'selector' => '{{WRAPPER}} .listzen-testimonial-slider .testimonial-img img',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name'     => 'image_border',
				'label'    => __( 'Icon Border', 'listzen-core' ),
				'selector' => '{{WRAPPER}} .listzen-testimonial-slider .testimonial-img img',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Content Settings
	 *
	 * @return void
	 */
	protected function content_settings() {
		$this->start_controls_section(
			'content_style',
			[
				'label' => esc_html__( 'Content Style', 'listzen-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'name_style_heading',
			[
				'label'     => __( 'Name Style', 'listzen-core' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typo',
				'label'    => esc_html__( 'Name Typography', 'listzen-core' ),
				'selector' => '{{WRAPPER}} .listzen-testimonial-slider .testimonial-content .item-title',
			]
		);

		$this->add_control(
			'title_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Name Color', 'listzen-core' ),
				'selectors' => [
					'{{WRAPPER}} .listzen-testimonial-slider .testimonial-content .item-title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'designation_style_heading',
			[
				'label'     => __( 'Designation Style', 'listzen-core' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'designation_typo',
				'label'    => esc_html__( 'Designation Typo', 'listzen-core' ),
				'selector' => '{{WRAPPER}} .listzen-testimonial-slider .testimonial-content .designation',
			]
		);

		$this->add_control(
			'des_dots',
			[
				'label'        => __( 'Enable Dots?', 'listzen-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'listzen-core' ),
				'label_off'    => __( 'Hide', 'listzen-core' ),
				'return_value' => 'yes',
				'default'      => false,
				'prefix_class' => 'is-dots-',
			]
		);

		$this->add_control(
			'designation_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Designation Color', 'listzen-core' ),
				'selectors' => [
					'{{WRAPPER}} .listzen-testimonial-slider .testimonial-content .designation' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'des_dots_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Dots Color', 'listzen-core' ),
				'selectors' => [
					'{{WRAPPER}} .listzen-testimonial-slider .testimonial-content .designation span::before' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'des_dots' => 'yes',
				],
			]
		);

		$this->add_control(
			'desc_style_heading',
			[
				'label'     => __( 'Description Style', 'listzen-core' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'content_typo',
				'label'    => esc_html__( 'Description Typography', 'listzen-core' ),
				'selector' => '{{WRAPPER}} .listzen-testimonial-slider .testimonial-content .description',
			]
		);

		$this->add_control(
			'content_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Description Color', 'listzen-core' ),
				'selectors' => [
					'{{WRAPPER}} .listzen-testimonial-slider .testimonial-content .description' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'content_heading_typo',
				'label'    => esc_html__( 'Heading Typography', 'listzen-core' ),
				'selector' => '{{WRAPPER}} .listzen-testimonial-slider .testimonial-content .description :is(h2, h3, h4, h5, h6)',
			]
		);

		$this->add_control(
			'content_heading_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Heading Color', 'listzen-core' ),
				'selectors' => [
					'{{WRAPPER}} .listzen-testimonial-slider .testimonial-content .description :is(h2, h3, h4, h5, h6)' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'rating_style_heading',
			[
				'label'     => __( 'Rating Style', 'listzen-core' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'rating' => 'yes',
				],
			]
		);

		$this->add_control(
			'rating_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Rating Color', 'listzen-core' ),
				'selectors' => [
					'{{WRAPPER}} .listzen-testimonial-slider .testimonial-content .star-rating' => 'color: {{VALUE}}',
				],
				'condition' => [
					'rating' => 'yes',
				],
			]
		);

		$this->add_control(
			'rating_size',
			[
				'label'     => __( 'Rating Size', 'listzen-core' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 10,
				'max'       => 50,
				'step'      => 1,
				'default'   => 20,
				'selectors' => [
					'{{WRAPPER}} .listzen-testimonial-slider .testimonial-content .star-rating' => 'font-size: {{VALUE}}px',
				],
				'condition' => [
					'rating' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Box Settings
	 *
	 * @return void
	 */
	protected function card_settings() {
		$this->start_controls_section(
			'common_style',
			[
				'label' => __( 'Common', 'listzen-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'card_style',
			[
				'label'     => esc_html__( 'Card Style', 'listzen-core' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'card_radius',
			[
				'label'      => __( 'Item Radius', 'listzen-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .listzen-testimonial-slider .testimonial-inner-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
			]
		);

		$this->add_responsive_control(
			'card_padding',
			[
				'label'      => __( 'Card Padding', 'listzen-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .listzen-testimonial-slider .testimonial-inner-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'item_center_enable',
			[
				'label'        => esc_html__( 'Item center?', 'listzen-core' ),
				'description'  => esc_html__( 'It works only for multiple columns.', 'listzen-core' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'listzen-core' ),
				'label_off'    => esc_html__( 'No', 'listzen-core' ),
				'return_value' => 'yes',
				'default'      => false,
				'prefix_class' => 'item-centered-',
				'condition'    => [
					'fade!' => 'yes',
				],
			]
		);

		// Start Icon Style Tab.
		$this->start_controls_tabs(
			'load_post_style_tabs'
		);

		// Normal Style.
		$this->start_controls_tab(
			'load_post_style_normal_tab',
			[
				'label' => __( 'Normal', 'listzen-core' ),
			]
		);
		$this->box_tab_style();

		$this->end_controls_tab();

		// Hover Style
		$this->start_controls_tab(
			'load_post_style_hover_tab',
			[
				'label' => __( 'Hover', 'listzen-core' ),
			]
		);
		$this->box_tab_style( 'hover' );

		$this->end_controls_tab();

		$this->end_controls_tabs();
		// End Icon Style Tab.

		$this->add_control(
			'main_wrap_style',
			[
				'label'     => esc_html__( 'Card Style', 'listzen-core' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name'           => 'main_wrap_bg',
				'label'          => __( 'Background', 'listzen-core' ),
				'types'          => [ 'classic', 'gradient' ],
				'fields_options' => [
					'background' => [
						'label' => esc_html__( 'Main Wrapper Background', 'listzen-core' ),
					],
				],
				'exclude'        => [ 'image' ], // phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_exclude
				'selector'       => '{{WRAPPER}} .listzen-testimonial-slider',
			]
		);

		$this->add_responsive_control(
			'wrapper_padding',
			[
				'label'      => __( 'Main Wrapper Padding', 'listzen-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .listzen-testimonial-slider' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function box_tab_style( $context = '' ) {
		$label = ( $context === 'hover' ) ? __( ':hover', 'listzen-core' ) : '';

		$this->add_control(
			"item_color$context",
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( "Text Color", 'listzen-core' ) . $label,
				'separator' => '',
				'selectors' => [
					"{{WRAPPER}} .testimonial-inner-wrap$label .testimonial-content > *" => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			"item_bg_color$context",
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( "Background Color", 'listzen-core' ) . $label,
				'separator' => '',
				'selectors' => [
					"{{WRAPPER}} .listzen-testimonial-slider .testimonial-inner-wrap$label" => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name'     => "item_shadow$context",
				'selector' => "{{WRAPPER}} .listzen-testimonial-slider .testimonial-inner-wrap$label",
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => "item_border$context",
				'label'    => __( 'Item Border', 'listzen-core' ),
				'selector' => "{{WRAPPER}} .listzen-testimonial-slider .testimonial-inner-wrap$label",
			]
		);
	}

	/**
	 * Render Content
	 *
	 * @return void
	 */
	protected function render() {
		$data      = $this->get_settings();
		$send_data = [
			'thumbnail_visibility' => $data['thumbnail_visibility'],
			'rating'               => $data['rating'],
			'thumbnail_size'       => $data['thumbnail_size'],
			'image_position'       => $data['image_position'],
			'quote_visibility'     => $data['quote_visibility'],
		];

		$layout        = $data['layout'];
		$wrapper_class = Fns::class_list( [ $layout ] );

		/*	if ( in_array( $layout, [ 'style-2', 'style-3' ] ) ) {
				$data['slider_column'] = $data['slider_column_tablet'] = $data['slider_column_mobile'] = 1;
			}*/
		?>


        <div class="listzen-testimonial-slider <?php echo esc_attr( $wrapper_class ); ?>">
            <div class="slider-wrap">
                <div class="testimonial-carousel swiper-container listzen-swiper-init"
                     data-swiper-settings="<?php echo esc_attr( htmlspecialchars( wp_json_encode( Fns::swiper_args( $data ) ) ) ); ?>">
                    <div class="swiper-wrapper">
						<?php
						foreach ( $data['items'] as $item ) :
							$item = array_merge( $item, $send_data );
							echo '<div class="swiper-slide">';
							Fns::get_template( "elementor/testimonial/{$layout}", [ 'args' => $item ] );
							echo '</div>';
						endforeach;
						?>
                    </div>

					<?php
					if ( 'yes' === $data['arrows'] ) {
						//Fns::slick_nav_html();
						echo '<div class="swiper-arrow swiper-button-next"><i class="rt-icon-arrow-small-right"></i></div><div class="swiper-arrow swiper-button-prev"><i class="rt-icon-arrow-small-left"></i></div>';
					}

					if ( 'yes' === $data['dots'] ) {
						//Fns::slick_nav_html();
						echo '<div class="swiper-pagination"></div>';
					}
					?>

                </div>

            </div>
        </div>
		<?php
	}
}

