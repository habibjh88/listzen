<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Elementor\Addons;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use Elementor\Group_Control_Border;
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use ListzenCore\Helper\Fns;
use ListzenCore\Abstracts\ElementorBase;


/**
 * Marquee Class
 */
class Marquee extends ElementorBase {

	/**
	 * Class Constructor
	 *
	 * @param $data
	 * @param $args
	 *
	 * @throws \Exception
	 */
	public function __construct( $data = [], $args = null ) {
		$this->listzen_name = esc_html__( 'Marquee', 'listzen-core' );
		$this->listzen_base = 'listzen-marquee';
		parent::__construct( $data, $args );
	}

	/**
	 * Register Controls
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->general();
		$this->common_styles();
		$this->title_style();
		$this->image_style();
		$this->icon_style();
	}

	protected function general() {
		$this->start_controls_section(
			'sec_general',
			[
				'label' => esc_html__( 'Settings ', 'listzen-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'source',
			[
				'label'        => __( 'Source', 'listzen-core' ),
				'type'         => \Elementor\Controls_Manager::SELECT,
				'default'      => 'text',
				'options'      => [
					'text'  => __( 'Text Marquee', 'listzen-core' ),
					'image' => __( 'Image Marquee', 'listzen-core' ),
				],
				'render_type'  => 'template',
				'prefix_class' => 'marquee-source-',
			]
		);

		$this->add_control(
			'enable_dark_bg',
			[
				'label'        => __( 'Dark ?', 'listzen-core' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'listzen-core' ),
				'label_off'    => __( 'No', 'listzen-core' ),
				'return_value' => 'yes',
				'default'      => 'no',
				'prefix_class' => 'marque-dark-',
			]
		);

		$this->add_control(
			'items',
			[
				'label'       => __( 'Marquee List', 'listzen-core' ),
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => [
					[
						'name'        => 'title',
						'label'       => __( 'Title', 'listzen-core' ),
						'type'        => \Elementor\Controls_Manager::TEXT,
						'default'     => __( 'Enter Name', 'listzen-core' ),
						'label_block' => true,
					],
					[
						'name'        => 'link',
						'label'       => __( 'Title Link', 'listzen-core' ),
						'type'        => Controls_Manager::URL,
						'placeholder' => __( 'https://your-link.com', 'listzen-core' ),
						'show_label'  => false,
					],
					[
						'name'        => 'style',
						'label'       => __( 'Style', 'listzen-core' ),
						'type'        => Controls_Manager::SELECT2,
						'options' => [
							'outline'           => __( 'Outline Stroke', 'listzen-core' ),
						],
					],
				],
				'default'     => [
					[ 'title' => 'Breaking News' ],
					[ 'title' => 'World Politics' ],
					[ 'title' => 'Tech Updates' ],
					[ 'title' => 'Health & Wellness' ],
					[ 'title' => 'Sports Highlights' ],
				],
				'title_field' => '{{{ title }}}',
				'condition'   => [
					'source' => 'text',
				],
			]
		);

		$this->add_control(
			'items2',
			[
				'label'       => __( 'Marquee List', 'listzen-core' ),
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => [
					[
						'name'        => 'title',
						'label'       => __( 'Title', 'listzen-core' ),
						'type'        => \Elementor\Controls_Manager::TEXT,
						'default'     => __( 'Enter Name', 'listzen-core' ),
						'label_block' => true,
					],
					[
						'name'    => 'image',
						'label'   => __( 'Choose Image', 'listzen-core' ),
						'type'    => Controls_Manager::MEDIA,
						'default' => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
					[
						'name'        => 'link',
						'label'       => __( 'Title Link', 'listzen-core' ),
						'type'        => Controls_Manager::URL,
						'placeholder' => __( 'https://your-link.com', 'listzen-core' ),
						'show_label'  => false,
					],
				],
				'default'     => [
					[ 'title' => 'Breaking News' ],
					[ 'title' => 'World Politics' ],
					[ 'title' => 'Tech Updates' ],
					[ 'title' => 'Health & Wellness' ],
					[ 'title' => 'Sports Highlights' ],
				],
				'title_field' => '{{{ title }}}',
				'condition'   => [
					'source' => 'image',
				],
			]
		);

		$this->add_responsive_control(
			'item_gap',
			[
				'type'       => Controls_Manager::SLIDER,
				'label'      => esc_html__( 'Item Gap', 'listzen-core' ),
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 20,
						'max'  => 500,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .listzen-marquee-inner' => '--itemGap: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'source' => 'image',
				],
			]
		);

		$this->add_responsive_control(
			'icon_margin',
			[
				'type'       => Controls_Manager::SLIDER,
				'mode'       => 'responsive',
				'label'      => esc_html__( 'Item Gap', 'listzen-core' ),
				'size_units' => [ 'px' ],
				'range'      => [
					'%'  => [
						'min' => 1,
						'max' => 100,
					],
					'px' => [
						'min' => 1,
						'max' => 500,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .listzen-marquee-item .icon-holder' => 'margin: 0 {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'source' => 'text',
				],
			]
		);

		$this->add_control(
			'marquee_direction',
			[
				'label'   => __( 'Marquee', 'listzen-core' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'marquee-left',
				'options' => [
					'marquee-left'  => __( 'Left Direction', 'listzen-core' ),
					'marquee-right' => __( 'Right Direction', 'listzen-core' ),
				],
			]
		);

		$this->add_responsive_control(
			'animation_speed',
			[
				'type'      => Controls_Manager::NUMBER,
				'label'     => esc_html__( 'Animation Speed (s)', 'listzen-core' ),
				'default'   => 40,
				'selectors' => [
					'{{WRAPPER}} .listzen-marquee-inner' => '--animationSpeed: {{VALUE}}s',
				],
			]
		);

		$this->add_control(
			'heading_tag',
			[
				'label'   => esc_html__( 'Title Tag', 'listzen-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'h3',
				'options' => [
					'h1' => esc_html__( 'H1', 'listzen-core' ),
					'h2' => esc_html__( 'H2', 'listzen-core' ),
					'h3' => esc_html__( 'H3', 'listzen-core' ),
					'h4' => esc_html__( 'H4', 'listzen-core' ),
					'h5' => esc_html__( 'H5', 'listzen-core' ),
					'h6' => esc_html__( 'H6', 'listzen-core' ),
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Common Styles
	 *
	 * @return void
	 */
	protected function common_styles() {
		$this->start_controls_section(
			'common_style',
			[
				'label' => esc_html__( 'Common Styles', 'listzen-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'alignment',
			[
				'label'     => __( 'Alignment', 'listzen-core' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'flex-start' => [
						'title' => __( 'Left', 'listzen-core' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center'     => [
						'title' => __( 'Center', 'listzen-core' ),
						'icon'  => 'eicon-text-align-center',
					],
					'flex-end'   => [
						'title' => __( 'Right', 'listzen-core' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .listzen-marquee-item .marquee-logo' => 'align-items: {{VALUE}};',
				],
				'condition' => [
					'source' => 'image',
				],
			]
		);

		$this->add_responsive_control(
			'item_width',
			[
				'label'      => esc_html__( 'Item Width (min)', 'listzen-core' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 5,
					],
					'%'  => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .marquee-logo' => 'min-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'box_bg_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Background Color', 'listzen-core' ),
				'selectors' => [
					'{{WRAPPER}} .listzen-marquee-slider .listzen-marquee-inner' => '--marqueBg: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'box_radius',
			[
				'label'      => __( 'Border Radius', 'listzen-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .listzen-marquee-slider .listzen-marquee-inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
			]
		);

		$this->add_responsive_control(
			'box_rotation',
			[
				'type'      => Controls_Manager::NUMBER,
				'label'     => esc_html__( 'Rotation', 'listzen-core' ),
				'selectors' => [
					'{{WRAPPER}} .listzen-marquee-slider' => 'transform: rotate({{VALUE}}deg)',
				],
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'box_padding',
			[
				'label'      => __( 'Padding', 'listzen-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .listzen-marquee-slider .listzen-marquee-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
				'separator'  => 'before',
			]
		);

		$this->add_responsive_control(
			'box_margin',
			[
				'label'      => __( 'Margin', 'listzen-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .listzen-marquee-slider' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Title Style
	 *
	 * @return void
	 */
	protected function title_style() {
		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title Style', 'listzen-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typo',
				'label'    => esc_html__( 'Title Typography', 'listzen-core' ),
				'selector' => '{{WRAPPER}} .listzen-marquee-item .entry-title',
			]
		);


		$this->add_responsive_control(
			'stroke_width',
			[
				'type'       => Controls_Manager::SLIDER,
				'mode'       => 'responsive',
				'label'      => esc_html__( 'Stroke Width', 'listzen-core' ),
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 0.1,
						'max'  => 10,
						'step' => 0.1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .listzen-marquee-item .entry-title' => '--titleStrokeWidth: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'stroke_fill_color',
			[
				'type'        => Controls_Manager::COLOR,
				'label'       => esc_html__( 'Stroke Fill Color', 'listzen-core' ),
				'selectors'   => [
					'{{WRAPPER}} .listzen-marquee-item .title' => '--titleFillColor: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'title_gradient',
			[
				'label'        => __( 'Enable Gradient', 'listzen-core' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'listzen-core' ),
				'label_off'    => __( 'No', 'listzen-core' ),
				'return_value' => 'yes',
				'default'      => 'no',
				'prefix_class' => 'title-gradient-',
				'render_type'  => 'template',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name'      => 'title_gradient',
				'types'     => [ 'gradient' ],
				'selector'  => '{{WRAPPER}}.title-gradient-yes .listzen-marquee-item .title',
				'condition' => [
					'title_gradient' => 'yes',
				],
			]
		);

		$this->add_control(
			'title_color',
			[
				'type'        => Controls_Manager::COLOR,
				'label'       => esc_html__( 'Title Color', 'listzen-core' ),
				'description' => esc_html__( 'This color can be applied as either the title’s outline or fill also, depending on the settings above.”', 'listzen-core' ),
				'selectors'   => [
					'{{WRAPPER}} .listzen-marquee-item ' => '--titleColor: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'title_hover_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Title Color:hover', 'listzen-core' ),
				'selectors' => [
					'{{WRAPPER}} .listzen-marquee-item' => '--titleHover: {{VALUE}}',
				],
				'condition' => [
					'title_gradient!' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Image Style
	 *
	 * @return void
	 */
	protected function image_style() {
		$this->start_controls_section(
			'image_style',
			[
				'label'     => esc_html__( 'Image Style', 'listzen-core' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'source' => 'image',
				],
			]
		);

		$this->add_responsive_control(
			'image_width',
			[
				'type'       => Controls_Manager::SLIDER,
				'label'      => esc_html__( 'Image Width', 'listzen-core' ),
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 30,
						'max'  => 500,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .listzen-marquee-item .image-wrap img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_height',
			[
				'type'       => Controls_Manager::SLIDER,
				'label'      => esc_html__( 'Image Height (optional)', 'listzen-core' ),
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 20,
						'max'  => 500,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .listzen-marquee-item .image-wrap img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'img_object_fit',
			[
				'label'       => __( 'Object Fit', 'listzen-core' ),
				'description' => __( 'It works when custom width and height are applied above.', 'listzen-core' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'cover',
				'options'     => [
					'cover'   => __( 'Cover', 'listzen-core' ),
					'contain' => __( 'Contain', 'listzen-core' ),
				],
				'selectors'   => [
					'{{WRAPPER}} .listzen-marquee-item .image-wrap img' => 'object-fit: {{SIZE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'img_border',
				'label'    => __( 'Image Border', 'listzen-core' ),
				'selector' => '{{WRAPPER}} .listzen-marquee-item .image-wrap',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'img_box_shadow',
				'selector' => '{{WRAPPER}} .listzen-marquee-item .image-wrap',
			]
		);

		$this->add_responsive_control(
			'img_radius',
			[
				'label'      => __( 'Border Radius', 'listzen-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .listzen-marquee-slider .image-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Css_Filter::get_type(),
			[
				'name'     => 'image_filters',
				'selector' => '{{WRAPPER}} .listzen-marquee-slider .marquee-logo .image-wrap img',
			]
		);

		$this->add_control(
			'overlay_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Overlay Color', 'listzen-core' ),
				'selectors' => [
					'{{WRAPPER}} .listzen-marquee-slider .marquee-logo .image-wrap .overlay' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'overlay_color_hover',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Overlay Color:hover', 'listzen-core' ),
				'selectors' => [
					'{{WRAPPER}} .listzen-marquee-slider .marquee-logo .image-wrap:hover .overlay' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function icon_style() {
		// Icon setting
		$this->start_controls_section(
			'icon_style',
			[
				'label'     => esc_html__( 'Icon Settings', 'listzen-core' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'source' => 'text',
				],
			]
		);

		$this->add_control(
			'marquee_icon',
			[
				'label'            => __( 'Choose Icon', 'listzen-core' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'default'          => [
					'value'   => 'fas fa-angle-right',
					'library' => 'fa-solid',
				],
			]
		);
		$this->add_control(
			'icon_animation',
			[
				'label'     => esc_html__( 'Animation', 'listzen-core' ),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 'none',
				'options'   => [
					'none'       => esc_html__( '-Select-', 'listzen-core' ),
					'spin'   => esc_html__( 'Spin', 'listzen-core' ),
					'spin reverse'   => esc_html__( 'Spin Reverse', 'listzen-core' ),
				],
				'selectors' => [
					'{{WRAPPER}} .listzen-marquee-item .icon-holder' => 'animation: {{VALUE}} 5s infinite linear;',
				],
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'type'       => Controls_Manager::SLIDER,
				'label'      => esc_html__( 'Icon Size', 'listzen-core' ),
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 0.1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .listzen-marquee-item' => '--iconSize: {{SIZE}}{{UNIT}};',
				],

			]
		);

		$this->add_control(
			'icon_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Icon Color', 'listzen-core' ),
				'selectors' => [
					'{{WRAPPER}} .listzen-marquee-item .icon-holder' => '--iconColor: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Content Render
	 *
	 * @return void
	 */
	protected function render() {
		$data   = $this->get_settings();
		$source = $data['source'];
		Fns::get_template( "elementor/marquee/$source", $data );
	}

}
