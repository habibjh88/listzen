<?php

namespace ListzenCore\Elementor\Addons;

use Elementor\Plugin;
use ListzenCore\Abstracts\ElementorBase;
use ListzenCore\Helper\Fns;
use ListzenCore\Traits\PostTraits;
use ListzenCore\Elementor\Renderers\PostGridRenderer;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PostGrid Class
 */
class PostGrid extends ElementorBase {

	use PostTraits;

	public $prefix;

	/**
	 * Class Constructor
	 *
	 * Initializes the module with provided data and arguments.
	 *
	 * @param array $data Data to initialize the module.
	 * @param mixed $args Optional additional arguments.
	 *
	 * @throws \Exception If the parent constructor fails to initialize properly.
	 */
	public function __construct( $data = [], $args = null ) {
		$this->listzen_name = esc_html__( 'Post Grid', 'listzen-core' );
		$this->prefix         = 'grid';
		$this->listzen_base = 'listzen-post-' . $this->prefix;
		parent::__construct( $data, $args );
	}

	public function custom_script_depends( $settings ) {
		if ( 'yes' === $settings['masonry_layout'] ) {
			wp_enqueue_script( 'jquery-masonry' );
		}
	}


	/**
	 * Register Controls
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->layout();
		$this->query();
		$this->thumbnail_settings();
		$this->title_settings();
		$this->excerpt_settings();
		$this->meta_settings();
		$this->readmore_settings();
		$this->post_card_settings();
	}

	/**
	 * Content Render
	 *
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings();
		$this->custom_script_depends( $settings );
		$renderer = new PostGridRenderer( $settings );
		$renderer->render();
	}
}