<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Elementor\Addons;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Icons_Manager;
use Elementor\Modules\DynamicTags\Module as TagsModule;
use \ListzenCore\Helper\Fns;
use ListzenCore\Abstracts\ElementorBase;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * VideoIcon Class
 */
class VideoIcon extends ElementorBase {

	/**
	 * Class Constructor
	 *
	 * @param $data
	 * @param $args
	 *
	 * @throws \Exception
	 */
	public function __construct( $data = [], $args = null ) {
		$this->listzen_name = esc_html__( 'Video Button', 'listzen-core' );
		$this->listzen_base = 'listzen-video-icon';
		parent::__construct( $data, $args );
	}

	public function get_script_depends() {
		return [ 'listzen-magnific-popup' ];
	}

	public function get_style_depends() {
		return [ 'listzen-magnific-popup' ];
	}

	/**
	 * Register Controls
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->general_settings();
		$this->button_settings();
		$this->image_settings();
	}

	/**
	 * General Settings
	 * @return void
	 */
	protected function general_settings() {
		$this->start_controls_section(
			'sec_general',
			[
				'label' => esc_html__( 'General', 'listzen-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'style',
			[
				'label'        => __( 'Style', 'listzen-core' ),
				'type'         => \Elementor\Controls_Manager::SELECT,
				'default'      => 'backgrounded',
				'options'      => [
					'backgrounded' => esc_html__( 'Backgrounded', 'listzen-core' ),
					'bordered'     => esc_html__( 'Bordered', 'listzen-core' ),
				],
				'prefix_class' => 'ripple-',
			]
		);


		$this->add_control(
			'video_url',
			[
				'label'       => __( 'Video URL', 'listzen-core' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your URL', 'listzen-core' ),
				'default'     => 'https://www.youtube.com/watch?v=1iIZeIy7TqM',
				'label_block' => true,
			]
		);

		$this->add_control(
			'button_text',
			[
				'label'       => __( 'Button Text', 'listzen-core' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter button text', 'listzen-core' ),
				'label_block' => true,
			]
		);


		$this->add_control(
			'text_align',
			[
				'label'     => __( 'Alignment', 'listzen-core' ),
				'type'      => \Elementor\Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => __( 'Left', 'listzen-core' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'listzen-core' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => __( 'Right', 'listzen-core' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .listzen-video-icon-wrapper' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function image_settings() {
		$this->start_controls_section(
			'image_settings',
			[
				'label' => esc_html__( 'Image Style', 'listzen-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name'           => 'video',
				'label'          => __( 'Background Image', 'listzen-core' ),
				'types'          => [ 'classic' ],
				'fields_options' => [
					'background' => [
						'label' => esc_html__( 'Choose Image', 'listzen-core' ),
					],
					'position'   => [
						'default' => 'center center',
					],
					'size'       => [
						'default' => 'cover',
					],
				],
				'exclude'        => [ 'gradient', 'video', 'color' ], // phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_exclude
				'selector'       => '{{WRAPPER}} .listzen-video-icon-wrapper',
			]
		);

		$this->add_responsive_control(
			'image_height',
			[
				'type'       => Controls_Manager::SLIDER,
				'label'      => esc_html__( 'Image Height', 'listzen-core' ),
				'size_units' => [ 'px', 'vh' ],
				'range'      => [
					'px' => [
						'min' => 100,
						'max' => 2000,
					],
					'vh' => [
						'min' => 5,
						'max' => 100,
					],
				],
				'condition'  => [
					'video_image[url]!' => ''
				],
				'selectors'  => [
					'{{WRAPPER}} .listzen-video-icon-wrapper.has-image' => 'height: {{SIZE}}{{UNIT}};',
				],
				'separator'  => 'before',
			]
		);

		$this->add_responsive_control(
			'image_radius',
			[
				'label'      => __( 'Radius', 'listzen-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .listzen-video-icon-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};overflow:hidden;',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name'           => 'image_overlay',
				'label'          => __( 'Background', 'listzen-core' ),
				'types'          => [ 'classic', 'gradient' ],
				'fields_options' => [
					'background' => [
						'label' => esc_html__( 'Overlay', 'listzen-core' ),
					],
				],
				'exclude'        => [ 'image' ], // phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_exclude
				'selector'       => '{{WRAPPER}} .listzen-video-icon-wrapper.has-image::before',
				'condition'      => [
					'video_image[url]!' => ''
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'video-border',
				'label'    => __( 'Video Border', 'listzen-core' ),
				'selector' => '{{WRAPPER}} .listzen-video-icon-wrapper',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'video_box_shadow',
				'selector' => '{{WRAPPER}} .listzen-video-icon-wrapper',
			]
		);

		$this->end_controls_section();
	}


	/**
	 * Button Settings
	 * @return void
	 */
	protected function button_settings() {
		$this->start_controls_section(
			'button_style',
			[
				'label' => esc_html__( 'Play Button Style', 'listzen-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'button_size',
			[
				'label'      => __( 'Button Size', 'listzen-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 30,
						'max'  => 300,
						'step' => 5,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .listzen-video-icon-wrapper .video-popup-icon' => 'width:{{SIZE}}px;height:{{SIZE}}px;',
				],
			]
		);

		$this->add_control(
			'button_icon',
			[
				'label' => esc_html__( 'Choose Icon', 'listzen-core' ),
				'type'  => \Elementor\Controls_Manager::ICONS,
			]
		);

		$this->start_controls_tabs(
			'button_style_tabs'
		);

		$this->start_controls_tab(
			'button_style_normal_tab',
			[
				'label' => __( 'Normal', 'listzen-core' ),
			]
		);

		$this->add_control(
			'icon_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Play Icon Color', 'listzen-core' ),
				'selectors' => [
					'{{WRAPPER}} .listzen-video-icon-wrapper .video-popup-icon' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'icon_bg_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Button Background', 'listzen-core' ),
				'selectors' => [
					'{{WRAPPER}} .listzen-video-icon-wrapper .video-popup-icon' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'button_style_hover_tab',
			[
				'label' => __( 'Hover', 'listzen-core' ),
			]
		);

		$this->add_control(
			'button_color_hover',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Play Icon Hover', 'listzen-core' ),
				'selectors' => [
					'{{WRAPPER}} .listzen-video-icon-wrapper .video-popup-icon:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'button_bg_color_hover',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Button Background Hover', 'listzen-core' ),
				'selectors' => [
					'{{WRAPPER}} .listzen-video-icon-wrapper .video-popup-icon:hover' => 'background-color: {{VALUE}}',
				],
			]
		);


		$this->end_controls_tab();


		$this->add_control(
			'ripple_style',
			[
				'label'     => __( 'Ripple Style', 'listzen-core' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);


		$this->add_control(
			'ripple_circle_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Ripple Color', 'listzen-core' ),
				'selectors' => [
					'{{WRAPPER}}.ripple-backgrounded .ripple-circle' => '--rippleColor: {{VALUE}}',
					'{{WRAPPER}}.ripple-bordered .video-popup-icon'  => '--rippleColor2: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tabs();


		$this->add_control(
			'text_style',
			[
				'label'     => __( 'Text Style', 'listzen-core' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'button_text!' => ''
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'      => 'content_typography',
				'label'     => __( 'Text Typography', 'listzen-core' ),
				'selector'  => '{{WRAPPER}} .listzen-video-icon-wrapper .button-text',
				'condition' => [
					'button_text!' => ''
				]
			]
		);

		$this->add_control(
			'text_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Text Color', 'listzen-core' ),
				'selectors' => [
					'{{WRAPPER}} .listzen-video-icon-wrapper .button-text' => 'color: {{VALUE}}',
				],
				'condition' => [
					'button_text!' => ''
				]
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Content Render
	 *
	 * @return void
	 */
	protected function render() {
		$data = $this->get_settings();

		$classess = '';
		if ( ! empty( $video_image['url'] ) ) {
			$classess = 'has-image';
		}
		?>

        <div class="listzen-video-icon-wrapper <?php echo esc_attr( $classess ) ?>">
            <div class="icon-box">
                <a class="listzen-popup-video video-popup-icon btn-target-animation" href="<?php echo esc_url( $data['video_url'] ) ?>">
					<?php
					if ( ! empty( $button_icon['value'] ) ) {
						Icons_Manager::render_icon( $button_icon, [ 'aria-hidden' => 'true' ] );
					} else {
						echo "<i class='rt-icon-play-solid'></i>";
					}
					?>
                    <span class="ripple-circle"></span>
                </a>

				<?php if ( $data['button_text'] ) : ?>
                    <span class="button-text"><?php echo esc_html( $data['button_text'] ) ?></span>
				<?php endif ?>
            </div>
        </div>
		<?php

	}

}