<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Elementor\Addons;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use Elementor\Controls_Manager;
use ListzenCore\Abstracts\ElementorBase;

/**
 * Marquee Class
 */
class MenuIconGroup extends ElementorBase {

	/**
	 * Class Constructor
	 *
	 * @param $data
	 * @param $args
	 *
	 * @throws \Exception
	 */
	public function __construct( $data = [], $args = null ) {
		$this->listzen_name = esc_html__( 'Menu Icon Group', 'listzen-core' );
		$this->listzen_base = 'listzen-menu-icon-group';
		parent::__construct( $data, $args );
	}

	/**
	 * Register Controls
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->general();
		$this->style_tab();
	}

	protected function general() {
		$this->start_controls_section(
			'sec_general',
			[
				'label' => esc_html__( 'Settings', 'listzen-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'hamburg',
			[
				'label'        => esc_html__( 'Off Canvas Icon?', 'listzen-core' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'On', 'listzen-core' ),
				'label_off'    => esc_html__( 'Off', 'listzen-core' ),
				'return_value' => 'on',
				'default'      => 'on',
			]
		);

		$this->add_control(
			'login',
			[
				'label'        => esc_html__( 'Login Icon?', 'listzen-core' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'On', 'listzen-core' ),
				'label_off'    => esc_html__( 'Off', 'listzen-core' ),
				'return_value' => 'on',
				'default'      => 'on',
			]
		);
		$this->add_control(
			'login_text',
			[
				'label'        => esc_html__( 'Login Text?', 'listzen-core' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'On', 'listzen-core' ),
				'label_off'    => esc_html__( 'Off', 'listzen-core' ),
				'return_value' => 'on',
				'default'      => 'on',
			]
		);

		$this->add_control(
			'search',
			[
				'label'        => esc_html__( 'Search Icon?', 'listzen-core' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'On', 'listzen-core' ),
				'label_off'    => esc_html__( 'Off', 'listzen-core' ),
				'return_value' => 'on',
				'default'      => 'on',
			]
		);

		$this->add_control(
			'has_separator',
			[
				'label'        => esc_html__( 'Enable Separator', 'listzen-core' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'On', 'listzen-core' ),
				'label_off'    => esc_html__( 'Off', 'listzen-core' ),
				'return_value' => 'on',
				'default'      => false,
			]
		);

		$this->add_control(
			'button1',
			[
				'label'     => esc_html__( 'Button 1', 'listzen-core' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'button',
			[
				'label'        => esc_html__( 'Button-1?', 'listzen-core' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'On', 'listzen-core' ),
				'label_off'    => esc_html__( 'Off', 'listzen-core' ),
				'return_value' => 'on',
				'default'      => 'on',
			]
		);
		$this->add_control(
			'button_link',
			[
				'label'       => esc_html__( 'Button-1 Link', 'listzen-core' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'options'     => [ 'url', 'is_external', 'nofollow' ],
				'default'     => [
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				],
				'label_block' => true,
				'condition'   => [
					'button' => 'on',
				],
			]
		);
		$this->add_control(
			'button_label',
			[
				'label'       => esc_html__( 'Button-1 Label', 'listzen-core' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Type your title here', 'listzen-core' ),
				'default'     => esc_html__( 'Get Started', 'listzen-core' ),
				'dynamic'     => [
					'active' => true,
				],
				'condition'   => [
					'button' => 'on',
				],
			]
		);

		$this->add_control(
			'button2',
			[
				'label'     => esc_html__( 'Add Listing Button', 'listzen-core' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'add_listing_button',
			[
				'label'        => esc_html__( 'Add Listing button?', 'listzen-core' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'On', 'listzen-core' ),
				'label_off'    => esc_html__( 'Off', 'listzen-core' ),
				'return_value' => 'on',
				'default'      => 'on',
			]
		);
		$this->add_control(
			'listing_button_link',
			[
				'label'       => esc_html__( 'Add Listing Link', 'listzen-core' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'options'     => [ 'url', 'is_external', 'nofollow' ],
				'default'     => [
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				],
				'label_block' => true,
				'condition'   => [
					'add_listing_button' => 'on',
				],
			]
		);
		$this->add_control(
			'listing_button_label',
			[
				'label'       => esc_html__( 'Add Listing Label', 'listzen-core' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Type your title here', 'listzen-core' ),
				'default'     => esc_html__( 'Add Listing', 'listzen-core' ),
				'dynamic'     => [
					'active' => true,
				],
				'condition'   => [
					'add_listing_button' => 'on',
				],
			]
		);

		$this->end_controls_section();


	}


	protected function style_tab() {
		$this->start_controls_section(
			'icon_group_style',
			[
				'label' => esc_html__( 'Style', 'listzen-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control( 'icon_color', [
			'label'     => __( 'Icon Color', 'listzen-core' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .el-menu-icon-group-wrapper .menu-icon-wrapper a' => 'color: {{VALUE}}',
			],
		] );
		$this->add_control( 'icon_color_hover', [
			'label'     => __( 'Icon Color:hover', 'listzen-core' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .el-menu-icon-group-wrapper .menu-icon-wrapper a:hover' => 'color: {{VALUE}}',
			],
		] );
		$this->add_control( 'separator_color', [
			'label'     => __( 'Separator Color', 'listzen-core' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .el-menu-icon-group-wrapper .menu-icon-wrapper .has-separator li' => '--listzen-meta-color: {{VALUE}}',
			],
			'condition' => [
				'has_separator' => 'on',
			],
		] );


		$this->add_control(
			'button_style',
			[
				'label'     => esc_html__( 'Button Style', 'listzen-core' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control( //add_responsive_control
			'btn_padding',
			[
				'label'      => esc_html__( 'Padding', 'listzen-core' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .el-menu-icon-group-wrapper li.listzen-button .btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'btn_height',
			[
				'label'      => esc_html__( 'Height', 'listzen-core' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					]
				],
				'selectors'  => [
					'{{WRAPPER}} .el-menu-icon-group-wrapper li.listzen-button .btn' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs(
			'btn_style_tabs'
		);

		$this->start_controls_tab(
			'btn_style_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'listzen-core' ),
			]
		);

		$this->add_control(
			'backdrop_filter',
			[
				'label'      => esc_html__( 'Backdrop filter', 'listzen-core' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 20,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .el-menu-icon-group-wrapper li.listzen-button .btn' => 'backdrop-filter: blur({{SIZE}}px);',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name'     => 'button_border',
				'selector' => '{{WRAPPER}} .el-menu-icon-group-wrapper li.listzen-button .btn',
			]
		);
		$this->add_control( 'button_color', [
			'label'     => __( 'Button Color', 'listzen-core' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .el-menu-icon-group-wrapper li.listzen-button .btn' => 'color: {{VALUE}}',
			],
		] );

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name'     => 'button_bg_color',
				'label'    => __( 'Button Background', 'listzen-core' ),
				'types'    => [ 'classic', 'gradient' ],
				'exclude'  => [ 'image' ], // phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_exclude
				'selector' => '{{WRAPPER}} .el-menu-icon-group-wrapper li.listzen-button .btn',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'style_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'listzen-core' ),
			]
		);
		$this->add_control(
			'backdrop_filter_hover',
			[
				'label'      => esc_html__( 'Backdrop filter:hover', 'listzen-core' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 20,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .el-menu-icon-group-wrapper li.listzen-button .btn:hover' => 'backdrop-filter: blur({{SIZE}}px);',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name'     => 'button_border_hover',
				'selector' => '{{WRAPPER}} .el-menu-icon-group-wrapper li.listzen-button .btn:hover',
			]
		);
		$this->add_control( 'button_color_hover', [
			'label'     => __( 'Button Color:hover', 'listzen-core' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .el-menu-icon-group-wrapper li.listzen-button .btn:hover' => 'color: {{VALUE}}',
			],
		] );

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name'     => 'button_bg_color_hover',
				'types'    => [ 'classic', 'gradient' ],
				'exclude'  => [ 'image' ], // phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_exclude
				'selector' => '{{WRAPPER}} .el-menu-icon-group-wrapper li.listzen-button .btn:hover',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();


		$this->end_controls_section();
	}

	/**
	 * Content Render
	 *
	 * @return void
	 */
	protected function render() {
		$settings         = $this->get_settings();
		$nav_drawer_style = '1';

		$args = [
			'hamburg'              => $settings['hamburg'],
			'search'               => $settings['search'],
			'login'                => $settings['login'],
			'login_text'           => $settings['login_text'],
			'button'               => $settings['button'],
			'button_link'          => $settings['button_link']['url'] ?? '',
			'button_label'         => $settings['button_label'],
			'listing_button'       => $settings['add_listing_button'],
			'listing_button_link'  => $settings['listing_button_link']['url'] ?? '',
			'listing_button_label' => $settings['listing_button_label'],
			'has_separator'        => $settings['has_separator'],
		];

		echo "<div class='el-menu-icon-group-wrapper'>";
		listzen_menu_icons_group( $args );
		echo "</div>";

		if ( $settings['search'] ) {
			get_template_part( 'template-parts/header/header', 'search' );
		}

		get_template_part( 'template-parts/header/nav-drawer', $nav_drawer_style );
	}

}
