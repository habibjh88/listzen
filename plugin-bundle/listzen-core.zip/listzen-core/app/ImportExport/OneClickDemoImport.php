<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\ImportExport;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use Elementor\Plugin;
use \FW_Ext_Backups_Demo;
use ListzenCore\Traits\SingletonTraits;
use Rtcl\Models\Form\Form;

/**
 * OneClickDemoImport class
 */
//phpcs:disable
class OneClickDemoImport {
	/**
	 * Singleton traits
	 */
	use SingletonTraits;

	private $demo_base_url = 'https://www.radiustheme.com/demo/wordpress/themes/listzen/';

	/**
	 * Class constructor
	 */
	public function __construct() {
		if ( ! class_exists( 'OCDI_Plugin' ) ) {
			return;
		}
		add_filter( 'ocdi/import_files', [ $this, 'demo_config' ] );
		add_filter( 'ocdi/before_content_import', [ $this, 'before_import' ] );
		add_filter( 'ocdi/after_import', [ $this, 'after_import' ] );
		add_action( 'ocdi/before_widgets_import', [ $this, 'remove_default_widgets' ] );
		add_filter( 'ocdi/disable_pt_branding', '__return_true' );
		add_filter( 'ocdi/regenerate_thumbnails_in_content_import', '__return_false' );
		add_action( 'init', [ $this, 'rewrite_flush_check' ] );
		add_action( 'admin_footer', [ $this, 'footer_style' ] );
	}

	/**
	 * Demo configuration
	 *
	 * @return array
	 */
	public function demo_config() {
		$base_url    = trailingslashit( $this->demo_base_url );
		$demos_array = [
			'demo1' => [
				'title'        => __( 'Home 1', 'listzen-core' ),
				'page'         => __( 'Home 1', 'listzen-core' ),
				'screenshot'   => trailingslashit( LISTZEN_CORE_BASE_URL ) . 'assets/images/screenshots/1.webp',
				'preview_link' => $base_url,
			],
			'demo2' => [
				'title'        => __( 'Home 2', 'listzen-core' ),
				'page'         => __( 'Home 2', 'listzen-core' ),
				'screenshot'   => trailingslashit( LISTZEN_CORE_BASE_URL ) . 'assets/images/screenshots/2.webp',
				'preview_link' => $base_url . 'home-2/',
			],
			'demo3' => [
				'title'        => __( 'Home 3', 'listzen-core' ),
				'page'         => __( 'Home 3', 'listzen-core' ),
				'screenshot'   => trailingslashit( LISTZEN_CORE_BASE_URL ) . 'assets/images/screenshots/3.webp',
				'preview_link' => $base_url . 'home-3/',
			],
			'demo4' => [
				'title'        => __( 'Home 4', 'listzen-core' ),
				'page'         => __( 'Home 4', 'listzen-core' ),
				'screenshot'   => trailingslashit( LISTZEN_CORE_BASE_URL ) . 'assets/images/screenshots/4.webp',
				'preview_link' => $base_url . 'home-4/',
			],
			'demo5' => [
				'title'        => __( 'Home 5', 'listzen-core' ),
				'page'         => __( 'Home 5', 'listzen-core' ),
				'screenshot'   => trailingslashit( LISTZEN_CORE_BASE_URL ) . 'assets/images/screenshots/5.webp',
				'preview_link' => $base_url . 'home-5/',
			],
		];

		$config      = [];
		$import_path = trailingslashit( LISTZEN_CORE_BASE_DIR ) . 'sample-data/';

		foreach ( $demos_array as $key => $demo ) {
			$config[] = [
				'import_file_id'               => $key,
				'import_page_name'             => $demo['page'],
				'import_file_name'             => $demo['title'],
				'local_import_file'            => $import_path . 'contents.xml',
				'local_import_widget_file'     => $import_path . 'widgets.wie',
				'local_import_customizer_file' => $import_path . 'customizer.dat',
				'import_preview_image_url'     => $demo['screenshot'],
				'preview_url'                  => $demo['preview_link'],
			];
		}

		return $config;
	}

	/**
	 * Before import
	 *
	 * @param $selected_import
	 *
	 * @return void
	 */
	public function before_import( $selected_import ) {
		$this->remove_default_rtcl_pages();
		$this->remove_rtcl_builder_default_form();
		$this->set_elementor_settings();
		//RTCL options updated early otherwise some settings can mistake during import.
		$this->rtcl_options_before_migration();
		$this->remove_old_elementor_active_kit();
	}

	/**
	 * After import
	 *
	 * @param $selected_import
	 *
	 * @return void
	 */
	public function after_import( $selected_import ) {
		flush_rewrite_rules();
		$this->assign_menu( $selected_import['import_file_id'] );
		$this->assign_frontpage( $selected_import );
		//		$this->update_contact_form_sender_email();
		$this->site_widde_modify();
		$this->update_permalinks();
		$this->rtcl_options_after_migration();
		$this->rtcl_taxonomy_migration();
		$this->rtcl_ajax_filter_migration();
		$this->import_rtcl_forms();
		new UserImportExport();
		$this->set_elementor_active_kit();
		$this->url_replace();

		flush_rewrite_rules();
		update_option( 'listzen_ocdi_importer_rewrite_flash', true );
	}

	function site_widde_modify() {
		// Get the "Hello World!" post by title.
		$post_id = $this->get_page_by_title( 'Hello World!', 'post' );

		if ( $post_id ) {
			wp_trash_post( $post_id );
		}

		update_option( 'rtcl_listing_types', [
			'sell' => esc_html__( 'Sell', 'listzen-core' ),
			'buy'  => esc_html__( 'Buy', 'listzen-core' ),
			'rent' => esc_html__( 'Rent', 'listzen-core' ),
		] );
	}

	public function rtcl_options_before_migration() {
		$formFile = trailingslashit( LISTZEN_CORE_BASE_DIR ) . 'sample-data/rtcl-options.json';
		if ( file_exists( $formFile ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			$options_data = json_decode( file_get_contents( $formFile ), true );

			if ( $options_data && is_array( $options_data ) ) {
				foreach ( $options_data as $value ) {
					$key   = $value['key'] ?? null;
					$value = $value['value'] ?? null;
					if ( $key && $value ) {
						if ( 'rtcl_advanced_settings' === $key ) {
							unset( $value['listings'] );
							unset( $value['listing_form'] );
							unset( $value['checkout'] );
							unset( $value['myaccount'] );

						}
						update_option( $key, $value );
					}
				}
			}
		}
	}

	public function rtcl_options_after_migration() {
		$rtcl_advanced_settings                 = get_option( 'rtcl_advanced_settings' );
		$rtcl_advanced_settings['listings']     = $this->get_page_by_title( 'Listings' );
		$rtcl_advanced_settings['listing_form'] = $this->get_page_by_title( 'Listing Form' );
		$rtcl_advanced_settings['checkout']     = $this->get_page_by_title( 'Checkout' );
		$rtcl_advanced_settings['myaccount']    = $this->get_page_by_title( 'My Account' );
		$rtcl_advanced_settings['compare_page'] = $this->get_page_by_title( 'Compare' );
		$rtcl_advanced_settings['store']        = $this->get_page_by_title( 'Store' );
		update_option( 'rtcl_advanced_settings', $rtcl_advanced_settings );
	}

	public function rtcl_ajax_filter_migration() {
		$ajaxFilter = trailingslashit( LISTZEN_CORE_BASE_DIR ) . 'sample-data/rtcl-ajax-filter.json';
		if ( file_exists( $ajaxFilter ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			$data = json_decode( file_get_contents( $ajaxFilter ), true );
			update_option( 'rtcl_filter_settings', $data );
		}
	}

	public function replaceTaxonomy( &$array, $tax_ids ) {
		if ( ! empty( $array ) ) {
			foreach ( $array as $key => &$value ) {
				//Array: Elementor keys collection for taxonomy
				if ( ! in_array( $key, [ "location", "cats" ] ) ) {
					if ( is_array( $value ) ) {
						$this->replaceTaxonomy( $value, $tax_ids );
					}
				} else {
					if ( is_array( $value ) ) {
						$new_value = [];
						foreach ( $value as $id ) {
							if ( isset( $tax_ids[ $id ] ) ) {
								$new_value[] = $tax_ids[ $id ];
							}
						}
						$value = $new_value;
					} else {
						$value = $tax_ids[ $value ] ?? '';
					}
				}
			}
		}
	}

	public function get_old_tax_info() {
		return [
			'rtcl_location' => [
				'austin'        => 30,
				'bangladesh'    => 61,
				'buffalo'       => 27,
				'california'    => 16,
				'canada'        => 48,
				'chicago'       => 24,
				'china'         => 56,
				'dhaka'         => 62,
				'florida'       => 20,
				'france'        => 59,
				'guangzhou'     => 57,
				'illinois'      => 23,
				'india'         => 60,
				'jacksonville'  => 21,
				'khulna'        => 63,
				'los-angeles'   => 17,
				'miami'         => 22,
				'mumbai'        => 52,
				'new-york'      => 26,
				'new-york-city' => 28,
				'ottawa'        => 50,
				'paris'         => 54,
				'pune'          => 53,
				'saint-denis'   => 55,
				'san-diego'     => 18,
				'san-francisco' => 19,
				'shenzhen'      => 58,
				'springfield'   => 25,
				'sydney'        => 51,
				'texas'         => 29,
				'toronto'       => 49
			],
			'rtcl_category' => [
				'automotive'   => 39,
				'beauty-spas'  => 38,
				'cafe'         => 11,
				'car'          => 42,
				'event'        => 40,
				'gym-fitness'  => 8,
				'home-service' => 9,
				'hospital'     => 15,
				'hotel'        => 10,
				'museum'       => 12,
				'music'        => 13,
				'real-estate'  => 41,
				'restaurant'   => 14,
				'shopping'     => 37
			],
		];
	}

	private function taxonomy_old_new_map( $old_tqxonomies_id ) {
		$new_taxonomy_ids = [];
		foreach ( $old_tqxonomies_id as $tax => $taxonomies ) {
			foreach ( $taxonomies as $slug => $id ) {
				$term = get_term_by( 'slug', $slug, $tax );
				if ( $term && isset( $term->term_id ) ) {
					$new_taxonomy_ids[ $id ] = $term->term_id;
				}
			}
		}

		return $new_taxonomy_ids;
	}

	public function rtcl_taxonomy_migration() {

		/**
		 * To generate the below data use this query string: ?taxonomy=rtcl_location || rtcl_category
		 */
		$old_tqxonomies_id = $this->get_old_tax_info();

		$args  = [
			'post_type'      => 'page',
			'post_status'    => 'publish',
			'posts_per_page' => - 1,
			'fields'         => 'ids',
			'meta_query'     => [
				[
					'key'     => '_elementor_data',
					'compare' => 'EXISTS',
				],
			],
		];
		$query = get_posts( $args );

		foreach ( $query as $page_id ) {
			$meta_json = get_post_meta( $page_id, '_elementor_data', true );
			$meta_data = json_decode( $meta_json, true );

			$new_taxonomy_ids = $this->taxonomy_old_new_map( $old_tqxonomies_id );

			if ( ! empty( $new_taxonomy_ids ) ) {
				$this->replaceTaxonomy( $meta_data, $new_taxonomy_ids );
				$updatedJson = wp_slash( wp_json_encode( $meta_data ) );
				update_post_meta( $page_id, '_elementor_data', $updatedJson );

				Plugin::instance()->files_manager->clear_cache();
			}
		}
	}

	private function import_rtcl_forms() {
		$formFile = trailingslashit( LISTZEN_CORE_BASE_DIR ) . 'sample-data/rtcl-form.json';

		$fileExists = file_exists( $formFile );

		if ( $fileExists ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			$data  = file_get_contents( $formFile );
			$forms = json_decode( $data, true );

			$old_tqxonomies_id = $this->get_old_tax_info();
			$new_taxonomy_ids  = $this->taxonomy_old_new_map( $old_tqxonomies_id );

			if ( $forms && is_array( $forms ) ) {
				foreach ( $forms as &$formItem ) {
					$this->replace_category_ids( $formItem, $new_taxonomy_ids );

					// Save to DB
					Form::query()->insert( $formItem );
				}
			}
		}
	}

	public function replace_category_ids( &$array, $map ) {
		foreach ( $array as $key => &$value ) {
			if ( is_array( $value ) ) {
				$this->replace_category_ids( $value, $map );
			} else {
				// Only target numeric values under "value" inside "conditions"
				if ( $key === 'value' && is_numeric( $value ) && isset( $map[ $value ] ) ) {
					$value = $map[ $value ];
				}
			}
		}
	}

	private function import_rtcl_forms_old() {
		$formFile = trailingslashit( LISTZEN_CORE_BASE_DIR ) . 'sample-data/rtcl-form.json';

		$fileExists = file_exists( $formFile );

		if ( $fileExists ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			$data  = file_get_contents( $formFile );
			$forms = json_decode( $data, true );

			if ( $forms && is_array( $forms ) ) {
				foreach ( $forms as $formItem ) {
					Form::query()->insert( $formItem );
				}
			}
		}
	}


	/**
	 * Set Menu
	 *
	 * @param $demo
	 *
	 * @return void
	 */
	private function assign_menu( $demo ) {
		$primary_menu   = get_term_by( 'name', 'Primary Menu', 'nav_menu' );
		$quick_links    = get_term_by( 'name', 'Quick Links', 'nav_menu' );
		$top_highlights = get_term_by( 'name', 'Top Highlights', 'nav_menu' );

		// Ensure menus exist before assigning them
		$locations = [];
		if ( $primary_menu ) {
			$locations['primary'] = $primary_menu->term_id;
		}

		if ( ! empty( $locations ) ) {
			set_theme_mod( 'nav_menu_locations', $locations );
		}
	}

	/**
	 * Assign Homepage
	 *
	 * @param $selected_import
	 *
	 * @return void
	 */
	private function assign_frontpage( $selected_import ) {
		$blog_page  = $this->get_page_by_title( 'Blog' );
		$front_page = $this->get_page_by_title( $selected_import['import_page_name'] );

		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $front_page );
		update_option( 'page_for_posts', $blog_page );
	}

	private function update_contact_form_sender_email() {
		$form1 = $this->get_page_by_title( 'Contact', 'wpcf7_contact_form' );

		$forms = [ $form1 ];
		foreach ( $forms as $form ) {
			if ( ! $form ) {
				continue;
			}
			$cf7id = $form->ID;
			$mail  = get_post_meta( $cf7id, '_mail', true );
			if ( class_exists( 'WPCF7_ContactFormTemplate' ) ) {
				$pattern        = "/<[^@\s]*@[^@\s]*\.[^@\s]*>/"; // <email@email.com>
				$replacement    = '<' . WPCF7_ContactFormTemplate::from_email() . '>';
				$mail['sender'] = preg_replace( $pattern, $replacement, $mail['sender'] );
			}
			update_post_meta( $cf7id, '_mail', $mail );
		}
	}

	private function update_permalinks() {
		update_option( 'permalink_structure', '/%postname%/' );
	}

	private function remove_default_rtcl_pages() {
		$listings     = $this->get_page_by_title( 'Listings', 'page' );
		$listing_form = $this->get_page_by_title( 'Listing Form', 'page' );
		$myaccount    = $this->get_page_by_title( 'My Account' );
		$checkout     = $this->get_page_by_title( 'Checkout' );

		if ( $listings ) {
			wp_delete_post( $listings, true );
		}
		if ( $listing_form ) {
			wp_delete_post( $listing_form, true );
		}
		if ( $myaccount ) {
			wp_delete_post( $myaccount, true );
		}
		if ( $checkout ) {
			wp_delete_post( $checkout, true );
		}
	}


	private function remove_rtcl_builder_default_form() {
		global $wpdb;
		$table = $wpdb->prefix . 'rtcl_forms';
		$wpdb->query( "TRUNCATE TABLE $table" );
	}

	public function rewrite_flush_check() {
		if ( get_option( 'listzen_ocdi_importer_rewrite_flash' ) == true ) {
			flush_rewrite_rules();
			delete_option( 'listzen_ocdi_importer_rewrite_flash' );
		}
	}

	private function get_page_by_title( $title, $post_type = 'page' ) {
		$page = get_posts( [
			'post_type'   => $post_type,
			'name'        => sanitize_title( $title ),
			'post_status' => 'publish',
			'numberposts' => 1,
		] );

		if ( $page ) {
			$page = $page[0];

			return $page->ID;
		} else {
			return null;
		}
	}

	public function remove_default_widgets( $selected_import ) {
		delete_option( 'sidebars_widgets' );
	}

	/**
	 * Sets the active Elementor kit.
	 *
	 * @return $this
	 */
	private function remove_old_elementor_active_kit() {
		// Get the ID of the default kit
		global $wpdb;
		$default_kit_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT ID FROM $wpdb->posts WHERE post_type = 'elementor_library' AND post_name = %s",
				'default-kit'
			)
		);

		if ( $default_kit_id ) {
			$wpdb->delete( $wpdb->postmeta, [ 'post_id' => $default_kit_id ] );
			$wpdb->delete( $wpdb->posts, [ 'ID' => $default_kit_id ] );
            delete_option( 'elementor_active_kit' );
		}
    }
	private function set_elementor_active_kit() {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$pageIds = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT ID FROM $wpdb->posts WHERE (post_name = %s OR post_title = %s) AND post_type = 'elementor_library' AND post_status = 'publish'",
				'default-kit',
				'Default Kit'
			)
		);

		if ( ! is_null( $pageIds ) ) {
			$pageId    = 0;
			$deleteIds = [];

			// Retrieve page with greater id and delete others.
			if ( count( $pageIds ) > 1 ) {
				foreach ( $pageIds as $page ) {
					if ( $page->ID > $pageId ) {
						if ( $pageId ) {
							$deleteIds[] = $pageId;
						}
						$pageId = $page->ID;
					} else {
						$deleteIds[] = $page->ID;
					}
				}
			} else {
				$pageId = $pageIds[0]->ID;
			}

			// Update `elementor_active_kit` page.
			if ( $pageId > 0 ) {
				wp_update_post(
					[
						'ID'        => $pageId,
						'post_name' => sanitize_title( 'Default Kit' ),
					]
				);
				update_option( 'elementor_active_kit', $pageId );
			}
		}

		return $this;
	}

	private function url_replace() {
		global $wpdb;

		$base_url = trailingslashit( $this->demo_base_url );
		$new_url  = home_url( '/' );

		// Replace inside Elementor data
		$wpdb->query( $wpdb->prepare(
			"UPDATE {$wpdb->postmeta} 
         SET meta_value = REPLACE(meta_value, %s, %s) 
         WHERE meta_key = '_elementor_data'",
			$base_url, $new_url
		) );

		// Replace inside Elementor global settings (site title, button links, etc.)
		$wpdb->query( $wpdb->prepare(
			"UPDATE {$wpdb->options} 
         SET option_value = REPLACE(option_value, %s, %s) 
         WHERE option_name LIKE 'elementor%%'",
			$base_url, $new_url
		) );
	}

	/**
	 * Sets the Elementor default settings.
	 *
	 * @return $this
	 */
	private function set_elementor_settings() {
//		update_option( 'elementor_disable_color_schemes', 'yes' );
//		update_option( 'elementor_disable_typography_schemes', 'yes' );
		update_option( 'elementor_unfiltered_files_upload', '1' );

//		update_option( 'elementor_experiment-e_font_icon_svg', 'inactive' );

		return $this;
	}

	public function footer_style() {
		if ( isset( $_GET['page'] ) && $_GET['page'] === 'one-click-demo-import' ) {
			?>
            <style>
                :root {
                    --listzen-primary-color: #FA350C;
                    --listzen-primary-light: #FF4E2A;
                    --listzen-primary-dark: #D42400;
                    --listzen-primary-soft: #FFEEEA;
                    --listzen-primary-border: #cdbbb6;
                }

                .ocdi__content-container .ocdi__theme-about {
                    display: none;
                }

                .ocdi__content-container .notice:not(#setting-error-tgmpa, .notice-error),
                .ocdi__content-container .ocdi__intro-text p {
                    display: none !important;
                }

                .ocdi__content-container .ocdi__gl-item-container {
                    width: 1122px;
                    margin: auto;
                    max-width: 100%;
                }

                .ocdi__content-container .ocdi__gl-item-buttons {
                    position: absolute;
                    top: 8px;
                    right: 7px;
                    display: block;
                    transform: translateX(-15px);
                    transition: 0.4s;
                    opacity: 0;
                }

                .ocdi__gl-item:hover .ocdi__gl-item-buttons {
                    transform: translateX(0);
                    opacity: 1;
                }

                .ocdi__content-container .ocdi__gl-item-footer {
                    position: relative;
                }

                .ocdi__content-container .ocdi__gl-item-button {
                    color: var(--listzen-primary-color);
                    background: var(--listzen-primary-soft);
                    border-color: var(--listzen-primary-border);
                    padding: 0 12px;
                }

                .ocdi__content-container .ocdi__gl-item-button + .ocdi__gl-item-button {
                    margin-left: 5px;
                    color: #FFFFFF;
                    background: var(--listzen-primary-light) !important;
                    border: none;
                }

                .ocdi__content-container .ocdi__gl-item-button:hover {
                    color: #FFFFFF !important;
                    background: var(--listzen-primary-color) !important;
                    border-color: var(--listzen-primary-color) !important;
                    transition: 0.4s;
                }

                .ocdi__content-container .ocdi__gl-item-title {
                    display: block !important;
                    text-align: left;
                }

                .ocdi hr {
                    margin: 15px 0 !important;
                }
            </style>
			<?php
		}
	}

}