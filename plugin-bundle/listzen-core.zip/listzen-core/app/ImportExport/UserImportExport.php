<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\ImportExport;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ListzenCore\Traits\SingletonTraits;

/**
 * UserImportExport class
 */
class UserImportExport {
	use SingletonTraits;

	public $user_migration = [];

	/**
	 * Class constructor
	 */
	public function __construct() {
		$this->import_users();
		$this->import_usermeta();
		$this->update_listing_author();
		/*$this->update_userid_from_comments();*/
	}


	/**
	 * Listzen users import to client server
	 *
	 * @return void
	 */
	public function import_users() {
		global $wpdb;

		$existing_users     = []; //Current users - Client live server
		$existing_users_obj = get_users( [ 'number' => - 1, 'fields' => [ 'ID', 'user_login' ] ] );
		foreach ( $existing_users_obj as $existing_user ) {
			$existing_users[ $existing_user->user_login ] = $existing_user->ID;
		}

		$listzen_users = file_get_contents( LISTZEN_CORE_BASE_DIR . 'sample-data/users.json' ); //Imported Users - Listzen live server
		$listzen_users = json_decode( $listzen_users, true );

		$_user_migration = []; //Store old and new ids [old_id => new_id]
		foreach ( $listzen_users as $user_value ) {
			if ( array_key_exists( $user_value['user_login'], $existing_users ) ) {
				continue;
				// If matched, no need to delete current users. If everything works fine this comment can be removed.
				// require_once( ABSPATH . 'wp-admin/includes/user.php' );
				// wp_delete_user( $existing_users[ $user_value['user_login'] ] );
			}

			$old_id = $user_value['ID'];
			unset( $user_value['ID'] );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			if ( $wpdb->insert( $wpdb->users, $user_value ) ) {
				$_user_migration[ $old_id ] = $wpdb->insert_id;
			}
		}

		update_option( 'listzen_users', $_user_migration );
	}

	/**
	 * Import user meta data.
	 *
	 * @return void
	 */
	public function import_usermeta() {
		global $wpdb;

		//Listzen users meta
		$user_meta_data = file_get_contents( LISTZEN_CORE_BASE_DIR . 'sample-data/usermeta.json' );
		$user_meta_data = json_decode( $user_meta_data, true );

		$_listzen_users = get_option( 'listzen_users' ); //[old_id => new_id]
		foreach ( $user_meta_data as $user_meta_value ) {
			if ( ! array_key_exists( $user_meta_value['user_id'], $_listzen_users ) ) {
				continue;
			}

			$user_meta_value['user_id']    = $_listzen_users[ $user_meta_value['user_id'] ]; //update old id with new inserted user id
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			$user_meta_value['meta_value'] = maybe_unserialize( $user_meta_value['meta_value'] );

			// update user meta
			update_user_meta( $user_meta_value['user_id'], $user_meta_value['meta_key'], $user_meta_value['meta_value'] );
		}
	}

	/**
	 *
	 * @return void
	 */
	public function update_listing_author() {
		$_listzen_users = get_option( 'listzen_users' ); //[old_id => new_id]

		/**
		 * To generate the below json just enter this querystring in the frontend - ?listzen_listiing_info=yes
		 * It will make a json file in sample-data folder.
		 * [listing_id => [author=>4, manager=>4]] This is the format
		 */

		$listing_info_json = file_get_contents( LISTZEN_CORE_BASE_DIR . 'sample-data/listing-info.json' );
		$listing_data      = json_decode( $listing_info_json, true );

		foreach ( $listing_data as $listing_id => $info ) {
			if ( ! array_key_exists( $info['author'], $_listzen_users ) ) {
				continue;
			}
			@wp_update_post( [ 'ID' => $listing_id, 'post_author' => $info['author'] ] );
			update_post_meta( $listing_id, '_rtcl_manager_id', $info['manager'] );
		}

		/**
		 * Update Store Meta : store_id => user_id
		 */
		$listzen_store_ids = [
			172 => 4, //LocaList
			168 => 2, //FindStry
			157 => 3, //BizNest
		];

		foreach ( $listzen_store_ids as $store_id => $user_id ) {
			if ( ! array_key_exists( $user_id, $_listzen_users ) ) {
				continue;
			}
			//Update store owner and manage id
			update_post_meta( $store_id, '_rtcl_manager_ids', $_listzen_users[ $user_id ] );
			update_post_meta( $store_id, 'store_owner_id', $_listzen_users[ $user_id ] );
		}
	}


	/**
	 * Comment userid updated
	 *
	 * @return void
	 */
	public function update_userid_from_comments() {
		$existing_userid  = [
			5 => 6,
			6 => 4,
		];

		$_listzen_users = get_option( 'listzen_users' ); //[old_id => new_id]

		foreach ( $existing_userid as $key => $value ) {
			if ( ! array_key_exists( $value, $_listzen_users ) ) {
				continue;
			}
			wp_update_comment( [ 'comment_ID' => $key, 'user_id' => $_listzen_users[ $value ] ] );
		}
	}


}