<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\ImportExport;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ListzenCore\Traits\SingletonTraits;

//phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.MissingUnslash
class Exporter {
	use SingletonTraits;

	public $exportDir;

	public function __construct() {
		$this->exportDir = trailingslashit( LISTZEN_CORE_BASE_DIR ) . 'sample-data/';

		add_action( 'template_redirect', [ $this, 'template_redirect_cbf' ] );
	}

	public function template_redirect_cbf() {

		if ( isset( $_GET['ajax_filter_export'] ) && 'yes' == $_GET['ajax_filter_export'] ) {
			$this->ajax_filter_export();
		}

		if ( isset( $_GET['listzen_user'] ) && 'yes' === $_GET['listzen_user'] ) {
			$this->export_users();
		}

		if ( isset( $_GET['listzen_listiing_info'] ) && 'yes' === $_GET['listzen_listiing_info'] ) {
			$this->export_listing_information();
		}

		if ( isset( $_GET['listzen_export'] ) && 'yes' === $_GET['listzen_export'] ) {
			$this->ajax_filter_export();
			$this->export_users();
			$this->export_widgets();
			$this->export_customizer();
		}

		$this->get_taxonomy_slug_id_array();
	}


	/**
	 * Get taxonomy terms as [slug => id] array.
	 *
	 * @param string $taxonomy Taxonomy name.
	 *
	 * @return array
	 */
	function get_taxonomy_slug_id_array() {
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$taxonomy = ! empty( $_GET['taxonomy'] ) ? $_GET['taxonomy'] : null; //'rtcl_location'
		if ( ! $taxonomy ) {
			return;
		}
		$terms = get_terms( [
			'taxonomy'   => $taxonomy,
			'hide_empty' => false, // set true if you only want non-empty terms
		] );

		$result = [];

		if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
			foreach ( $terms as $term ) {
				$result[ $term->slug ] = $term->term_id;
			}
		}

		$file = $this->exportDir . 'taxonomy-info.json';

		file_put_contents( $file, wp_json_encode( $result ) );
	}

	public function export_listing_information() {
		$listing_infor = [];

		$args = [
			'post_type'      => 'rtcl_listing',
			'posts_per_page' => - 1, // Get all listings
			'post_status'    => 'publish', // Only published posts
		];

		$listings = get_posts( $args );

		if ( $listings ) {
			foreach ( $listings as $listing ) {
				$listing_infor[ $listing->ID ] = [
					'author'  => $listing->post_author,
					'manager' => get_post_meta( $listing->ID, '_rtcl_manager_id', true ),
				];
			}
		}

		$file = $this->exportDir . 'listing-info.json';

		// OCDI expects serialized .dat
		file_put_contents( $file, wp_json_encode( $listing_infor ) );
	}

	public function ajax_filter_export() {
		$ajax_filter = get_option( 'rtcl_filter_settings' );
		$file        = $this->exportDir . 'rtcl-ajax-filter.json';
		file_put_contents( $file, json_encode( $ajax_filter ) );
	}

	public function export_customizer() {

		$theme_slug = get_option( 'stylesheet' );

		$export_data = [
			'template' => $theme_slug,
			'mods'     => get_theme_mods(),
			'options'  => [
				'site_icon'               => get_option( 'site_icon' ),
				'nav_menus_created_posts' => get_option( 'nav_menus_created_posts', [] ),
			],
			'wp_css'   => '',
		];

		$file = $this->exportDir . 'customizer.text';

		// OCDI expects serialized .dat
		file_put_contents( $file, serialize( $export_data ) );

	}

	public function export_widgets() {
		global $wp_registered_sidebars, $wp_registered_widgets;

		$sidebars_widgets = get_option( 'sidebars_widgets' );
		$all_instances    = [];

		// Collect all widget instances from options table
		foreach ( $wp_registered_widgets as $widget_id => $widget ) {
			$option_name = preg_replace( '/-\d+$/', '', $widget_id );
			if ( ! isset( $all_instances[ $option_name ] ) ) {
				$all_instances[ $option_name ] = get_option( 'widget_' . $option_name );
			}
		}

		$export_data = [];

		// Build export structure for each sidebar
		foreach ( $sidebars_widgets as $sidebar_id => $widget_ids ) {
			if ( 'wp_inactive_widgets' === $sidebar_id || empty( $widget_ids ) || ! is_array( $widget_ids ) ) {
				continue;
			}

			foreach ( $widget_ids as $widget_id ) {
				// widget id like text-3, categories-2, block-16 etc
				$option_name = preg_replace( '/-\d+$/', '', $widget_id );
				$index       = str_replace( $option_name . '-', '', $widget_id );

				if ( isset( $all_instances[ $option_name ][ $index ] ) ) {
					$export_data[ $sidebar_id ][ $widget_id ] = $all_instances[ $option_name ][ $index ];
				}
			}
		}

		// Save as widgets.wie

		$file = $this->exportDir . 'widgets.json';


		file_put_contents( $file, wp_json_encode( $export_data ) );

	}


	public static function export_users() {
		global $wpdb;

		// Exclude these users
		$users_id_exclude = [ 1 ];

		// Convert array to SQL-safe list
		$exclude_sql = implode( ',', array_map( 'intval', $users_id_exclude ) );

		// user table (exclude IDs)
		$query = "SELECT * FROM $wpdb->users";
		if ( ! empty( $exclude_sql ) ) {
			$query .= " WHERE ID NOT IN ($exclude_sql)";
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$users = $wpdb->get_results( $query, ARRAY_A );

		// Get all user IDs from result (so we only fetch their metadata)
		$user_ids     = wp_list_pluck( $users, 'ID' );
		$user_ids_sql = implode( ',', array_map( 'intval', $user_ids ) );

		// usermeta table (exclude IDs automatically because we use only fetched IDs)
		$usermetas = [];
		if ( ! empty( $user_ids_sql ) ) {
			$query     = "SELECT * FROM $wpdb->usermeta WHERE user_id IN ($user_ids_sql)";
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$usermetas = $wpdb->get_results( $query, ARRAY_A );
		}

		// JSON encode
		$json1 = wp_json_encode( $users );
		$json2 = wp_json_encode( $usermetas );

		// Paths
		$dir1 = trailingslashit( LISTZEN_CORE_BASE_DIR ) . 'sample-data/users.json';
		$dir2 = trailingslashit( LISTZEN_CORE_BASE_DIR ) . 'sample-data/usermeta.json';

		// Save files (overwrite)
		file_put_contents( $dir1, $json1 );
		file_put_contents( $dir2, $json2 );
	}

}