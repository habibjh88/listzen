<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Generator;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
use ListzenCore\Traits\SingletonTraits;
class WidgetFieldsGenerator {
	use SingletonTraits;
	public static function display( $fields, $instance, $object ) {
		foreach ( $fields as $key => $field ) {
			$label   = $field['label'];
			$desc    = ! empty( $field['desc'] ) ? $field['desc'] : false;
			$id      = $object->get_field_id( $key );
			$name    = $object->get_field_name( $key );
			$value   = $instance[ $key ] ?? '';
			$options = ! empty( $field['options'] ) ? $field['options'] : false;

			if ( method_exists( __CLASS__, $field['type'] ) ) {
				echo '<div class="listzen-widget-field">';
				if ( version_compare( phpversion(), '5.3.0', '<' ) ) {
					call_user_func( __CLASS__ . '::' . $field['type'], $id, $name, $value, $label, $options, $field );
				} else {
					call_user_func( [ __CLASS__, $field['type'] ], $id, $name, $value, $label, $options, $field );
				}
				if ( $desc ) {
					$desc = '<div class="desc">' . $desc . '</div>';
					listzen_html( $desc );
				}
				echo '</div>';
			}
		}
	}

	public static function heading( $id, $name, $value, $label, $options, $field ) {
		?>
		<h3 style="border-bottom: 1px solid #ddd;" for="<?php echo esc_attr( $id ); ?>"><strong><?php echo esc_html( $label ); ?>:</strong></h3>
		<?php
	}

	public static function text( $id, $name, $value, $label, $options, $field ) {
		?>
		<label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?>:</label>
		<input class="widefat" type="text" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>"/>
		<?php
	}

	public static function url( $id, $name, $value, $label, $options, $field ) {
		?>
		<label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?>:</label>
		<input class="widefat" type="text" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_url( $value ); ?>"/>
		<?php
	}

	public static function number( $id, $name, $value, $label, $options, $field ) {
		$min  = isset( $field['min'] ) ? $field['min'] : '';
		$max  = isset( $field['max'] ) ? $field['max'] : '';
		$step = isset( $field['step'] ) ? $field['step'] : 1;
		?>
		<label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?>:</label>
		<input class="widefat" type="number" min="<?php echo esc_attr( $min ); ?>" max="<?php echo esc_attr( $max ); ?>" step="<?php echo esc_attr( $step ); ?>" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>"/>
		<?php
	}

	public static function textarea( $id, $name, $value, $label, $options, $field ) {
		?>
		<label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?>:</label>
		<textarea class="widefat" rows="3" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>"><?php echo esc_textarea( $value ); ?></textarea>
		<?php
	}

	public static function checkbox( $id, $name, $value, $label, $options, $field ) {
		?>
		<label for="<?php echo esc_attr( $id ); ?>"><input class="widefat" type="checkbox" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" <?php echo $value ? ' checked="checked"' : ''; ?> /> <?php echo esc_html( $label ); ?></label>
		<?php
	}

	public static function select( $id, $name, $value, $label, $options, $field ) {
		?>
		<label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?>:</label>
		<select name="<?php echo esc_attr( $name ); ?>" id="<?php echo esc_attr( $id ); ?>">
			<?php foreach ( $options as $key => $option ) : ?>
				<option value="<?php echo esc_attr( $key ); ?>"<?php selected( $key, $value ); ?>><?php echo esc_html( $option ); ?></option>
			<?php endforeach; ?>
		</select>
		<?php
	}

	// Using components
	public static function image( $id, $name, $value, $label, $options, $field ) {
		$image    = '';
		$disstyle = '';

		if ( $value ) {
			$image = wp_get_attachment_image_src( $value, 'thumbnail' );
			$image = $image[0];
		} else {
			$disstyle = 'display:none;';
		}

		echo '
			<label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . ':</label>
			<div class="listzen_metabox_image">
			<input name="' . esc_attr( $name ) . '" type="hidden" class="custom_upload_image" value="' . esc_attr( $value ) . '" />
			<img src="' . esc_url( $image ) . '" class="custom_preview_image" style="' . esc_attr( $disstyle ) . '" alt="" />
			<input class="listzen_upload_image upload_button_' . esc_attr( $id ) . ' button-primary" type="button" value="' . esc_attr__( 'Choose Image', 'listzen-core' ) . '" />
			<div class="listzen_remove_image_wrap" style="' . esc_attr( $disstyle ) . '"><a href="#" class="listzen_remove_image button" >' . esc_html__( 'Remove Image', 'listzen-core' ) . '</a></div>
			</div>
			';
	}

	public static function multi_select( $id, $name, $value, $label, $options, $field ) {
		?>
		<label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?>:</label>
		<?php
		if ( empty( $value ) ) {
			$value = [];
		}
		echo '<select class="listzen-multi-select" data-placeholder=" ' . esc_attr__( 'Click here to select options', 'listzen-core' ) . '" multiple="multiple"' .
		     ' name="' . esc_attr( $name ) . '[]"' .
		     ' id="' . esc_attr( $id ) . '">';
		foreach ( $options as $key => $option ) {
			echo '<option',
			in_array( $key, $value ) ? ' selected="selected"' : '',
				' value="' . esc_attr( $key ) . '"' .
				'>' .
				esc_html( $option ) .
				'</option>';
		}
		echo '</select>';
	}
}
