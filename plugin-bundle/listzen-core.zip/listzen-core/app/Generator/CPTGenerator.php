<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Generator;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use ListzenCore\Traits\SingletonTraits;
//phpcs:disable

class CPTGenerator {
	use SingletonTraits;

	protected static $instance = null;
	private static $post_types = [];
	private static $taxonomies = [];

	/**
	 * Class Constructor
	 */
	private function __construct() {
		add_action( 'init', [ $this, 'register_taxonomies' ], 9999 );
		add_action( 'init', [ $this, 'register_custom_post_types' ], 9999 );
	}


	/**
	 * Add post types
	 *
	 * @param $post_types
	 *
	 * @return void
	 */
	public static function add_post_types( $post_types ) {

		foreach ( $post_types as $post_type ) {
			$labels = [
				'name'               => sprintf( _x( '%s', 'post type general name', 'listzen-core' ), $post_type['plural'] ),
				'singular_name'      => sprintf( _x( '%s', 'post type singular name', 'listzen-core' ), $post_type['singular'] ),
				'menu_name'          => sprintf( _x( '%s', 'admin menu', 'listzen-core' ), $post_type['plural'] ),
				'name_admin_bar'     => sprintf( _x( '%s', 'add new on admin bar', 'listzen-core' ), $post_type['singular'] ),
				'add_new'            => sprintf( __( 'Add New %s', 'listzen-core' ), $post_type['singular'] ),
				'add_new_item'       => sprintf( __( 'Add New %s', 'listzen-core' ), $post_type['singular'] ),
				'new_item'           => sprintf( __( 'New %s', 'listzen-core' ), $post_type['singular'] ),
				'edit_item'          => sprintf( __( 'Edit %s', 'listzen-core' ), $post_type['singular'] ),
				'view_item'          => sprintf( __( 'View %s', 'listzen-core' ), $post_type['singular'] ),
				'view_items'         => sprintf( __( 'View %s', 'listzen-core' ), $post_type['plural'] ),
				'all_items'          => sprintf( __( 'All %s', 'listzen-core' ), $post_type['plural'] ),
				'search_items'       => sprintf( __( 'Search %s', 'listzen-core' ), $post_type['plural'] ),
				'parent_item_colon'  => sprintf( __( 'Parent %s', 'listzen-core' ), $post_type['plural'] ),
				'not_found'          => sprintf( __( 'No %s found.', 'listzen-core' ), $post_type['plural'] ),
				'not_found_in_trash' => sprintf( __( 'No %s found in Trash.', 'listzen-core' ), $post_type['plural'] ),
			];
			$args   = [
				'labels'             => $labels,
				'description'        => __( $post_type['description'], 'listzen-core' ),
				'public'             => $post_type['public'] ?? true,
				'publicly_queryable' => $post_type['publicly_queryable'] ?? true,
				'show_ui'            => $post_type['show_ui'] ?? true,
				'show_in_menu'       => $post_type['show_in_menu'] ?? true,
				'menu_icon'          => $post_type['menu_icon'],
				'query_var'          => $post_type['query_var'] ?? true,
				'rewrite'            => [ 'slug' => $post_type['slug'] ],
				'capability_type'    => $post_type['capability_type'] ?? 'post',
				'has_archive'        => $post_type['has_archive'] ?? true,
				'hierarchical'       => $post_type['hierarchical'] ?? false,
				'menu_position'      => $post_type['menu_position'],
				'supports'           => $post_type['supports'],
				'show_in_rest'       => $post_type['show_in_rest'] ?? true,
			];

			if ( ! empty( $post_type['taxonomies'] ) ) {
				$args['taxonomies'] = $post_type['taxonomies'];
			}

			self::$post_types[ $post_type['id'] ] = $args;
		}
	}

	/**
	 * Add Taxonomies list
	 *
	 * @param $taxonomies
	 *
	 * @return void
	 */
	public static function add_taxonomies( $taxonomies ) {

		foreach ( $taxonomies as $taxonomy ) {

			$labels                              = [
				'name'              => _x( $taxonomy['plural'], 'taxonomy general name', 'listzen-core' ),
				'singular_name'     => _x( $taxonomy['singular'], 'taxonomy singular name', 'listzen-core' ),
				'menu_name'         => _x( $taxonomy['plural'], 'admin menu', 'listzen-core' ),
				'add_new_item'      => _x( 'Add New ' . $taxonomy['singular'], 'listzen-core' ),
				'search_items'      => __( 'Search ' . $taxonomy['plural'], 'listzen-core' ),
				'all_items'         => __( 'All ' . $taxonomy['plural'], 'listzen-core' ),
				'parent_item'       => __( 'Parent ' . $taxonomy['singular'], 'listzen-core' ),
				'parent_item_colon' => __( 'Parent ' . $taxonomy['singular'], 'listzen-core' ),
				'edit_item'         => __( 'Edit ' . $taxonomy['singular'], 'listzen-core' ),
				'update_item'       => __( 'Update ' . $taxonomy['singular'], 'listzen-core' ),
				'new_item_name'     => __( 'New ' . $taxonomy['singular'], 'listzen-core' ),
			];
			$args                                = [
				'labels'             => $labels,
				'description'        => __( '', 'listzen-core' ),
				'hierarchical'       => $taxonomy['hierarchical'] ?? true,
				'public'             => $taxonomy['public'] ?? true,
				'publicly_queryable' => $taxonomy['publicly_queryable'] ?? true,
				'show_ui'            => $taxonomy['show_ui'] ?? true,
				'show_in_menu'       => $taxonomy['show_in_menu'] ?? true,
				'show_in_nav_menus'  => $taxonomy['show_in_nav_menus'] ?? true,
				'show_tagcloud'      => $taxonomy['show_tagcloud'] ?? true,
				'show_in_quick_edit' => $taxonomy['show_in_quick_edit'] ?? true,
				'show_admin_column'  => $taxonomy['show_admin_column'] ?? false,
				'show_in_rest'       => $taxonomy['show_in_rest'] ?? true,
				'post_type'          => $taxonomy['post_type'],
			];
			self::$taxonomies[ $taxonomy['id'] ] = $args;
		}
	}

	/**
	 * Register custom post type
	 *
	 * @return void
	 */
	public function register_custom_post_types() {
		$post_types = apply_filters( 'listzen_framework_post_types', self::$post_types );
		foreach ( $post_types as $post_type => $args ) {
			register_post_type( $post_type, $args );
		}
	}

	/**
	 * Register Taqxonomies
	 *
	 * @return void
	 */
	public function register_taxonomies() {
		$taxonomies = apply_filters( 'listzen_framework_taxonomies', self::$taxonomies );
		foreach ( $taxonomies as $taxonomy => $args ) {
			$post_type = $args['post_type'];
			unset( $args['post_type'] );
			register_taxonomy( $taxonomy, $post_type, $args );
		}
	}
}