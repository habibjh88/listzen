<?php

namespace ListzenCore\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use Listzen\Modules\PostMeta;
class Fns {

	public static function doing_it_wrong( $function, $message, $version ) {
		// @codingStandardsIgnoreStart
		$message .= ' Backtrace: ' . wp_debug_backtrace_summary();
		_doing_it_wrong( $function, $message, $version );
	}

	/**
	 * Class list
	 *
	 * @param $clsses
	 *
	 * @return string
	 */
	public static function class_list( $clsses ) {
		return trim( implode( ' ', $clsses ) );
	}

	/**
	 * @param        $template_name
	 * @param string $template_path
	 * @param string $default_path
	 *
	 * @return mixed|void
	 */
	public static function locate_template( $template_name, $template_path = '', $default_path = '' ) {
		$template_name = $template_name . ".php";
		if ( ! $template_path ) {
			$template_path = 'listzen-core/';
		}

		if ( ! $default_path ) {
			$default_path = untrailingslashit( LISTZEN_CORE_BASE_DIR ) . '/templates/';
		}

		$template_files = trailingslashit( $template_path ) . $template_name;

		$template = locate_template( apply_filters( 'listzen_locate_template_files', $template_files, $template_name, $template_path, $default_path ) );

		// Get default template/.
		if ( ! $template ) {
			$template = trailingslashit( $default_path ) . $template_name;
		}

		return apply_filters( 'listzen_locate_template', $template, $template_name );
	}

	/**
	 * Template Content
	 *
	 * @param string $template_name Template name.
	 * @param array $args Arguments. (default: array).
	 * @param string $template_path Template path. (default: '').
	 * @param string $default_path Default path. (default: '').
	 */
	public static function get_template( $template_name, $args = null, $template_path = '', $default_path = '' ) {

		if ( ! empty( $args ) && is_array( $args ) ) {
			extract( $args ); // @codingStandardsIgnoreLine
		}
		$located = self::locate_template( $template_name, $template_path, $default_path );

		if ( ! file_exists( $located ) ) {
			// translators: %s template
			self::doing_it_wrong( __FUNCTION__, sprintf( __( '%s does not exist.', 'listzen-core' ), '<code>' . $located . '</code>' ), '1.0' );

			return;
		}

		// Allow 3rd party plugin filter template file from their plugin.
		$located = apply_filters( 'listzen_get_template', $located, $template_name, $args );

		do_action( 'listzen_before_template_part', $template_name, $located, $args );

		include $located;

		do_action( 'listzen_after_template_part', $template_name, $located, $args );
	}

	/**
	 * Get Asset URL
	 * @return string
	 */
	public static function get_assets_url( $path = null ) {
		return LISTZEN_CORE_BASE_URL . 'assets/' . $path;
	}

	/**
	 * Get all Post Type
	 * @return array
	 */
	public static function get_post_types( $exc = '' ) {
		$post_types = get_post_types(
			[
				'public' => true,
			],
			'objects'
		);
		$post_types = wp_list_pluck( $post_types, 'label', 'name' );

		$exclude = [
			'attachment',
			'revision',
			'nav_menu_item',
			'elementor_library',
			'listzen_builder',
			'e-landing-page',
			'elementor-listzen'
		];
		if ( $exc ) {
			$exclude = array_merge( $exclude, $exc );
		}

		foreach ( $exclude as $ex ) {
			unset( $post_types[ $ex ] );
		}

		return $post_types;
	}


	/**
	 * Grid Columns
	 *
	 * @return mixed|null
	 */
	public static function column_list() {
		$columns = [
			''   => __( '-Select-', 'listzen-core' ),
			'2'  => __( '6 Columns', 'listzen-core' ),
			'3'  => __( '4 Columns', 'listzen-core' ),
			'4'  => __( '3 Columns', 'listzen-core' ),
			'6'  => __( '2 Columns', 'listzen-core' ),
			'12' => __( '1 Columns', 'listzen-core' ),
		];

		return apply_filters( 'listzen_gird_columns', $columns );
	}


	/**
	 * Get All Image Sizes
	 *
	 * @return array
	 */
	public static function image_size_lists() {
		global $_wp_additional_image_sizes;
		$image_sizes = [
			''          => __( '--Select--', 'listzen-core' ),
			'full'      => __( 'Full', 'listzen-core' ),
			'large'     => __( 'Large', 'listzen-core' ),
			'medium'    => __( 'Medium', 'listzen-core' ),
			'thumbnail' => __( 'Thumbnail', 'listzen-core' ),
		];
		if ( ! empty( $_wp_additional_image_sizes ) ) {
			foreach ( $_wp_additional_image_sizes as $index => $item ) {
				$image_sizes[ $index ] = __( ucwords( $index . ' - ' . $item['width'] . 'x' . $item['height'] ), 'listzen-core' );
			}
		}

		return $image_sizes;
	}

	/**
	 * Contact markup render
	 *
	 * @param $instance
	 *
	 * @return false|string
	 */
	public static function contact_render( $instance ) {
		ob_start();
		?>
        <div class="listzen-contact-widget-wrapper">
            <ul>
				<?php if ( ! empty( $instance['address'] ) ) : ?>
                    <li>
                        <p><?php echo esc_html( $instance['address'] ); ?></p>
                    </li>
				<?php endif; ?>

				<?php if ( ! empty( $instance['phone'] ) ) : ?>
                    <li class="phone-no"><p><a target="_blank"
                                               href="tel:<?php echo esc_attr( $instance['phone'] ); ?>"><?php echo esc_html( $instance['phone'] ); ?></a>
                        </p>
                    </li>
				<?php endif; ?>

				<?php if ( ! empty( $instance['mail'] ) ) : ?>
                    <li><p><a target="_blank"
                              href="mailto:<?php echo esc_html( $instance['mail'] ); ?>"><?php echo esc_html( $instance['mail'] ); ?></a>
                        </p>
                    </li>
				<?php endif; ?>

				<?php if ( ! empty( $instance['website'] ) ) : ?>
                    <li><p><a target="_blank"
                              href="<?php echo esc_url( $instance['website'] ); ?>"><?php echo esc_html( $instance['website'] ); ?></a>
                        </p>
                    </li>
				<?php endif; ?>
            </ul>
        </div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Get Post view count meta key
	 *
	 * @return string
	 */
	public static function get_post_view_count_meta_key() {
		$count_key = '';

		if ( function_exists( 'listzen_utils' ) ) {
			$count_key = listzen_utils( 'post_view_key' );
		}

		return apply_filters( 'listzen_post_view_count', $count_key );
	}

	public static function get_terms_id( $id, $type ) {
		$data = [];
		$arr  = get_the_terms( $id, $type );
		if ( is_array( $arr ) ) {
			foreach ( $arr as $key => $val ) {
				$data[] = $val->term_id;
			}
		}

		return $data;
	}

	/**
	 * Get Instant Query Argument
	 *
	 * @param $instant_query
	 * @param $args
	 *
	 * @return mixed
	 */
	public static function get_quick_query( $instant_query, $args ) {
		if ( 'default' === $instant_query ) {
			return $args;
		}
		//phpcs:disable WordPress.Security.NonceVerification.Missing

		switch ( $instant_query ) {
			case 'random_post_7_days':
			case 'random_post_30_days':
				$args['orderby']    = 'rand';
				$args['order']      = 'ASC';
				$args['date_query'] = [ [ 'after' => $instant_query === 'random_post_7_days' ? '1 week ago' : '1 month ago' ] ];
				break;
			case 'most_comment_1_day':
			case 'most_comment_7_days':
			case 'most_comment_30_days':
				$args['orderby']    = 'comment_count';
				$args['order']      = 'DESC';
				$args['date_query'] = [ [ 'after' => $instant_query === 'most_comment_1_day' ? '1 day ago' : ( $instant_query === 'most_comment_7_days' ? '1 week ago' : '1 month ago' ) ] ];
				break;
			case 'popular_post_1_day_view':
			case 'popular_post_7_days_view':
			case 'popular_post_30_days_view':
			case 'popular_post_all_times_view':
				$args['meta_key'] = self::get_post_view_count_meta_key(); //phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				$args['orderby']  = 'meta_value_num';
				$args['order']    = 'DESC';
				if ( $instant_query !== 'popular_post_all_times_view' ) {
					$args['date_query'] = [ [ 'after' => ( $instant_query === 'popular_post_1_day_view' ? '1 day ago' : ( $instant_query === 'popular_post_7_days_view' ? '1 week ago' : '1 month ago' ) ) ] ];
				}
				break;
			case 'related_category':
				global $post;
				$p_id = isset( $post->ID ) && $post->ID ? $post->ID : ( isset( $prams['current_post'] ) && $prams['current_post'] ? $prams['current_post'] : ( isset( $_POST['postId'] ) ? sanitize_text_field( $_POST['postId'] ) : '' ) );
				if ( $p_id ) {
					//phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
					$args['tax_query']    = [
						[
							'taxonomy' => 'category',
							'terms'    => self::get_terms_id( $p_id, 'category' ),
							'field'    => 'term_id',
						],
					];
					$args['post__not_in'] = [ $p_id ]; //phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_post__not_in
				}
				break;
			case 'related_tag':
				global $post;
				$p_id = isset( $post->ID ) && $post->ID ? $post->ID : ( isset( $prams['current_post'] ) && $prams['current_post'] ? $prams['current_post'] : ( isset( $_POST['postId'] ) ? sanitize_text_field( $_POST['postId'] ) : '' ) );
				if ( $p_id ) {
					//phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
					$args['tax_query']    = [
						[
							'taxonomy' => 'post_tag',
							'terms'    => self::get_terms_id( $p_id, 'post_tag' ),
							'field'    => 'term_id',
						],
					];
					$args['post__not_in'] = [ $p_id ]; //phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_post__not_in
				}
				break;
			case 'related_cat_tag':
				global $post;
				$p_id = isset( $post->ID ) && $post->ID ? $post->ID : ( isset( $prams['current_post'] ) && $prams['current_post'] ? $prams['current_post'] : ( isset( $_POST['postId'] ) ? sanitize_text_field( $_POST['postId'] ) : '' ) );
				if ( $p_id ) {
					//phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
					$args['tax_query']    = [
						[
							'taxonomy' => 'post_tag',
							'terms'    => self::get_terms_id( $p_id, 'post_tag' ),
							'field'    => 'term_id',
						],
						[
							'taxonomy' => 'category',
							'terms'    => self::get_terms_id( $p_id, 'category' ),
							'field'    => 'term_id',
						],
					];
					$args['post__not_in'] = [ $p_id ]; //phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_post__not_in
				}
				break;
			default:
				break;
		}

		return $args;
	}

	/**
	 * Grid Columns
	 *
	 * @return mixed|null
	 */
	public static function slider_list() {
		$columns = [
			''   => __( '--Select--', 'listzen-core' ),
			'1'  => __( '1 Columns', 'listzen-core' ),
			'2'  => __( '2 Columns', 'listzen-core' ),
			'3'  => __( '3 Columns', 'listzen-core' ),
			'4'  => __( '4 Columns', 'listzen-core' ),
			'5'  => __( '5 Columns', 'listzen-core' ),
			'6'  => __( '6 Columns', 'listzen-core' ),
			'7'  => __( '7 Columns', 'listzen-core' ),
			'8'  => __( '8 Columns', 'listzen-core' ),
			'9'  => __( '9 Columns', 'listzen-core' ),
			'10' => __( '10 Columns', 'listzen-core' ),
		];

		return apply_filters( 'listzen_core_slider_columns', $columns );
	}

	public static function swiper_args( $data ) {

		$default = [ '3', '2', '1' ];

		$slider_column_lg = absint( ! empty( $data['slider_column'] ) ? $data['slider_column'] : $default[0] );
		$slider_column_md = absint( ! empty( $data['slider_column_tablet'] ) ? $data['slider_column_tablet'] : $default[1] );
		$slider_column_sm = absint( ! empty( $data['slider_column_mobile'] ) ? $data['slider_column_mobile'] : $default[2] );

		$is_fade = (bool) $data['fade'];

		if ( $is_fade ) {
			$slider_column_lg = $slider_column_md = $slider_column_sm = 1;
		}

		$args = [
			'slidesPerView'  => $slider_column_lg,
			'slidesPerGroup' => $slider_column_lg,
			'spaceBetween'   => absint( $data['spaceBetween'] ?? 30 ), // optional
			'loop'           => (bool) $data['infinite'],
			'speed'          => absint( $data['speed'] ),
			'simulateTouch'  => (bool) $data['draggable'],

			// Navigation (arrows)
			'navigation'     => [
				'nextEl' => '.swiper-button-next',
				'prevEl' => '.swiper-button-prev',
			],

			// Breakpoints
			'breakpoints'    => [
				// when window width is >= 1440px
				1440 => [
					'slidesPerView'  => $slider_column_lg,
					'slidesPerGroup' => $slider_column_lg,
				],
				// when window width is >= 800px
				800  => [
					'slidesPerView'  => $slider_column_md,
					'slidesPerGroup' => $slider_column_md,
				],
				// when window width is >= 100px
				100  => [
					'slidesPerView'  => $slider_column_sm,
					'slidesPerGroup' => $slider_column_sm,
				],
			],
		];


		if ( $is_fade ) {
			$args['effect']     = 'fade';
			$args['fadeEffect'] = [ 'crossFade' => true ];
		}

		$direction = $data['direction'] ?? 'horizontal';

		if ( ! $is_fade && 'vertical' === $direction ) {
			$args['direction']     = $direction;
			$args['slidesPerView'] = 1;
			$args['spaceBetween']  = 1;
		}

		if ( $data['dots'] ) {
			$args['pagination'] = [
				'el'             => '.swiper-pagination',
				'clickable'      => true,
				'dynamicBullets' => boolval( $data['dynamicBullets'] ),
			];
		}


		if ( $data['autoplay'] ) {
			$args['autoplay'] = [
				'delay'                => absint( $data['autoplaySpeed'] ),
				'disableOnInteraction' => false,
			];
		}

		return $args;
	}

	/**
	 * @param $post_type
	 *
	 * @return mixed|string
	 */
	public static function post_type_permission( $post_type ) {
		$post_type_object = get_post_type_object( $post_type );

		if ( ! $post_type_object ) {
			return 'post';
		}

		if ( $post_type_object->public ) {
			return $post_type;
		}

		if ( is_user_logged_in() ) {
			$user          = wp_get_current_user();
			$roles         = (array) $user->roles;
			$allowed_roles = [ 'administrator', 'editor', 'author', 'contributor' ];

			if ( array_intersect( $roles, $allowed_roles ) ) {
				return $post_type;
			}
		}

		return 'post';
	}

	/**
	 * Check post type permission
	 *
	 * @param $post_types
	 * @param $is_guten
	 *
	 * @return array|string
	 */
	public static function post_types_permission( $post_types ) {
		$final_post_type = [];
		foreach ( $post_types as $post_type ) {
			$post_type_object = get_post_type_object( $post_type );

			if ( ! $post_type_object ) {
				return 'post';
			}

			if ( $post_type_object->public ) {
				$final_post_type[] = $post_type;
				continue;
			}

			if ( is_user_logged_in() ) {
				$user          = wp_get_current_user();
				$roles         = (array) $user->roles;
				$allowed_roles = [ 'administrator', 'editor', 'author', 'contributor' ];

				if ( array_intersect( $roles, $allowed_roles ) ) {
					$final_post_type[] = $post_type;
				}
			}
		}

		return $final_post_type;
	}

	/**
	 * Scaping array
	 *
	 * @param $arr
	 *
	 * @return array|mixed
	 */
	public static function array_sanitize( $arr ) {
		if ( ! is_array( $arr ) ) {
			return $arr;
		}
		$escaped_arr = [];
		foreach ( $arr as $key => $value ) {
			if ( is_array( $value ) ) {
				$escaped_arr[ esc_attr( $key ) ] = self::array_sanitize( $value );
			} else {
				$escaped_arr[ esc_attr( $key ) ] = $value;
			}
		}

		return $escaped_arr;
	}

	/**
	 * Post Layout Data
	 *
	 * @param $data
	 * @param $post_classes
	 *
	 * @return array
	 */
	public static function post_layout_settings( $data, $post_classes = '' ) {
		return [
			'template'      => 'post-grid',
			'layout'        => $data['layout'],
			'post_limit'    => $data['post_limit'],
			'post_class'    => $post_classes,
			'entry_content' => [
				'excerpt_visibility' => $data['excerpt_visibility'],
				'content_limit'      => $data['content_limit'],
				'excerpt_more'       => $data['excerpt_more'],
			],
			'entry_footer'  => [
				'readmore_visibility' => $data['readmore_visibility'],
				'readmore_text'       => $data['readmore_text'],
				'show_btn_icon'       => $data['show_btn_icon'],
				'btn_icon'            => $data['btn_icon'] ?? '',
			],
			'thumbnail'     => [
				'thumbnail_visibility' => $data['thumbnail_visibility'],
				'thumbnail_size'       => $data['thumbnail_size'] ?? 'large',
			],
			'post_meta'     => [
				'meta_list'                => $data['meta_list'] ?? [],
				'separate_meta_list'       => $data['separate_meta_list'] ?? [],
				'separate_meta_visibility' => $data['separate_meta_visibility'],
				'meta_visibility'          => $data['meta_visibility'],
				'author_avatar'            => $data['author_avatar'],
				'author_prefix'            => $data['author_prefix'],
			],

		];
	}

	/**
	 * Grid Column
	 *
	 * @param $data
	 *
	 * @return string
	 */
	public static function grid_column( $data ) {
		$default = [ '4', '6', '12' ];

		if ( in_array( $data['layout'], [ 'list-1', 'list-2', 'list-3' ] ) ) {
			$default = [ '12', '12', '12' ];
		}

		$grid_column_lg = ! empty( $data['grid_column'] ) ? $data['grid_column'] : $default[0];
		$grid_column_md = ! empty( $data['grid_column_tablet'] ) ? $data['grid_column_tablet'] : $default[1];
		$grid_column_sm = ! empty( $data['grid_column_mobile'] ) ? $data['grid_column_mobile'] : $default[2];

		return "col-lg-$grid_column_lg col-md-$grid_column_md col-sm-$grid_column_sm col-$grid_column_sm";
	}

	/**
	 * Make layout depended on class for css
	 *
	 * @param $layout
	 * @param $prefix
	 *
	 * @return string
	 */
	public static function layout_prefix( $layout, $prefix = 'blog' ) {
		$parts = explode( '-', $layout );

		return $prefix . '-' . $parts[0];
	}

	public static function separate_meta( $post_meta ) {
		if ( 'yes' !== $post_meta['separate_meta_visibility'] ) {
			return;
		}
		$meta_list = $post_meta['separate_meta_list'];
		listzen_separate_meta( 'post', $meta_list );
	}

	public static function entry_content( $entry_content ) {
		if ( 'yes' !== $entry_content['excerpt_visibility'] ) {
			return;
		}
		$limit = $entry_content['content_limit'] ?? 15;
		$more  = $entry_content['excerpt_more'] ?? '';
		?>
        <div class="entry-content">
			<?php listzen_entry_content( $limit, $more ) ?>
        </div>
		<?php
	}

	public static function entry_meta( $post_meta ) {

		if ( 'yes' !== $post_meta['meta_visibility'] ) {
			return;
		}
		$meta_list = $post_meta['meta_list'];

		if ( 'yes' === $post_meta['separate_meta_visibility'] ) {
			$meta_list = array_diff( $meta_list, [ 'category' ] );
		}

		$args = [
			'include'       => $meta_list,
			'author_prefix' => $post_meta['author_prefix'],
			'with_avatar'   => $post_meta['author_avatar'],
		];
		PostMeta::get_meta( 'post', $args );
	}

	public static function entry_footer( $entry_footer ) {
		if ( 'yes' !== $entry_footer['readmore_visibility'] ) {
			return;
		}

		$label = $entry_footer['readmore_text'];
		$icon  = $entry_footer['show_btn_icon'] === 'yes' ? 'rt-icon-arrow-right' : null;

		listzen_entry_footer( $label, $icon );
	}
}


