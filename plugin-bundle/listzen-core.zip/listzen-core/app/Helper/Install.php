<?php

namespace ListzenCore\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
class Install {

	public static function activate() {
		self::create_cron_jobs();
		add_option( 'listzen_activation_redirect', true );
		self::import_store_options();
	}

	public static function deactivate() {
		update_option( 'listzen_flush_rewrite_rules', 0 );
		self::clean_cron_jobs();
	}


	public static function clean_cron_jobs() {
		// Un-schedules all previously-scheduled cron jobs

		wp_clear_scheduled_hook( 'listzen_daily_scheduled_events' );
	}

	/**
	 * Create cron jobs (clear them first)
	 *
	 * @return void
	 */
	private static function create_cron_jobs() {
		self::clean_cron_jobs();

		if ( ! wp_next_scheduled( 'listzen_daily_scheduled_events' ) ) {
			$ve          = get_option( 'gmt_offset' ) > 0 ? '-' : '+';
			$expire_time = strtotime( '00:00 tomorrow ' . $ve . absint( get_option( 'gmt_offset' ) ) . ' HOURS' );
			wp_schedule_event( $expire_time, 'daily', 'listzen_daily_scheduled_events' );
		}
	}

	/**
	 * Import some default options for enable membership
	 * to ignore 'can't import store_category' from OCDI
	 *
	 * @return void
	 */
	private static function import_store_options() {
		if ( 'yes' !== get_option( 'rtcl_membership_migration' ) ) {
			$store_settings = [
				'number_of_free_ads'                  => '4',
				'renewal_days_for_free_ads'           => '20',
				'membership_section'                  => '',
				'enable'                              => 'yes',
				'enable_store'                        => 'yes',
				'stores_per_page'                     => '12',
				'stores_per_row'                      => '4',
				'enable_store_rating'                 => 'yes',
				'new_store_status'                    => 'publish',
				'enable_store_only_membership'        => 'no',
				'display_store_only_valid_membership' => 'no',
				'enable_store_manager'                => 'yes',
				'renew_only_membership'               => 'no',
				'enable_free_ads'                     => 'yes',
				'unlimited_free_ads_membership'       => 'no',
			];

			update_option( 'rtcl_membership_settings', $store_settings );
			update_option( 'rtcl_membership_migration', 'yes' );
		}
	}
}
