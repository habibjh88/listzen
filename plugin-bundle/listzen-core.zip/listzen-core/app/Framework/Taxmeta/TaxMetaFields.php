<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Framework\Taxmeta;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ListzenCore\Framework\Postmeta\MetaFields;
use ListzenCore\Traits\SingletonTraits;

/**
 * TaxMetaFields Class
 */
class TaxMetaFields extends MetaFields {
	use SingletonTraits;

	/**
	 * Display fields
	 *
	 * @param $fields
	 * @param $term_id
	 * @param $type
	 *
	 * @return void
	 */
	public static function display_fields( $fields, $term_id, $type = 'edit' ) {

		foreach ( $fields as $key => $field ) {
			// Display group field
			if ( $field['type'] == 'group' ) {
				$parent_key = $key . "['$key']";
				foreach ( $field['value'] as $key2 => $field2 ) {
					$parent_key = $key . "[$key2]";
					$default    = get_term_meta( $term_id, $key, true );
					$default    = empty( $default[ $key2 ] ) ? false : $default[ $key2 ];
					self::display_single_field( $parent_key, $field2, $term_id, $type, $default );
				}
			} // Display single field
			else {
				self::display_single_field( $key, $field, $term_id, $type );
			}
		}
	}

	/**
	 * Display Single Fields
	 *
	 * @param $key
	 * @param $field
	 * @param $term_id
	 * @param $type
	 * @param $default
	 *
	 * @return void
	 */
	private static function display_single_field( $key, $field, $term_id, $type, $default = false ) {
		// Set default value
		if ( ! $default ) {
			$default = get_term_meta( $term_id, $key, true );
		}

		if ( $field['type'] != 'multi_checkbox' && empty( $default ) && ! empty( $field['default'] ) ) {
			$default = $field['default'];
		}

		// class
		if ( ! empty( $field['class'] ) ) {
			$class = 'class="listzen-meta-field ' . esc_attr( $field['class'] ) . '"';
		} else {
			$class = 'class="listzen-meta-field"';
		}

		if ( $type == 'add' ) {
			self::add_field_html( $key, $field, $default, $class );
		} else {
			self::edit_field_html( $key, $field, $default, $class );
		}
	}

	/**
	 * Edit html fields
	 *
	 * @param $key
	 * @param $field
	 * @param $default
	 * @param $class
	 *
	 * @return void
	 */
	private static function edit_field_html( $key, $field, $default, $class ) {
		$desc = '';
		if ( ! empty( $field['desc'] ) ) {
			$desc = '<div class="listzen-postmeta-desc">' . listzen_html( $field['desc'], '', false ) . '</div>';
		}
		?>
		<tr class="form-field term-<?php echo esc_attr( $key ); ?>-wrap">
			<th scope="row"><label for="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $field['label'] ); ?></label></th>
			<td>
				<?php
				if ( method_exists( __CLASS__, $field['type'] ) ) {
					self::{$field['type']}( $key, $field, $default, $class );
				}
                listzen_html( $desc );
				?>
			</td>
		</tr>
		<?php
	}

	/**
	 * Add html fields
	 *
	 * @param $key
	 * @param $field
	 * @param $default
	 * @param $class
	 *
	 * @return void
	 */
	private static function add_field_html( $key, $field, $default, $class ) {
		$desc = '';
		if ( ! empty( $field['desc'] ) ) {
			$desc = '<div class="listzen-postmeta-desc">' . listzen_html( $field['desc'], '', false ) . '</div>';
		}
		?>
		<div class="form-field term-<?php echo esc_attr( $key ); ?>-wrap">
			<label for="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $field['label'] ); ?></label>
			<?php
			if ( method_exists( __CLASS__, $field['type'] ) ) {
				self::{$field['type']}( $key, $field, $default, $class );
                listzen_html( $desc );
			}
			?>
		</div>
		<?php
	}
}
