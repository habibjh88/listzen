<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Framework\Taxmeta;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use ListzenCore\Framework\Postmeta\PostMeta;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

//phpcs:ignore

/**
 * TaxMeta class
 */
class TaxMeta extends Postmeta {

	private static $tax_meta = [];

	/**
	 * Class constructor
	 */
	private function __construct() {
		add_action( 'init', [ $this, 'initialize' ], 12 );
	}

	/**
	 * Initialize function
	 *
	 * @return void
	 */
	public function initialize() {
		if ( ! is_admin() ) {
			return;
		}

		$tax_done = [];

		foreach ( self::$tax_meta as $id => $meta ) {
			if ( ! in_array( $meta['taxonomy'], $tax_done ) ) {
				add_action( "{$meta['taxonomy']}_add_form_fields", [ __CLASS__, 'add_tax_fields' ], $meta['priority'] );
				add_action( "{$meta['taxonomy']}_edit_form_fields", [ __CLASS__, 'edit_tax_fields' ], $meta['priority'], 2 );
				$tax_done[] = $meta['taxonomy'];
			}
		}

		add_action( 'created_term', [ $this, 'save_fields' ], 10, 3 );
		add_action( 'edit_term', [ $this, 'save_fields' ], 10, 3 );
	}

	/**
	 * Add tax meta
	 *
	 * @param $id
	 * @param $taxonomy
	 * @param $priority
	 * @param $fields
	 *
	 * @return void
	 */
	public static function add_tax_meta( $id, $taxonomy, $priority = 10, $fields = '' ) {
		$tax_metas             = [
			'taxonomy' => $taxonomy,
			'priority' => $priority,
			'fields'   => $fields,
		];
		self::$tax_meta[ $id ] = apply_filters( 'listzen_tax_meta_' . $id, $tax_metas );
	}

	/**
	 * Add tax fields
	 *
	 * @param $taxonomy
	 *
	 * @return void
	 */
	public static function add_tax_fields( $taxonomy ) {
		wp_nonce_field( self::$nonce_action, self::$nonce_field );
		foreach ( self::$tax_meta as $meta ) {
			if ( $taxonomy == $meta['taxonomy'] ) {
				TaxMetaFields::display_fields( $meta['fields'], 0, 'add' );
			}
		}
	}

	/**
	 * Edit tax fields
	 *
	 * @param $term
	 * @param $taxonomy
	 *
	 * @return void
	 */
	public static function edit_tax_fields( $term, $taxonomy ) {
		foreach ( self::$tax_meta as $meta ) {
			if ( $taxonomy == $meta['taxonomy'] ) {
				TaxMetaFields::display_fields( $meta['fields'], $term->term_id );
			}
		}
	}

	/**
	 * Save fields
	 *
	 * @param $term_id
	 * @param $tt_id
	 * @param $taxonomy
	 *
	 * @return void
	 */
	public static function save_fields( $term_id, $tt_id, $taxonomy ) {

		// Only verify nonce when this is an admin POST request
		if ( is_admin() && isset( $_POST[ self::$nonce_field ] ) ) {
			if ( ! check_admin_referer( self::$nonce_action, self::$nonce_field ) ) {
				return;
			}
		}

		foreach ( self::$tax_meta as $meta ) {
			if ( $taxonomy == $meta['taxonomy'] ) {
				foreach ( $meta['fields'] as $field => $data ) {
					self::save_single_meta( $field, $data, $term_id );
				}
			}
		}
	}


	/**
	 * Save single meta
	 *
	 * @param $field
	 * @param $data
	 * @param $term_id
	 *
	 * @return void
	 */
	public static function save_single_meta( $field, $data, $term_id ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( isset( $_POST[ $field ] ) ) {
			$old = get_term_meta( $term_id, $field, true );
			$new = $_POST[ $field ]; // phpcs:ignore

			if ( $data['type'] == 'group' ) {
				$new = self::sanitize_group_field( $new, $data['value'] );
			} elseif ( $data['type'] == 'repeater' ) {
				$new = self::sanitize_repeater_field( $new, $data['value'] );
			} else {
				$new = self::sanitize_field( $new, $data['type'] );
			}

			// Update
			if ( $new != $old ) {
				if ( $new == [] ) { // assuming repeater field is empty array
					delete_term_meta( $term_id, $field );
				} else {
					update_term_meta( $term_id, $field, $new );
				}
			}
		} else {
			if ( $data['type'] == 'checkbox' || $data['type'] == 'multi_checkbox' || $data['type'] == 'multi_select' ) {
				delete_term_meta( $term_id, $field );
			}
		}
	}
}
