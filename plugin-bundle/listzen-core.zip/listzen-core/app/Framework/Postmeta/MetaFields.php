<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Framework\Postmeta;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ListzenCore\Traits\SingletonTraits;

class MetaFields {
	use SingletonTraits;

	/**
	 * Store conditional fields
	 * @var
	 */
	public static $conditioinal_fields;

	/**
	 * Display multiple meta fields in the post meta table.
	 *
	 * @param array $fields Array of field configurations.
	 * @param int $post_id Post ID to retrieve/save meta.
	 * @param array $condition_fields Optional array of conditional field keys.
	 */
	public static function display_fields( $fields, $post_id, $condition_fields = [] ) {

		if ( ! empty( $condition_fields ) ) {
			self::$conditioinal_fields = $condition_fields;
		}
		echo '<table class="listzen-postmeta-container">';

		foreach ( $fields as $key => $field ) {
			// Display group field
			if ( $field['type'] == 'group' ) {
				// $parent_key = $key. "['$key']";
				foreach ( $field['value'] as $key2 => $field2 ) {
					$parent_key = $key . "[$key2]";
					$default    = get_post_meta( $post_id, $key, true );
					$default    = empty( $default[ $key2 ] ) ? false : $default[ $key2 ];
					self::display_single_field( $parent_key, $field2, $post_id, $default );
				}
			} // Display repeater field
            elseif ( $field['type'] == 'repeater' ) {
				self::display_repeater_field( $key, $field, $post_id );
			} // Display single field
			else {
				self::display_single_field( $key, $field, $post_id );
			}
		}

		echo '</table>';
	}

	/**
	 * Display a repeater field in the post meta table.
	 *
	 * @param string $key Field key (used for name/id and meta retrieval).
	 * @param array $field Field configuration array (type, label, default, etc.).
	 * @param int $post_id Post ID to retrieve/save meta.
	 */
	private static function display_repeater_field( $key, $field, $post_id ) {
		$meta = get_post_meta( $post_id, $key, true );

		if ( empty( $meta ) ) {
			$meta = [];
		}
		$count = count( $meta );

		echo ! empty( $field['label'] ) ? '<tr><th colspan="2">' . esc_html( $field['label'] ) . ':</th></tr>' : '';
		echo '<tr><td colspan="2" class="listzen-postmeta-repeater-wrap" data-num="' . esc_attr( $count ) . '" data-fieldname="' . esc_attr( $key ) . '">';

		// First Hidden Item
		echo '<table class="listzen-postmeta-repeater repeater-init">';
		foreach ( $field['value'] as $key2 => $field2 ) {
			$parent_key = $key . "[hidden][$key2]";
			self::display_single_field( $parent_key, $field2, $post_id, '' );
		}
		echo '</table>';

		// repeatative items
		if ( ! empty( $meta ) ) {
			foreach ( $meta as $item => $itemvalue ) {
				echo '<table class="listzen-postmeta-repeater">';

				foreach ( $field['value'] as $repkey => $repvalue ) {
					$display_key = $key . "[$item]" . "[$repkey]";
					$fieldvalue  = isset( $itemvalue[ $repkey ] ) ? $itemvalue[ $repkey ] : false;
					self::display_single_field( $display_key, $repvalue, $post_id, $fieldvalue );
				}

				echo '</table>';
			}
		}

		$buttontext = empty( $field['button'] ) ? esc_html__( 'Add More', 'listzen-core' ) : $field['button'];
		echo '<div class="listzen-postmeta-repeater-addmore"><button>' . esc_html( $buttontext ) . '</button></div></td></tr>';
	}

	/**
	 * Display a single meta field row in the post meta table.
	 *
	 * @param string $key Field key (used for name, id, and meta retrieval).
	 * @param array $field Field configuration array (type, label, default, etc.).
	 * @param int $post_id Post ID to retrieve/save meta.
	 * @param mixed $default Default value for the field (optional).
	 */
	private static function display_single_field( $key, $field, $post_id, $default = false ) {
		$tr_class = str_replace( '[', '-', rtrim( $key, ']' ) );

		// Set default value
		if ( ! $default ) {
			$default = get_post_meta( $post_id, $key, true );
		}

		if ( $field['type'] != 'multi_checkbox' && empty( $default ) && ! empty( $field['default'] ) ) {
			$default = $field['default'];
		}

		$desc = '';
		if ( ! empty( $field['desc'] ) ) {
			$desc = '<div class="listzen-postmeta-desc">' . listzen_html( $field['desc'], '', false ) . '</div>';
		}

		$container_attr = '';
		if ( ! empty( $field['required'] ) ) {
			$container_attr .= ' class="listzen-postmeta-tr listzen-postmeta-dependent ' . $tr_class . '"';
			$container_attr .= ' data-required="' . esc_attr( $field['required'][0] ) . '"';
			$container_attr .= ' data-required-value="' . esc_attr( $field['required'][1] ) . '"';
		} else {
			if ( is_array( self::$conditioinal_fields ) && in_array( $key, self::$conditioinal_fields ) ) {
				$tr_class .= ' has-condition';
			}
			$container_attr .= ' class="listzen-postmeta-tr ' . $tr_class . '"';
		}

		// Display Title
		if ( $field['type'] == 'header' ) {
			$default = empty( $field['default'] ) ? 'h1' : $field['default'];
			echo '<tr ' . esc_attr( $container_attr ) . '><td colspan="2"><' . esc_html( $default ) . '>' . esc_html( $field['label'] ) . '</' . esc_html( $default ) . '>' . wp_kses_post( $desc );
		} elseif ( empty( $field['label'] ) ) {
			echo '<tr ' . esc_attr( $container_attr ) . '><td colspan="2">';
		} else {
			echo '<tr ' . esc_attr( $container_attr ) . '><th><label for="' . esc_attr( $key ) . '">' . esc_html( $field['label'] ) . '</label></th><td>';
		}

		// class
		if ( ! empty( $field['class'] ) ) {
			$class = 'listzen-meta-field ' . esc_attr( $field['class'] );
		} else {
			$class = 'listzen-meta-field';
		}

		$field['post_id'] = $post_id;
		// Display input
		if ( method_exists( __CLASS__, $field['type'] ) ) {
			self::{$field['type']}( $key, $field, $default, $class );
			listzen_html( $desc );
		}

		echo '</td></tr>';
	}

	/**
	 * Output a text input field.
	 *
	 * @param string $key Field key (used for name and id attributes).
	 * @param array $field Field configuration. Can include 'placeholder'.
	 * @param string $default Default text value.
	 * @param string $class Additional CSS class for the input (optional).
	 */
	public static function text( $key, $field, $default = '', $class = '' ) {
		$placeholder = $field['placeholder'] ?? '';
		?>
        <input
                type="text"
                placeholder="<?php echo esc_attr( $placeholder ); ?>"
                class="<?php echo esc_attr( $class ); ?>"
                name="<?php echo esc_attr( $key ); ?>"
                id="<?php echo esc_attr( $key ); ?>"
                value="<?php echo esc_attr( $default ); ?>"
        />
		<?php
	}

	/**
	 * Output a number input field.
	 *
	 * @param string $key Field key (used for name and id attributes).
	 * @param array $field Field configuration (not used here but kept for compatibility).
	 * @param string $default Default numeric value.
	 * @param string $class Additional CSS class for the input (optional).
	 */
	public static function number( $key, $field, $default = '', $class = '' ) {
		?>
        <input
                type="number"
                class="<?php echo esc_attr( $class ); ?>"
                name="<?php echo esc_attr( $key ); ?>"
                id="<?php echo esc_attr( $key ); ?>"
                value="<?php echo esc_attr( $default ); ?>"
                step="any"
        />
		<?php
	}

	/**
	 * Output a textarea field.
	 *
	 * @param string $key Field key (used for name and id attributes).
	 * @param array $field Field configuration (not used here but kept for compatibility).
	 * @param string $default Default value for the textarea.
	 * @param string $class CSS class for the textarea.
	 */
	public static function textarea( $key, $field, $default, $class ) {
		?>
        <textarea
                class="<?php echo esc_attr( $class ); ?>"
                name="<?php echo esc_attr( $key ); ?>"
                id="<?php echo esc_attr( $key ); ?>"
        ><?php echo esc_textarea( $default ); ?></textarea>
		<?php
	}

	/**
	 * Output a textarea field.
	 *
	 * @param string $key Field key (used for name and id attributes).
	 * @param array $field Field configuration (not used here but kept for future use).
	 * @param string $default Default value for the textarea.
	 * @param string $class CSS class for the textarea.
	 */
	public static function textarea_html( $key, $field, $default, $class ) {
		?>
        <textarea
                class="<?php echo esc_attr( $class ); ?>"
                name="<?php echo esc_attr( $key ); ?>"
                id="<?php echo esc_attr( $key ); ?>"
        ><?php echo esc_textarea( $default ); ?></textarea>
		<?php
	}

	/**
	 * Output a select dropdown field.
	 *
	 * @param string $key Field key (used for name and id attributes).
	 * @param array $field Field configuration. Must include 'options' array.
	 * @param string $default Default selected value.
	 * @param string $class CSS class for the select element.
	 */
	public static function select( $key, $field, $default, $class ) {
		?>
        <select
                name="<?php echo esc_attr( $key ); ?>"
                id="<?php echo esc_attr( $key ); ?>"
                class="<?php echo esc_attr( $class ); ?>"
        >
			<?php foreach ( $field['options'] as $option_key => $option_value ) : ?>
                <option value="<?php echo esc_attr( $option_key ); ?>"
					<?php selected( $default, $option_key ); ?>
                >
					<?php echo esc_html( $option_value ); ?>
                </option>
			<?php endforeach; ?>
        </select>
		<?php
	}

	/**
	 * Output a Font Awesome icon select dropdown.
	 *
	 * @param string $key Field key (used for name and id attributes).
	 * @param array $field Field configuration. Must include 'options' array.
	 * @param string $default Default selected value.
	 * @param string $class Additional CSS classes for the select element.
	 */
	public static function icon_select( $key, $field, $default, $class ) {
		?>
        <select
                class="select2_font_awesome <?php echo esc_attr( $class ); ?>"
                name="<?php echo esc_attr( $key ); ?>"
                id="<?php echo esc_attr( $key ); ?>"
        >
			<?php foreach ( $field['options'] as $option_key => $option_value ) : ?>
                <option
                        value="<?php echo esc_attr( $option_key ); ?>"
                        data-icon="<?php echo esc_attr( $option_key ); ?>"
					<?php selected( $default, $option_key ); ?>
                >
					<?php echo esc_html( $option_value ); ?>
                </option>
			<?php endforeach; ?>
        </select>
		<?php
	}

	/**
	 * Output a checkbox field.
	 *
	 * @param string $key Field key (used for name and id attributes).
	 * @param array $field Field configuration (not used here but kept for compatibility).
	 * @param bool $default Whether the checkbox should be checked by default.
	 * @param string $class Additional CSS class (optional, can be added if needed).
	 */
	public static function checkbox( $key, $field, $default, $class = '' ) {
		?>
        <input
                type="checkbox"
                name="<?php echo esc_attr( $key ); ?>"
                id="<?php echo esc_attr( $key ); ?>"
                class="<?php echo esc_attr( $class ); ?>"
			<?php checked( $default, true ); ?>
        />
		<?php
	}

	/**
	 * Output a multi-select dropdown field.
	 *
	 * @param string $key Field key (used for name and id attributes).
	 * @param array $field Field configuration. Must include 'options' array.
	 * @param array $default Default selected values (array).
	 * @param string $class Additional CSS class for the select element.
	 */
	public static function multi_select( $key, $field, $default, $class = '' ) {
		if ( empty( $default ) || ! is_array( $default ) ) {
			$default = [];
		}
		?>
        <select
                class="listzen-multi-select <?php echo esc_attr( $class ); ?>"
                name="<?php echo esc_attr( $key ); ?>[]"
                id="<?php echo esc_attr( $key ); ?>"
                data-placeholder="<?php echo esc_attr__( 'Click here to select options', 'listzen-core' ); ?>"
                multiple="multiple"
        >
			<?php foreach ( $field['options'] as $option_key => $option_value ) : ?>
                <option
                        value="<?php echo esc_attr( $option_key ); ?>"
					<?php echo in_array( $option_key, $default, true ) ? 'selected="selected"' : ''; ?>
                >
					<?php echo esc_html( $option_value ); ?>
                </option>
			<?php endforeach; ?>
        </select>
		<?php
	}

	/**
	 * Display a multi-select field with optgroups for Select2.
	 *
	 * @param string $key Field key (used for name/id and meta retrieval).
	 * @param array $field Field configuration array (options, label, etc.).
	 * @param mixed $default Default selected value(s).
	 * @param string $class Additional CSS classes for the select field.
	 */
	public static function multi_select2( $key, $field, $default, $class ) {
		if ( empty( $default ) ) {
			$default = [];
		}

		echo '<select class="listzen-multi-select ' . esc_attr( $class ) . '" data-placeholder=" ' . esc_attr__( 'Click here to select options', 'listzen-core' ) . '" multiple="multiple"' .
		     ' name="' . esc_attr( $key ) . '[]"' .
		     ' id="' . esc_attr( $key ) . '">';

		$options = $field['options'];
		foreach ( $options as $key => $option ) {

			$label = $option['label'] ?? '';
			echo '<optgroup label="' . esc_html( $label ) . '" data-select2-id="select2-data-' . esc_attr( $key ) . '">';

			foreach ( $option['value'] as $key2 => $value ) {
				if ( is_array( $default ) ) {
					$selected = in_array( $key2, $default ) ? 'selected="selected"' : '';
				} else {
					$selected = $key2 == $default ? 'selected="selected"' : '';
				}
				?>
                <option
					<?php echo esc_attr( $selected ); ?>
                        value="<?php echo esc_attr( $key2 ); ?>"
                        data-select2-id="<?php echo esc_attr( $key2 ); ?>"
                >
					<?php echo esc_html( $value ); ?>
                </option>
				<?php
			}

			echo ' </optgroup>';
		}
		echo '</select>';
	}

	/**
	 * Display an AJAX-enabled multi-select field.
	 *
	 * @param string $key Field key (used for name/id).
	 * @param array $field Field configuration array.
	 * @param array $default Array of default selected post IDs.
	 * @param string $class Additional CSS classes for the select field.
	 */
	public static function ajax_select( $key, $field, $default, $class ) {
		if ( empty( $default ) ) {
			$default = [];
		}
		$class = 'listzen-ajax-multi-select ' . esc_attr( $class );
		?>
        <label>
            <select
                    name="<?php echo esc_attr( $key ); ?>[]"
                    id="<?php echo esc_attr( $key ); ?>"
                    class="<?php echo esc_attr( $class ); ?>"
                    multiple="multiple"
                    style="width:400px;">
				<?php
				if ( ! empty( $default ) ) {
					foreach ( $default as $item ) {
						$p = get_the_title( $item );
						echo "<option value='".esc_attr( $item )."' selected> " . esc_html( $p ) . " </option>";
					}
				}
				?>
            </select>
        </label>
		<?php
	}

	/**
	 * Output multiple checkboxes for a single field.
	 *
	 * @param string $key Field key (used for name attributes).
	 * @param array $field Field configuration. Must include 'options' array.
	 * @param array $default Default selected values (array).
	 * @param string $class Additional CSS class for checkboxes.
	 */
	public static function multi_checkbox( $key, $field, $default = [], $class = '' ) {
		if ( empty( $default ) || ! is_array( $default ) ) {
			$default = [];
		}

		foreach ( $field['options'] as $value => $title ) {
			$id = $key . '_' . $value;
			?>
            <span class="listzen-postmeta-radio">
			<input
                    type="checkbox"
                    class="<?php echo esc_attr( $class ); ?>"
                    name="<?php echo esc_attr( $key ); ?>[]"
                    id="<?php echo esc_attr( $id ); ?>"
                    value="<?php echo esc_attr( $value ); ?>"
				<?php echo in_array( $value, $default, true ) ? 'checked="checked"' : ''; ?>
			/>
			<label for="<?php echo esc_attr( $id ); ?>">
				<?php echo esc_html( $title ); ?>
			</label>
		</span>
			<?php
		}
	}

	/**
	 * Output a set of radio buttons for a field.
	 *
	 * @param string $key Field key (used for name attributes).
	 * @param array $field Field configuration. Must include 'options' array.
	 * @param string $default Default selected value.
	 * @param string $class Additional CSS class for radio inputs.
	 */
	public static function radio( $key, $field, $default = '', $class = '' ) {
		foreach ( $field['options'] as $value => $title ) {
			$id = $key . '_' . $value;
			?>
            <span class="listzen-postmeta-radio">
			<input
                    type="radio"
                    class="<?php echo esc_attr( $class ); ?>"
                    name="<?php echo esc_attr( $key ); ?>"
                    id="<?php echo esc_attr( $id ); ?>"
                    value="<?php echo esc_attr( $value ); ?>"
				<?php checked( $default, $value ); ?>
			/>
			<label for="<?php echo esc_attr( $id ); ?>">
				<?php echo esc_html( $title ); ?>
			</label>
		</span>
			<?php
		}
	}

	/**
	 * Output an image upload field.
	 *
	 * @param string $key Field key (used for name and class attributes).
	 * @param array $field Field configuration (not used here but kept for compatibility).
	 * @param int $default Attachment ID of the default image.
	 * @param string $class Additional CSS class for wrapper (optional).
	 */
	public static function image( $key, $field, $default = 0, $class = '' ) {
		$image_url = '';
		$display   = '';

		if ( $default ) {
			$image_src = wp_get_attachment_image_src( $default, 'medium' );
			if ( $image_src ) {
				$image_url = $image_src[0];
			}
		} else {
			$display = 'display:none;';
		}
		?>
        <div class="listzen_metabox_image <?php echo esc_attr( $class ); ?>">
            <input
                    name="<?php echo esc_attr( $key ); ?>"
                    type="hidden"
                    class="custom_upload_image"
                    value="<?php echo esc_attr( $default ); ?>"
            />
            <img
                    src="<?php echo esc_url( $image_url ); ?>"
                    class="custom_preview_image"
                    style="<?php echo esc_attr( $display ); ?>"
                    alt=""
            />
            <input
                    class="listzen_upload_image upload_button_<?php echo esc_attr( $key ); ?> button-primary"
                    type="button"
                    value="<?php echo esc_attr__( 'Choose Image', 'listzen-core' ); ?>"
            />
            <div class="listzen_remove_image_wrap" style="<?php echo esc_attr( $display ); ?>">
                <a href="#" class="listzen_remove_image button">
					<?php echo esc_html__( 'Remove Image', 'listzen-core' ); ?>
                </a>
            </div>
        </div>
		<?php
	}

	/**
	 * Output a gallery upload field.
	 *
	 * @param string $key Field key (used for name and class attributes).
	 * @param array $field Field configuration (not used here but kept for compatibility).
	 * @param string $default Comma-separated attachment IDs of gallery images.
	 * @param string $class Additional CSS class for wrapper (optional).
	 */
	public static function gallery( $key, $field, $default = '', $class = '' ) {
		$display  = '';
		$img_html = '';

		if ( ! empty( $default ) ) {
			$img_ids = explode( ',', $default );
			foreach ( $img_ids as $img_id ) {
				$img_id = intval( $img_id );
				if ( $img_id <= 0 ) {
					continue;
				}

				$image      = wp_get_attachment_image_src( $img_id, 'medium' );
				$image_full = wp_get_attachment_image_src( $img_id, 'full' );
				$image_url  = $image[0] ?? $image_full[0] ?? '';

				if ( $image_url ) {
					$img_html .= '<img src="' . esc_url( $image_url ) . '" alt="" />';
				}
			}
		} else {
			$display = 'display:none;';
		}
		?>
        <div class="listzen_metabox_gallery <?php echo esc_attr( $class ); ?>">
            <input
                    name="<?php echo esc_attr( $key ); ?>"
                    type="hidden"
                    class="custom_upload_image"
                    value="<?php echo esc_attr( $default ); ?>"
            />
            <div class="custom_preview_images">
				<?php listzen_html( $img_html ); ?>
            </div>
            <div class="listzen_metabox_gallery_buttons">
                <input
                        class="listzen_upload_gallery upload_button_<?php echo esc_attr( $key ); ?> button-primary"
                        type="button"
                        value="<?php echo esc_attr__( 'Add/Edit Gallery Images', 'listzen-core' ); ?>"
                />
                <a
                        href="#"
                        class="listzen_remove_gallery button"
                        style="<?php echo esc_attr( $display ); ?>"
                >
					<?php echo esc_html__( 'Remove All Images', 'listzen-core' ); ?>
                </a>
            </div>
        </div>
		<?php
	}

	/**
	 * Output a file upload field.
	 *
	 * @param string $key Field key (used for name and class attributes).
	 * @param array $field Field configuration (not used here but kept for compatibility).
	 * @param int $default Attachment ID of the default file.
	 * @param string $class Additional CSS class for wrapper (optional).
	 */
	public static function file( $key, $field, $default = 0, $class = '' ) {
		$file_url   = '#';
		$file_title = '';
		$display    = '';

		if ( $default ) {
			$file_url   = wp_get_attachment_url( $default );
			$file_title = get_the_title( $default );
		} else {
			$display = 'display:none;';
		}
		?>
        <div class="listzen_metabox_file <?php echo esc_attr( $class ); ?>">
            <input
                    name="<?php echo esc_attr( $key ); ?>"
                    type="hidden"
                    class="custom_upload_file"
                    value="<?php echo esc_attr( $default ); ?>"
            />
            <input
                    class="listzen_upload_file upload_button_<?php echo esc_attr( $key ); ?> button-primary"
                    type="button"
                    value="<?php echo esc_attr__( 'Choose File', 'listzen-core' ); ?>"
            />
            <div class="listzen_remove_file_wrap" style="<?php echo esc_attr( $display ); ?>">
                <a href="#" class="listzen_remove_file button">
					<?php echo esc_html__( 'Remove File', 'listzen-core' ); ?>
                </a>
            </div>
            <a
                    class="custom_preview_file"
                    href="<?php echo esc_url( $file_url ); ?>"
                    style="<?php echo esc_attr( $display ); ?>"
            >
				<?php echo esc_html( $file_title ); ?>
            </a>
        </div>
		<?php
	}

	/**
	 * Output a color picker field.
	 *
	 * @param string $key Field key (used for name and id attributes).
	 * @param array $field Field configuration (not used here but kept for compatibility).
	 * @param string $default Default color value (hex code or CSS color).
	 * @param string $class Additional CSS class for the input (optional).
	 */
	public static function color_picker( $key, $field, $default = '', $class = '' ) {
		?>
        <input
                type="text"
                class="listzen-metabox-picker listzen-metabox-colorpicker <?php echo esc_attr( $class ); ?>"
                name="<?php echo esc_attr( $key ); ?>"
                id="<?php echo esc_attr( $key ); ?>"
                value="<?php echo esc_attr( $default ); ?>"
        />
		<?php
	}

	/**
	 * Output a date picker field.
	 *
	 * @param string $key Field key (used for name and id attributes).
	 * @param array $field Field configuration. Can include 'format'.
	 * @param string $default Default date value.
	 * @param string $class Additional CSS class for the input (optional).
	 */
	public static function date_picker( $key, $field, $default = '', $class = '' ) {
		$format = isset( $field['format'] ) ? $field['format'] : 'MM dd, yy';
		?>
        <input
                type="text"
                data-format="<?php echo esc_attr( $format ); ?>"
                class="listzen-metabox-picker listzen-metabox-datepicker <?php echo esc_attr( $class ); ?>"
                name="<?php echo esc_attr( $key ); ?>"
                id="<?php echo esc_attr( $key ); ?>"
                value="<?php echo esc_attr( $default ); ?>"
        />
		<?php
	}

	/**
	 * Output a time picker field.
	 *
	 * @param string $key Field key (used for name and id attributes).
	 * @param array $field Field configuration (not used here but kept for compatibility).
	 * @param string $default Default time value.
	 * @param string $class Additional CSS class for the input (optional).
	 */
	public static function time_picker( $key, $field, $default = '', $class = '' ) {
		?>
        <input
                type="text"
                class="listzen-metabox-picker listzen-metabox-timepicker <?php echo esc_attr( $class ); ?>"
                name="<?php echo esc_attr( $key ); ?>"
                id="<?php echo esc_attr( $key ); ?>"
                value="<?php echo esc_attr( $default ); ?>"
        />
		<?php
	}

	/**
	 * Output a 24-hour format time picker field.
	 *
	 * @param string $key Field key (used for name and id attributes).
	 * @param array $field Field configuration (not used here but kept for compatibility).
	 * @param string $default Default time value.
	 * @param string $class Additional CSS class for the input (optional).
	 */
	public static function time_picker_24( $key, $field, $default = '', $class = '' ) {
		?>
        <input
                type="text"
                class="listzen-metabox-picker listzen-metabox-timepicker-24 <?php echo esc_attr( $class ); ?>"
                name="<?php echo esc_attr( $key ); ?>"
                id="<?php echo esc_attr( $key ); ?>"
                value="<?php echo esc_attr( $default ); ?>"
        />
		<?php
	}
}
