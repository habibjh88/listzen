<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Framework\Postmeta;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ListzenCore\Traits\SingletonTraits;

/**
 * Postmeta class
 */
class PostMeta {
	use SingletonTraits;

	private static $metaboxes = [];
	private static $metabox_fields = [];
	private static $metabox_condition = [];

	public static $nonce_action = 'listzen_metabox_nonce';
	public static $nonce_field = 'listzen_metabox_nonce_secret';

	private function __construct() {
		add_action( 'init', [ $this, 'initialize' ], 12 );
	}


	/**
	 * Initialize
	 *
	 * @return void
	 */
	public function initialize() {
		if ( ! is_admin() ) {
			return;
		}

		add_action( 'add_meta_boxes', [ __CLASS__, 'register_meta_boxes' ], 5 );
		add_action( 'save_post', [ __CLASS__, 'save_metaboxes' ] );
	}

	/**
	 * Collect metabox fields
	 *
	 * @param $id
	 * @param $title
	 * @param $post_types
	 * @param $callback
	 * @param $context
	 * @param $priority
	 * @param $fields
	 *
	 * @return void
	 */
	public static function add_meta_box( $id, $title, $post_types, $callback = '', $context = '', $priority = '', $fields = '' ) {
		$fields    = apply_filters( 'listzen_postmeta_field_' . $id, $fields );
		$metaboxes = [
			'title'         => $title,
			'callback'      => $callback,
			'post_type'     => $post_types,
			'context'       => empty( $context ) ? 'normal' : $context,
			'priority'      => $priority,
			'callback_args' => $fields,
		];

		self::$metaboxes[ $id ]      = apply_filters( 'listzen_metabox_' . $id, $metaboxes );
		self::$metabox_fields[ $id ] = $fields['fields'];
		self::find_conditional_fields( $fields['fields'] );
	}

	/**
	 * Get conditional fields id
	 *
	 * @param $fields
	 * @param $metabox_condition
	 *
	 * @return void
	 */
	public static function find_conditional_fields( $fields ) {
		foreach ( $fields as $field_id => $field ) {
			if ( 'group' == $field['type'] ) {
				self::find_conditional_fields( $field['value'] );
			} elseif ( isset( $field['required'] ) ) {
				if ( ! in_array( $field['required'][0], self::$metabox_condition ) ) {
					self::$metabox_condition[] = $field['required'][0];
				}
			}
		}
	}

	/**
	 * Register meta boxes
	 *
	 * @return void
	 */
	public static function register_meta_boxes() {
		foreach ( self::$metaboxes as $metabox_id => $args ) {
			add_meta_box(
				$metabox_id,
				$args['title'],
				empty( $args['callback'] ) ? [ __CLASS__, 'display_metaboxes' ] : $args['callback'],
				$args['post_type'],
				$args['context'],
				$args['priority'],
				$args['callback_args']
			);
		}
	}

	/**
	 * Display Metabox
	 *
	 * @param $post
	 * @param $metabox
	 *
	 * @return void
	 */
	public static function display_metaboxes( $post, $metabox ) {
		$fields = $metabox['args']['fields'];
		wp_nonce_field( self::$nonce_action, self::$nonce_field );
		MetaFields::display_fields( $fields, $post->ID, self::$metabox_condition );
	}

	/**
	 * Save metabox values
	 *
	 * @param $post_id
	 *
	 * @return mixed|void
	 */
	public static function save_metaboxes( $post_id ) {
		if ( isset( $_POST[ self::$nonce_field ] ) ) {
			if ( ! check_admin_referer( self::$nonce_action, self::$nonce_field ) ) {
				return $post_id;
			}
		}

		if ( wp_is_post_revision( $post_id ) ) {
			return $post_id;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return $post_id;
		}
		if ( ! current_user_can( 'edit_page', $post_id ) ) {
			return $post_id;
		}

		foreach ( self::$metabox_fields as $fields ) {
			foreach ( $fields as $field => $data ) {
				self::save_single_meta( $field, $data, $post_id );
			}
		}
	}


	/**
	 * Save single meta value
	 *
	 * @param $field
	 * @param $data
	 * @param $post_id
	 *
	 * @return void
	 */
	public static function save_single_meta( $field, $data, $post_id ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( isset( $_POST[ $field ] ) ) {
			$old = get_post_meta( $post_id, $field, true );
			$new = $_POST[ $field ]; // phpcs:ignore

			if ( $data['type'] == 'group' ) {
				$new = self::sanitize_group_field( $new, $data['value'] );
			} elseif ( $data['type'] == 'repeater' ) {
				$new = self::sanitize_repeater_field( $new, $data['value'] );
			} else {
				$new = self::sanitize_field( $new, $data['type'] );
			}

			// Update
			if ( $new != $old ) {
				if ( $new == [] ) { // assuming repeater field is empty array
					delete_post_meta( $post_id, $field );
				} else {
					update_post_meta( $post_id, $field, $new );
				}
			}
		} else {
			if ( $data['type'] == 'checkbox' || $data['type'] == 'multi_checkbox' || $data['type'] == 'multi_select' || $data['type'] == 'multi_select2' || $data['type'] == 'ajax_select' ) {
				delete_post_meta( $post_id, $field );
			}
		}
	}

	/**
	 * Sanitize Group meta fields
	 *
	 * @param $data
	 * @param $type
	 *
	 * @return mixed
	 */
	public static function sanitize_group_field( $data, $type ) {
		foreach ( $type as $key => $value ) {
			if ( isset( $data[ $key ] ) ) {
				$data[ $key ] = self::sanitize_field( $data[ $key ], $value['type'] );
			}
		}

		return $data;
	}

	/**
	 * Sanitize repeater fields
	 *
	 * @param $data
	 * @param $type
	 *
	 * @return array
	 */
	public static function sanitize_repeater_field( $data, $type ) {
		unset( $data['hidden'] ); // unset hidden
		foreach ( $data as $key => $value ) {
			foreach ( $value as $key2 => $value2 ) {
				$fieldtype             = $type[ $key2 ]['type'];
				$data[ $key ][ $key2 ] = self::sanitize_field( $data[ $key ][ $key2 ], $fieldtype );
			}
		}

		return array_values( $data );
	}

	/**
	 * Sanitize meta fields
	 *
	 * @param $data
	 * @param $type
	 *
	 * @return array|string|null
	 */
	public static function sanitize_field( $data, $type ) {
		switch ( $type ) {
			case 'multi_checkbox':
			case 'multi_select2':
			case 'multi_select':
			case 'ajax_select':
				$data = array_filter( $data, 'sanitize_text_field' );
				break;
			case 'textarea':
				$data = trim( $data );
				$data = listzen_html( $data, '', false );
				break;
			case 'textarea_html':
				$data = trim( $data );
				break;
			case 'color_picker':
				$data = sanitize_hex_color( $data );
				break;
			default:
				$data = sanitize_text_field( $data );
				break;
		}

		return $data;
	}
}