<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Listzen\Helpers\Fns;
use ListzenCore\Traits\SingletonTraits;

class WidgetOverwrite {
	use SingletonTraits;

	/**
	 * register default hooks and actions for WordPress
	 *
	 * @return
	 */
	public function __construct() {
		//Add input fields(priority 5, 3 parameters)
		add_action( 'in_widget_form', [ $this, 'listzen_in_widget_form' ], 5,
			3 );
		//Callback function for options update (priorität 5, 3 parameters)
		add_filter( 'widget_update_callback',
			[ $this, 'listzen_in_widget_form_update' ], 5, 3 );
		//add class names (default priority, one parameter)
		add_filter( 'dynamic_sidebar_params',
			[ $this, 'listzen_dynamic_sidebar_params' ] );
	}

	function listzen_in_widget_form( $t, $return, $instance ) {
		$instance = wp_parse_args( (array) $instance,
			[ 'widget_lg_cols' => '', 'widget_xl_cols' => '' ] );
		if ( ! isset( $instance['widget_xl_cols'] ) ) {
			$instance['widget_xl_cols'] = null;
		}
		if ( ! isset( $instance['widget_lg_cols'] ) ) {
			$instance['widget_lg_cols'] = null;
		}
		?>
        <div class="listzen-widget-custom-cols">
            <label for="<?php echo esc_attr( $t->get_field_id( 'widget_xl_cols' ) ); ?>"><?php echo esc_html__( 'Column:', 'listzen-core' ) ?></label>
            <div class="widget-cols" style="display:flex;gap:15px;margin-bottom:5px;">
				<?php $cols = [ 2, 3, 4, 5, 6, 7, 8 ]; ?>
                <select id="<?php echo esc_attr( $t->get_field_id( 'widget_xl_cols' ) ); ?>"
                        name="<?php echo esc_attr( $t->get_field_name( 'widget_xl_cols' ) ); ?>">
                    <option value=""><?php echo esc_html__( '-- Extra Large Columns --', 'listzen-core' ); ?></option>
					<?php foreach ( $cols as $col ) :
						$value = "col-xl-$col"; ?>
                        <option value="<?php echo esc_attr( $value ); ?>"
							<?php selected( $instance['widget_xl_cols'], $value ); ?>>
							<?php echo esc_html( $value ); ?>
                        </option>
					<?php endforeach; ?>
                </select>

                <select id="<?php echo esc_attr( $t->get_field_id( 'widget_lg_cols' ) ); ?>"
                        name="<?php echo esc_attr( $t->get_field_name( 'widget_lg_cols' ) ); ?>">
                    <option value=""><?php echo esc_html__( '-- Large Columns --', 'listzen-core' ); ?></option>
					<?php foreach ( $cols as $col ) :
						$value = "col-lg-$col"; ?>
                        <option value="<?php echo esc_attr( $value ); ?>"
							<?php selected( $instance['widget_lg_cols'], $value ); ?>>
							<?php echo esc_html( $value ); ?>
                        </option>
					<?php endforeach; ?>
                </select>
            </div>
            <small><?php echo esc_html__( 'Column option works only for the footer widgets.', 'listzen-core' ); ?></small>
        </div>
        <style>
            .listzen-widget-custom-cols {
                display: none;
            }

            [data-widget-area-id="<?php echo esc_attr(Fns::default_sidebar('footer')) ?>"] .listzen-widget-custom-cols {
                display: block !important;
            }
        </style>
		<?php
		$retrun = null;

		return [ $t, $return, $instance ];
	}

	function listzen_in_widget_form_update( $instance, $new_instance, $old_instance ) {
		$instance['widget_xl_cols'] = $new_instance['widget_xl_cols'] ?? '';
		$instance['widget_lg_cols'] = $new_instance['widget_lg_cols'] ?? '';

		return $instance;
	}

	function listzen_dynamic_sidebar_params( $params ) {
		global $wp_registered_widgets;
		$widget_id           = $params[0]['widget_id'];
		$widget_obj          = $wp_registered_widgets[ $widget_id ];
		$widget_opt
		                     = get_option( $widget_obj['callback'][0]->option_name );
		$widget_num          = $widget_obj['params'][0]['number'];
		$widget_before       = $params[0]['before_widget'];
		$widgets_custom_cols = '';

		if ( isset( $widget_opt[ $widget_num ]['widget_xl_cols'] )
		     || isset( $widget_opt[ $widget_num ]['widget_lg_cols'] )
		) {
			if ( ! empty( $widget_opt[ $widget_num ]['widget_xl_cols'] ) ) {
				$widgets_custom_cols .= $widget_opt[ $widget_num ]['widget_xl_cols'];
			} else {
				$widgets_custom_cols .= '';
			}

			if ( ! empty( $widget_opt[ $widget_num ]['widget_lg_cols'] ) ) {
				$widget_before       = str_replace( 'col-lg-', 'collg',
					$widget_before );
				$widgets_custom_cols .= ' '
				                        . $widget_opt[ $widget_num ]['widget_lg_cols'];
			} else {
				$widgets_custom_cols .= '';
			}
			$params[0]['before_widget'] = preg_replace( '/class="/',
				'class="' . $widgets_custom_cols . ' ', $widget_before, 1 );
		}

		return $params;
	}
}
