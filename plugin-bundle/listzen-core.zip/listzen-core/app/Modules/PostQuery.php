<?php

namespace ListzenCore\Modules;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use ListzenCore\Helper\Fns;
use WP_Query;

/**
 * Handles building and executing custom post queries.
 */
class PostQuery {

	/**
	 * Post Data store.
	 *
	 * @var self::$data
	 */
	private static $data;

	/**
	 * Make WP_Query
	 *
	 * @param array $data Data used to build the query.
	 *
	 * @return \WP_Query
	 */
	public static function query( array $data ): WP_Query {
		self::$data = $data;

		return new WP_Query( self::prepare_query_args() );
	}

	/**
	 * Prepare Query Arguments.
	 *
	 * @return array
	 */
	public static function prepare_query_args(): array {
		$post_type = self::resolve_post_type();
		$args      = [
			'post_type'      => $post_type,
			'post_status'    => 'publish',
			'posts_per_page' => (int) self::$data['post_limit'] ?? 6,
		];

		self::add_tax_query( $args );
		self::add_common_filters( $args );
		self::add_date_range( $args );

		return $args;
	}

	/**
	 * Resolved Post Type
	 *
	 * @return array|string
	 */
	protected static function resolve_post_type(): array|string {

		$post_type = ! empty( self::$data['post_type'] ) ? esc_html( self::$data['post_type'] ) : 'post';

		return Fns::post_type_permission( $post_type );
	}

	/**
	 * Add taxonomy Query
	 *
	 * @param array $args main query args.
	 *
	 * @return void
	 */
	protected static function add_tax_query( array &$args ): void {
		$tax_query = [];

		if ( ! empty( self::$data['category'] ) ) {
			$tax_query[] = [
				'taxonomy' => 'category',
				'field'    => 'id',
				'terms'    => self::$data['category'],
			];
		}

		if ( ! empty( self::$data['post_tag'] ) ) {
			$tax_query[] = [
				'taxonomy' => 'post_tag',
				'field'    => 'id',
				'terms'    => self::$data['post_tag'],
			];
		}

		if ( $tax_query ) {
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
			$args['tax_query'] = [
				'relation' => self::$data['tax_relation'] ?? 'OR',
				...$tax_query,
			];
		}

		if ( ! empty( self::$data['tags'] ) ) {
			$args['tag_slug__in'] = self::$data['tags'];
		}
	}

	/**
	 * Add common filters to query
	 *
	 * @param array $args query args modify.
	 *
	 * @return void
	 */
	protected static function add_common_filters( array &$args ): void {
		$common_filter_items = [
			'orderby' => 'orderby',
			'order'   => 'order',
			'post_id' => 'post__in',
			'exclude' => 'post__not_in', // phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_exclude
			'offset'  => 'offset',
		];
		foreach ( $common_filter_items as $key => $arg_key ) {
			if ( ! empty( self::$data[ $key ] ) ) {
				$args[ $arg_key ] = self::$data[ $key ];
			}
		}

		if ( 'on' === self::$data['ignore_sticky_posts'] ) {
			$args['ignore_sticky_posts'] = 1;
		}

		if ( ! empty( self::$data['author'] ) ) {
			$args['author__in'] = array_map( 'intval', self::$data['author'] );
		}
	}

	/**
	 * Add date range query.
	 *
	 * @param array $args main query args modify.
	 *
	 * @return void
	 */
	protected static function add_date_range( array &$args ): void {
		if ( empty( self::$data['date_range'] ) || ! str_contains( self::$data['date_range'], 'to' ) ) {
			return;
		}

		[ $after, $before ] = array_map( 'trim', explode( 'to', esc_html( self::$data['date_range'] ) ) );

		$args['date_query'] = [
			[
				'after'     => $after,
				'before'    => $before,
				'inclusive' => true,
			],
		];
	}

	/**
	 * Get terms id.
	 *
	 * @param int $post_id used post id.
	 * @param string $taxonomy used taxonomy id.
	 *
	 * @return array
	 */
	public static function get_terms_id( int $post_id, string $taxonomy ): array {
		$terms = get_the_terms( $post_id, $taxonomy );

		return is_array( $terms ) ? wp_list_pluck( $terms, 'term_id' ) : [];
	}

}
