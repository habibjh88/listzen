<?php
/**
 * This class is basically customizing WordPress “posts” (post post type)
 * so they behave more like pages (hierarchical, parent/child structure, custom permalinks).
 */
namespace ListzenCore\Modules;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use ListzenCore\Traits\SingletonTraits;

/**
 * Hooks Class
 */
class PostAttribute {

	use SingletonTraits;

	/**
	 * register default hooks and actions for WordPress
	 */
	public function __construct() {
		add_action( 'init', [ $this, 'add_post_attributes' ], 500 );
		add_action( 'registered_post_type', [ $this, 'enable_hierarchy_fields' ], 123, 2 );
		add_filter( 'post_type_labels_post', [ $this, 'enable_hierarchy_fields_for_js' ], 11, 2 );
		add_filter( 'pre_post_link', [ $this, 'change_permalinks' ], 8, 3 );
		add_filter( 'pre_get_posts', [ $this, 'method__query' ], 888 );
		add_action( 'registered_post_type', [ $this, 'hierarchy_for_custom_post' ], 90, 2 );
	}

	/**
	 * @param $post_type
	 * @param $post_type_object
	 */
	public function hierarchy_for_custom_post( $post_type, $post_type_object ) {
		if ( 'post' == $post_type ) {
			$post_type_object->hierarchical = true;
		}
	}

	/**
	 * @param      $permalink
	 * @param bool $post
	 * @param bool $leavename
	 *
	 * @return string|string[]
	 */
	public function change_permalinks( $permalink, $post = false, $leavename = false ) {
		if ( $post->post_type == "post" ) {
			// return if %postname% tag is not present in the url:
			if ( false === strpos( $permalink, '%postname%' ) ) {
				return $permalink;
			}
			$path      = str_replace( '%postname%', $this->get_parent_slugs( $post ) . '/' . '%postname%', $permalink );
			$permalink = str_replace( '//', '/', $path );
		}

		return $permalink;
	}

	/**
	 * @param $post_type
	 * @param $post_type_object
	 */
	public function enable_hierarchy_fields( $post_type, $post_type_object ) {
		if ( $post_type == 'post' ) {
			$post_type_object->hierarchical = true;
		}
	}

	/**
	 * @param $labels
	 *
	 * @return mixed
	 */
	public function enable_hierarchy_fields_for_js( $labels ) {
		$labels->parent_item_colon = 'Parent Post';

		return $labels;
	}

	/**
	 * @param $query
	 *
	 * @return mixed
	 */
	public function method__query( $query ) {
		$q = $query;

		if ( $q->is_main_query() && ! is_admin() ) {
			$possible_post_path = trailingslashit( preg_replace_callback( '/(.*?)\/((page|feed|rdf|rss|rss2|atom)\/.*)/i', function( $matches ) {
				return $matches[1];
			}, $this->path_after_blog_s() ) );
			if ( substr_count( $possible_post_path, "/" ) >= 2 ) {
				$post = get_page_by_path( $possible_post_path, OBJECT, 'post' );
				if ( $post ) {
					$q->parse_query( [ 'post_type' => [ 'post' ] ] );
					$q->is_home           = false;
					$q->is_single         = true;
					$q->is_singular       = true;
					$q->queried_object_id = $post->ID;
					$q->set( 'page_id', $post->ID );

					return $q;
				}
			}
		}

		return $q;
	}

	public function get_parent_slugs( $post ) {
		$final_SLUGG = '';
		if ( ! empty( $post->post_parent ) ) {
			$parent_post = get_post( $post->post_parent );
			while ( ! empty( $parent_post ) ) {
				$final_SLUGG = $parent_post->post_name . '/' . $final_SLUGG;
				if ( ! empty( $parent_post->post_parent ) ) {
					$parent_post = get_post( $parent_post->post_parent );
				} else {
					break;
				}
			}
			$final_SLUGG = empty( $final_SLUGG ) ?: '/' . $final_SLUGG;
		}

		return $final_SLUGG;
	}

	/**
	 * @return false|string|string[]
	 */
	public function path_after_blog_s() {
		$prf  = $this->get_blog_prefix_s();
		// phpcs:disable
		$path = ! empty( $_SERVER["REQUEST_URI"] ) ? substr( $_SERVER["REQUEST_URI"], strlen( home_url( '/', 'relative' ) ) ) : '';

		return ( ( $prf == "/blog" ) ? str_replace( '/blog/', '', '/' . $path ) : $path );
		// phpcs:enable
	}

	/**
	 * @return string
	 */
	private function get_blog_prefix_s() {
		$blog_prefix = '';
		if ( is_multisite() && ! is_subdomain_install() && is_main_site() && 0 === strpos( get_option( 'permalink_structure' ), '/blog/' ) ) {
			$blog_prefix = '/blog';
		}

		return $blog_prefix;
	}

	/**
	 * Add page attributes to post
	 */
	function add_post_attributes() {
		add_post_type_support( 'post', 'page-attributes' );
	}

}
