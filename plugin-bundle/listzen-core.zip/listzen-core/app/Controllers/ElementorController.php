<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Controllers;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use Elementor\Plugin;
use ListzenCore\Helper\Fns;
use ListzenCore\Traits\SingletonTraits;
use ListzenCore\Elementor\Controls\Select2AjaxControl;
use ListzenCore\Elementor\Custom\ElementorCore;
use ListzenCore\Ajax\ElementorAjax;
use ListzenCore\Elementor\Addons\Marquee;
use ListzenCore\Elementor\Addons\SiteLogo;
use ListzenCore\Elementor\Addons\SiteMenu;
use ListzenCore\Elementor\Addons\MenuIconGroup;
use ListzenCore\Elementor\Addons\VideoIcon;
use ListzenCore\Elementor\Addons\Testimonial;
use ListzenCore\Elementor\Addons\PostGrid;
use ListzenCore\Elementor\Addons\PageList;
use ListzenCore\Elementor\Addons\SwiperBtn;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ElementorController Class
 */
class ElementorController {
	use SingletonTraits;

	public function __construct() {
		new ElementorAjax();
		ElementorCore::instance();
		add_action( 'elementor/widgets/register', [ $this, 'register_widget' ] );
		add_action( 'elementor/elements/categories_registered', [ $this, 'widget_category' ], 999 );
		add_action( 'elementor/editor/before_enqueue_scripts', [ $this, 'editor_scripts' ] );
		add_action( 'elementor/editor/after_enqueue_styles', [ $this, 'editor_style' ] );
		add_action( 'elementor/controls/register', [ $this, 'register_new_control' ] );
	}


	/**
	 * Register Elementor Widget.
	 * Just put the widget class reference here
	 * @return void
	 */
	public function register_widget() {

		$widgets = [
			Marquee::class,
			VideoIcon::class,
			SiteLogo::class,
			SiteMenu::class,
			MenuIconGroup::class,
			Testimonial::class,
			PostGrid::class,
			PageList::class,
			SwiperBtn::class,
		];
		foreach ( $widgets as $class ) {
			Plugin::instance()->widgets_manager->register( new $class );
		}
	}

	/**
	 * Editor JS.
	 *
	 * @return void
	 */
	public function editor_scripts() {
		$version = ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ? time() : LISTZEN_CORE;
		add_action( 'action', [ $this, 'enqueue_assets' ] );
		wp_enqueue_script(
			'listzen-editor-script',
			Fns::get_assets_url( 'js/el-editor.js' ),
			[
				'jquery',
				'elementor-editor',
				'jquery-elementor-select2',
			],
			$version,
			true
		);
	}


	/**
	 * Register Elementor category
	 *
	 * @param $elements_manager
	 *
	 * @return void
	 */
	public function widget_category( $elements_manager ) {
		$id                = LISTZEN_CORE_PREFIX . '-widgets';
		$categories[ $id ] = [
			'title' => __( 'RadiusTheme Elements', 'listzen-core' ),
			'icon'  => 'fa fa-plug',
		];

		$get_all_categories = $elements_manager->get_categories();
		$categories         = array_merge( $categories, $get_all_categories );
		$set_categories     = function ( $categories ) {
			$this->categories = $categories;
		};

		$set_categories->call( $elements_manager, $categories );
	}

	public function editor_style() {
		$img = LISTZEN_CORE_BASE_URL . 'assets/images/icon.svg';
		wp_enqueue_style( 'flaticon' );
		wp_add_inline_style( 'elementor-editor', '.elementor-element .icon .rdtheme-el-custom{content: url(' . $img . ');width: 28px;}' );
		wp_add_inline_style( 'elementor-editor', '.elementor-panel .select2-container {min-width: 100px !important; min-height: 30px !important;}' );
		wp_add_inline_style( 'elementor-editor', '.elementor-panel .elementor-control-type-heading .elementor-control-title {color: #93013d !important}' );
	}

	/**
	 * Register New Controls
	 *
	 * @param $controls_manager
	 *
	 * @return void
	 */
	public static function register_new_control( $controls_manager ) {
		$controls_manager->register( new Select2AjaxControl() );
	}
}