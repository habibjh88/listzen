<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Controllers;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
use ListzenCore\Traits\SingletonTraits;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CustomCSSMeta {
	use SingletonTraits;

	const META_KEY = '_listzen_custom_css';
	const NONCE = 'listzen_custom_css_nonce';
	const FIELD_ID = 'listzen_custom_css_field';

	public function __construct() {
		add_action( 'init', [ $this, 'register_meta' ] );
		add_action( 'add_meta_boxes', [ $this, 'add_metabox' ] );
		add_action( 'save_post', [ $this, 'save_meta' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'admin_assets' ] );
		add_action( 'wp_head', [ $this, 'print_frontend_css' ], 100 );
		add_filter( '_wp_post_revision_fields', [ $this, 'add_revision_field' ] );
		add_action( 'wp_restore_post_revision', [ $this, 'restore_revision' ], 10, 2 );
	}

	/**
	 * Filterable post types. By default: post, page.
	 */
	public static function supported_post_types() {
		$types = [ 'post', 'page', 'rtcl_listing' ];

		/**
		 * Filter post types that get the Custom CSS metabox.
		 *
		 * @param array $types
		 */
		return apply_filters( 'listzen_custom_css_post_types', $types );
	}

	public function register_meta(): void {
		foreach ( self::supported_post_types() as $type ) {
			register_post_meta(
				$type,
				self::META_KEY,
				[
					'type'              => 'string',
					'description'       => __( 'Per-entry Custom CSS', 'listzen-core' ),
					'single'            => true,
					'default'           => '',
					'show_in_rest'      => true, // shows in REST; handy if you later build a block/React UI
					'auth_callback'     => function () use ( $type ) {
						return current_user_can( 'edit_' . $type );
					},
					'sanitize_callback' => [ $this, 'sanitize_css' ],
				]
			);
		}
	}

	public function add_metabox(): void {
		foreach ( self::supported_post_types() as $type ) {
			add_meta_box(
				'listzen_custom_css_metabox',
				__( 'Custom CSS', 'listzen-core' ),
				[ $this, 'render_metabox' ],
				$type,
				'normal',
				'default'
			);
		}
	}

	public function render_metabox( \WP_Post $post ): void {
		wp_nonce_field( self::NONCE, self::NONCE );
		$value = get_post_meta( $post->ID, self::META_KEY, true );
		?>
        <p style="margin:0 0 8px;">
            <em><?php esc_html_e( 'Add CSS that should apply only to this entry. No <style> tags needed.', 'listzen-core' ); ?></em>
        </p>
        <textarea
                id="<?php echo esc_attr( self::FIELD_ID ); ?>"
                name="<?php echo esc_attr( self::FIELD_ID ); ?>"
                rows="14"
                style="width:100%;font-size:0.9em; font-family: Menlo, Monaco, Consolas, monospace;"
                placeholder="<?php esc_attr_e( '/* Example */ .entry-title { font-size: 40px; }', 'listzen-core' ); ?>"
        ><?php echo esc_textarea( $value ); ?></textarea>
        <p style="margin-top:8px;opacity:.8">
			<?php esc_html_e( 'Tip: Keep it scoped (e.g., use body.postid-XX or unique section classes) to avoid conflicts.', 'listzen-core' ); ?>
        </p>
		<?php
	}

	public function save_meta( int $post_id ): void {
		// Autosave, revisions, bulk edits, etc. bail.
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		// Must have nonce.
		if ( empty( $_POST[ self::NONCE ] ) ) {
			return;
		}

        // Sanitize the nonce value
		$nonce = sanitize_text_field( wp_unslash( $_POST[ self::NONCE ] ) );

		if ( ! wp_verify_nonce( $nonce, self::NONCE ) ) {
			return;
		}

		$post_type = get_post_type( $post_id );
		if ( ! $post_type || ! in_array( $post_type, self::supported_post_types(), true ) ) {
			return;
		}

		// Permission check.
		if ( ! current_user_can( 'edit_' . $post_type, $post_id ) ) {
			return;
		}

		// Save value.
		if ( isset( $_POST[ self::FIELD_ID ] ) ) {
			$raw = wp_unslash( (string) $_POST[ self::FIELD_ID ] ); //phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$css = $this->sanitize_css( $raw );
			// Limit to avoid absurdly huge payloads (ThemeForest-friendly).
			$css = mb_substr( $css, 0, 100000 );

			update_post_meta( $post_id, self::META_KEY, $css );
		}
	}

	/**
	 * Keep CSS safe for inline output:
	 * - Strip all HTML tags (prevents <script> / <style> nesting)
	 * - Normalize control chars/newlines
	 * - Trim BOM and null bytes
	 */
	public function sanitize_css( string $css ): string {
		// Remove any HTML tags but keep CSS characters.
		$css = wp_kses( $css, [] );

		// Normalize line endings and strip null bytes.
		$css = str_replace( [ "\r\n", "\r" ], "\n", $css );
		$css = str_replace( "\0", '', $css );

		// Trim whitespace.
		$css = trim( $css );

		return $css;
	}

	public function admin_assets( $hook ): void {
		$screen = get_current_screen();
		if ( ! $screen || ! in_array( $screen->post_type, self::supported_post_types(), true ) ) {
			return;
		}

		// Load CodeMirror assets.
		wp_enqueue_script( 'code-editor' );
		wp_enqueue_style( 'code-editor' );

		$settings = wp_enqueue_code_editor( [
			'type'       => 'text/css',
			'codemirror' => [
				'lineNumbers'     => true,
				'styleActiveLine' => true,
				'indentUnit'      => 2,
				'tabSize'         => 2,
			],
		] );

		if ( false === $settings ) {
			return;
		}

		// Initialize editor + ensure it refreshes when needed
		wp_add_inline_script(
			'code-editor',
			sprintf(
				'jQuery(function($){
                var el = $("#%1$s");
                if(el.length && window.wp && wp.codeEditor){
                    var editor = wp.codeEditor.initialize(el[0], %2$s);
                    if(editor && editor.codemirror){
                        function refreshEditor(){ try{ editor.codemirror.refresh(); }catch(e){} }
                        // Force refresh after init (helps when metabox is collapsed)
                        setTimeout(refreshEditor, 300);
                        // Refresh on common events
                        $(window).on("resize", refreshEditor);
                        $(document).on("postbox-toggled", refreshEditor);
                        // Keep textarea synced
                        editor.codemirror.on("change", function(cm){ cm.save(); });
                    }
                }
            });',
				esc_js( self::FIELD_ID ),
				wp_json_encode( $settings )
			)
		);

		// CSS: make brackets red (scoped to your textarea's CodeMirror instance)
		$cm_selector = '#' . self::FIELD_ID . ' + .CodeMirror';
		$css         = "
    /* Bracket color (curly, square, paren) */
    {$cm_selector} .cm-bracket,
    {$cm_selector} .cm-brace,
    {$cm_selector} .cm-paren,
    {$cm_selector} .cm-angle {
        color: #d9534f !important; /* change hex to any red you prefer */
    }

    /* Matching / non-matching bracket highlights */
    {$cm_selector} .CodeMirror-matchingbracket {
        color: #d9534f !important;
        background: rgba(217,83,79,0.06) !important;
        font-weight: 600 !important;
    }
    {$cm_selector} .CodeMirror-nonmatchingbracket {
        color: #b52a23 !important;
        background: rgba(181,42,35,0.06) !important;
    }

    /* Slight left padding so numbers/line gutter don't overlap */
    {$cm_selector} { padding-left: 6px; }
    ";
		wp_add_inline_style( 'code-editor', $css );
	}

	public function print_frontend_css(): void {
		if ( ! is_singular( self::supported_post_types() ) ) {
			return;
		}

		$post_id = get_queried_object_id();
		if ( ! $post_id ) {
			return;
		}

		$css = get_post_meta( $post_id, self::META_KEY, true );
		if ( ! $css ) {
			return;
		}

		// Scope hint: Add a unique identifier to help debugging.
		$handle_id = 'listzen-custom-css-' . (int) $post_id;

		// Output safely. We already stripped tags; do not escape special chars or it will break CSS.
		echo "\n<!-- ".esc_html( $handle_id )." -->\n<style id=\"" . esc_attr( $handle_id ) . "\">\n" . $css . "\n</style>\n"; //phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/* ========== Revisions Support ========== */

	public function add_revision_field( array $fields ): array {
		$fields[ self::META_KEY ] = __( 'Custom CSS', 'listzen-core' );

		return $fields;
	}

	public function restore_revision( $post_id, $revision_id ): void {
		$revision = get_post( $revision_id );
		if ( ! $revision ) {
			return;
		}
		$value = get_metadata( 'post', $revision->ID, self::META_KEY, true );
		if ( null !== $value ) {
			update_post_meta( $post_id, self::META_KEY, (string) $value );
		}
	}
}
