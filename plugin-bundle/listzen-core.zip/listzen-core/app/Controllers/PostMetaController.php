<?php

namespace ListzenCore\Controllers;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use Listzen\Helpers\Fns;
use ListzenCore\Framework\Postmeta\PostMeta;
use ListzenCore\Traits\SingletonTraits;
use ListzenCore\Helper\FnsBuilder;

class PostMetaController {
	use SingletonTraits;

	public function __construct() {
		add_action( 'init', [ $this, 'add_meta_box' ] );
	}

	/**
	 * Add all metabox
	 * @return void
	 */
	function add_meta_box() {

		PostMeta::add_meta_box(
			"listzen_page_settings",
			__( 'Layout Settings', 'listzen-core' ),
			[ 'page', 'post' ],
			'',
			'',
			'high',
			[
				'fields' => [
					"listzen_layout_meta_data" => [
						'label' => __( 'Layouts', 'listzen-core' ),
						'type'  => 'group',
						'value' => $this->get_post_page_meta_args(),
					],
				],
			]
		);


		//header footer build
		PostMeta::add_meta_box(
			"listzen_el_builder_settings",
			__( 'Header - Footer Builder Settings', 'listzen-core' ),
			[ 'elementor-listzen' ],
			'',
			'',
			'high',
			[
				'fields' => $this->get_el_builder_meta_args(),
			]
		);

		//header footer build
		PostMeta::add_meta_box(
			"listzen_el_builder_for_page_settings",
			__( 'Header / Footer Builder', 'listzen-core' ),
			[ 'page', 'post', 'rtcl_listing' ],
			'',
			'side',
			'',
			[
				'fields' => $this->header_footer_builder_for_page(),
			]
		);
	}


	function get_el_builder_meta_args() {
		return apply_filters( 'listzen_layout_meta_field', [
			'template_type' => [
				'label'   => __( 'Template Type', 'listzen-core' ),
				'type'    => 'select',
				'options' => [
					'default' => __( 'Choose Options', 'listzen-core' ),
					'header'  => __( 'Header', 'listzen-core' ),
					'footer'  => __( 'Footer', 'listzen-core' ),
				],
				'default' => 'default',
			],

			'show_on' => [
				'label'   => __( 'Show On', 'listzen-core' ),
				'type'    => 'multi_select2',
				'options' => FnsBuilder::get_builder_type(),
				'default' => [],
				'class'   => 'listzen-header-footer-select'
			],

			'choose_post' => [
				'label'       => __( 'Choose posts or pages', 'listzen-core' ),
				'type'        => 'ajax_select',
				'data_source' => 'post',
				'default'     => [],
			],

		] );
	}

	function get_post_page_meta_args() {
		$sidebars = [ 'default' => __( 'Default from customizer', 'listzen-core' ) ] + Fns::sidebar_lists();

		return apply_filters( 'listzen_layout_meta_field', [
			'layout' => [
				'label'   => __( 'Layout', 'listzen-core' ),
				'type'    => 'select',
				'options' => [
					'default'       => __( 'Default from customizer', 'listzen-core' ),
					'full-width'    => __( 'Full Width', 'listzen-core' ),
					'left-sidebar'  => __( 'Left Sidebar', 'listzen-core' ),
					'right-sidebar' => __( 'Right Sidebar', 'listzen-core' ),
				],
				'default' => 'default',
			],

			'header_style'     => [
				'label'   => __( 'Header Style', 'listzen-core' ),
				'type'    => 'select',
				'options' => [
					'default' => __( 'Default from customizer', 'listzen-core' ),
					'1'       => __( 'Layout 1', 'listzen-core' ),
					'2'       => __( 'Layout 2', 'listzen-core' ),
					'3'       => __( 'Layout 3', 'listzen-core' ),
					'4'       => __( 'Layout 4', 'listzen-core' ),
					'5'       => __( 'Layout 5', 'listzen-core' ),
					'6'       => __( 'Layout 6', 'listzen-core' ),
				],
				'default' => 'default',
			],
			'sidebar'          => [
				'label'   => __( 'Custom Sidebar', 'listzen-core' ),
				'type'    => 'select',
				'options' => $sidebars,
				'default' => 'default',
			],
			'top_bar'          => [
				'label'   => __( 'Top Bar Visibility', 'listzen-core' ),
				'type'    => 'select',
				'options' => [
					'default' => __( 'Default from customizer', 'listzen-core' ),
					'on'      => __( 'ON', 'listzen-core' ),
					'off'     => __( 'OFF', 'listzen-core' ),
				],
				'default' => 'default',
			],
			'topbar_style'     => [
				'label'   => __( 'Top Bar Style', 'listzen-core' ),
				'type'    => 'select',
				'options' => [
					'default' => __( 'Default from customizer', 'listzen-core' ),
					'1'       => __( 'Layout 1', 'listzen-core' ),
					'2'       => __( 'Layout 2', 'listzen-core' ),
				],
				'default' => 'default',
			],
			'nav_drawer_style' => [
				'label'   => __( 'Nav Drawer Style', 'listzen-core' ),
				'type'    => 'select',
				'options' => [
					'default' => __( 'Default from customizer', 'listzen-core' ),
					'1'       => __( 'Layout 1', 'listzen-core' ),
					'2'       => __( 'Layout 2', 'listzen-core' ),
					'3'       => __( 'Layout 3', 'listzen-core' ),
				],
				'default' => 'default',
			],
			'header_width'     => [
				'label'   => __( 'Header Width', 'listzen-core' ),
				'type'    => 'select',
				'options' => [
					'default'  => __( 'Default from customizer', 'listzen-core' ),
					'box'      => __( 'Box Width', 'listzen-core' ),
					'full'     => __( 'Full Width', 'listzen-core' ),
					'max-2110' => __( 'Max width (2110px)', 'listzen-core' ),
					'max-1920' => __( 'Max width (1920px)', 'listzen-core' ),
				],
				'default' => 'default',
			],


			'menu_alignment' => [
				'label'   => __( 'Menu Alignment', 'listzen-core' ),
				'type'    => 'select',
				'options' => [
					'default'                => __( 'Default from customizer', 'listzen-core' ),
					'justify-content-start'  => __( 'Left Alignment', 'listzen-core' ),
					'justify-content-center' => __( 'Center Alignment', 'listzen-core' ),
					'justify-content-end'    => __( 'Right Alignment', 'listzen-core' ),
				],
				'default' => 'default',
			],

			'tr_header' => [
				'label'   => __( 'Transparent Header', 'listzen-core' ),
				'type'    => 'select',
				'options' => [
					'default' => __( 'Default from customizer', 'listzen-core' ),
					'on'      => __( 'ON', 'listzen-core' ),
					'off'     => __( 'OFF', 'listzen-core' ),
				],
				'default' => 'default',
			],

			'tr_header_color' => [
				'label'   => __( 'Transparent color', 'listzen-core' ),
				'type'    => 'select',
				'options' => [
					'default'         => __( 'Default from customizer', 'listzen-core' ),
					'tr-header-light' => __( 'Light Color', 'listzen-core' ),
					'tr-header-dark'  => __( 'Dark Color', 'listzen-core' ),
				],
				'default' => 'default',
			],

			'banner'           => [
				'label'   => __( 'Banner Visibility', 'listzen-core' ),
				'type'    => 'select',
				'options' => [
					'default' => __( 'Default from customizer', 'listzen-core' ),
					'on'      => __( 'ON', 'listzen-core' ),
					'off'     => __( 'OFF', 'listzen-core' ),
				],
				'default' => 'default',
			],
			'banner_style'     => [
				'label'   => __( 'Banner Style', 'listzen-core' ),
				'type'    => 'select',
				'options' => [
					'default' => __( 'Default from customizer', 'listzen-core' ),
					'1'       => __( 'Layout 1', 'listzen-core' ),
					'2'       => __( 'Layout 2', 'listzen-core' ),
				],
				'default' => 'default',
			],
			'breadcrumb_title' => [
				'label'   => __( 'Banner Title', 'listzen-core' ),
				'type'    => 'select',
				'options' => [
					'default' => __( 'Default from customizer', 'listzen-core' ),
					'on'      => __( 'ON', 'listzen-core' ),
					'off'     => __( 'OFF', 'listzen-core' ),
				],
				'default' => 'default',
			],
			'breadcrumb'       => [
				'label'   => __( 'Banner Breadcrumb', 'listzen-core' ),
				'type'    => 'select',
				'options' => [
					'default' => __( 'Default from customizer', 'listzen-core' ),
					'on'      => __( 'ON', 'listzen-core' ),
					'off'     => __( 'OFF', 'listzen-core' ),
				],
				'default' => 'default',
			],
			'banner_height'    => [
				'label'   => __( 'Banner Height (px)', 'listzen-core' ),
				'type'    => 'number',
				'default' => 'default',
			],

			'banner_image'   => [
				'type'  => 'image',
				'label' => __( 'Banner Background Image', 'listzen-core' ),
			],
			'banner_color'   => [
				'type'  => 'color_picker',
				'label' => __( 'Banner Background Color', 'listzen-core' ),
			],
			'footer_style'   => [
				'label'   => __( 'Footer Layout', 'listzen-core' ),
				'type'    => 'select',
				'options' => [
					'default' => __( 'Default from customizer', 'listzen-core' ),
					'1'       => __( 'Layout 1', 'listzen-core' ),
					'2'       => __( 'Layout 2', 'listzen-core' ),
					'3'       => __( 'Layout 3', 'listzen-core' ),
					'4'       => __( 'Layout 4', 'listzen-core' ),
					'5'       => __( 'Layout 5', 'listzen-core' ),
				],
				'default' => 'default',
			],
			'footer_schema'  => [
				'label'   => __( 'Footer Schema', 'listzen-core' ),
				'type'    => 'select',
				'options' => [
					'default'      => __( 'Default from customizer', 'listzen-core' ),
					'footer-light' => __( 'Light Footer', 'listzen-core' ),
					'footer-dark'  => __( 'Dark Footer', 'listzen-core' ),
				],
				'default' => 'default',
			],
			'padding_top'    => [
				'label' => __( 'Padding Top (Page Content)', 'listzen-core' ),
				'type'  => 'number',
			],
			'padding_bottom' => [
				'label' => __( 'Padding Bottom (Page Content)', 'listzen-core' ),
				'type'  => 'number',
			],
			'page_bg_image'  => [
				'type'  => 'image',
				'label' => __( 'Background Image', 'listzen-core' ),
			],
			'page_bg_color'  => [
				'type'  => 'color_picker',
				'label' => __( 'Background Color', 'listzen-core' ),
			],
		] );
	}

	function header_footer_builder_for_page() {
		return apply_filters( 'listzen_layout_meta_field', [
				'listzen_builder_header' => [
					'label'   => __( 'Choose Builder Header', 'listzen-core' ),
					'type'    => 'select',
					'options' => FnsBuilder::get_template_type_array( 'header' )
				],
				'listzen_builder_footer' => [
					'label'   => __( 'Choose Builder Footer', 'listzen-core' ),
					'type'    => 'select',
					'options' => FnsBuilder::get_template_type_array( 'footer' )
				],
			]
		);

	}


}

