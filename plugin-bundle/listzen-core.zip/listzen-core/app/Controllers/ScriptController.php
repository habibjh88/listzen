<?php

namespace ListzenCore\Controllers;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use ListzenCore\Traits\SingletonTraits;

/**
 * Enqueue.
 */
class ScriptController {
	use SingletonTraits;

	/**
	 * register default hooks and actions for WordPress
	 * @return
	 */
	public function __construct() {
		add_action( 'admin_enqueue_scripts', [ $this, 'load_meta_scripts' ] );
	}

	public static function get_version() {
		return WP_DEBUG ? time() : LISTZEN_CORE;
	}

	/**
	 * Load necessary CSS and JS
	 *
	 * @return void
	 */
	public function load_meta_scripts() {
		wp_enqueue_script('jquery-ui-core');
		wp_enqueue_style( 'jquery-ui-css', LISTZEN_CORE_BASE_URL . 'assets/lib/jquery-ui/jquery-ui.css', [], self::get_version() );
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_style( 'listzen-meta-style', LISTZEN_CORE_BASE_URL . 'assets/css/admin.css', [], self::get_version() ); // only datepicker

		//	wp_enqueue_script( 'jquery-ui-datepicker' );
		//	wp_enqueue_script( 'jquery-timepicker', LISTZEN_CORE_BASE_URL . 'assets/js/lib/jquery.timepicker.js', [ 'jquery' ], self::get_version() );
		wp_enqueue_script( 'select2', LISTZEN_CORE_BASE_URL . 'assets/lib/select2/select2.min.js', [ 'jquery' ], self::get_version(), true );
		wp_enqueue_style( 'select2', LISTZEN_CORE_BASE_URL . 'assets/lib/select2/select2.min.css', [], self::get_version() );

		wp_enqueue_script( 'wp-color-picker' );
		wp_enqueue_media();
		wp_enqueue_script(
			'listzen-admin-script',
			LISTZEN_CORE_BASE_URL . 'assets/js/admin.js',
			[ 'jquery', 'select2', 'jquery-ui-core', 'wp-color-picker', 'jquery-ui-datepicker' ],
			self::get_version(),
			true
		);
		wp_localize_script(
			'listzen-admin-script',
			'listzenObj',
			[
				'nonce'    => wp_create_nonce( 'wp_rest' ),
				'ajaxurl'  => admin_url( 'admin-ajax.php' ),
				'rest_url' => esc_url_raw( rest_url() ),
			]
		);
	}


}
