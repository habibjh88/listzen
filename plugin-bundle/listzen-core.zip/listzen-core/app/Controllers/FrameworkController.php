<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Controllers;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use ListzenCore\Framework\Postmeta\PostMeta;
use ListzenCore\Framework\Taxmeta\TaxMeta;
use ListzenCore\Traits\SingletonTraits;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

class FrameworkController {
	use SingletonTraits;

	public function __construct() {
		PostMeta::instance();
		TaxMeta::instance();
	}

}