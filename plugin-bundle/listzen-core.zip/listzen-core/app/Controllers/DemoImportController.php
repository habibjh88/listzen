<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Controllers;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use ListzenCore\Traits\SingletonTraits;
use ListzenCore\ImportExport\Exporter;
use ListzenCore\ImportExport\OneClickDemoImport;

/**
 * DemoImportController class
 */
class DemoImportController {
	/**
	 * Single tone
	 */
	use SingletonTraits;

	/**
	 * Class Constructor
	 */
	public function __construct() {
		if ( defined( 'RT_EXPORT_ENABLE' ) ) {
			Exporter::instance();
		}
		OneClickDemoImport::instance();
	}
}