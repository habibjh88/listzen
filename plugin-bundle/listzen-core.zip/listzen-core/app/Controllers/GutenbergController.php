<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Controllers;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use ListzenCore\Traits\SingletonTraits;
use ListzenCore\Blocks\PostGrid;
use ListzenCore\Blocks\SectionTitle;


if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ElementorController Class
 */
class GutenbergController {
	use SingletonTraits;

	public function __construct() {
		PostGrid::instance();
		SectionTitle::instance();

		add_action( 'enqueue_block_editor_assets', [ $this, 'listzen_enqueue_block_assets' ] );
	}

	public function listzen_enqueue_block_assets() {

		wp_enqueue_script(
			'listzen-post-block',
			LISTZEN_CORE_BASE_URL . 'assets/blocks/main.js',
			array( 'wp-api-fetch', 'wp-block-editor', 'wp-blocks', 'wp-components', 'wp-element', 'wp-i18n' ),
			time(),
			true
		);
		wp_enqueue_style(
			'listzen-block-editor',
			LISTZEN_CORE_BASE_URL . 'assets/blocks/main.css',
			null,
			time()
		);
	}

}