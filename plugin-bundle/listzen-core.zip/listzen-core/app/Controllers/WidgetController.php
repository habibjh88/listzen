<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Controllers;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use ListzenCore\Traits\SingletonTraits;
use ListzenCore\Widgets\About_Widget;
use ListzenCore\Widgets\Contact_Widget;
use ListzenCore\Widgets\Post_Widget;

class WidgetController {
	use SingletonTraits;

	public $widgets;

	public function __construct() {
		add_action( 'widgets_init', [ $this, 'custom_widgets' ] );
	}

	public function custom_widgets() {

		$widgets = [
			About_Widget::class,
			Contact_Widget::class,
			Post_Widget::class,
		];

		foreach ( $widgets as $class ) {
			register_widget( $class );
		}
	}
}