<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Widgets;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use ListzenCore\Generator\WidgetFieldsGenerator;
use Listzen\Helpers\Fns as ThemeFns;
use ListzenCore\Helper\Fns;
use \WP_Widget;

/**
 * Contact_Widget Class
 */
class Contact_Widget extends WP_Widget {

	/**
	 * Constructor
	 */
	public function __construct() {
		$id    = LISTZEN_CORE_PREFIX . '_contact';
		$title = __( 'Listzen: Contact', 'listzen-core' );
		$args  = [
			'description' => esc_html__( 'Displays Contact Info', 'listzen-core' ),
		];
		parent::__construct( $id, $title, $args );
	}


	/**
	 * Form
	 *
	 * @param $instance
	 *
	 * @return void
	 */
	public function form( $instance ) {
		$defaults = [
			'title'   => __( 'Contact', 'listzen-core' ),
			'address' => 'on',
			'mail'    => 'on',
			'phone'   => 'on',
			'website' => 'on',
			'show_social' => 'on',
		];

		$instance = wp_parse_args( (array) $instance, $defaults );

		$fields = [
			'title'   => [
				'label' => esc_html__( 'Title', 'listzen-core' ),
				'type'  => 'text',
			],
			'address' => [
				'label' => esc_html__( 'Show Address', 'listzen-core' ),
				'type'  => 'checkbox',
			],
			'mail'    => [
				'label' => esc_html__( 'Show Mail', 'listzen-core' ),
				'type'  => 'checkbox',
			],
			'phone'   => [
				'label' => esc_html__( 'Show Phone', 'listzen-core' ),
				'type'  => 'checkbox',
			],
			'website' => [
				'label' => esc_html__( 'Show Website', 'listzen-core' ),
				'type'  => 'checkbox',
			],
			'show_social' => [
				'label' => esc_html__( 'Show Social', 'listzen-core' ),
				'type'  => 'checkbox',
			],
		];

		WidgetFieldsGenerator::display( $fields, $instance, $this );
	}

	/**
	 * Update
	 *
	 * @param $new_instance
	 * @param $old_instance
	 *
	 * @return array
	 */
	public function update( $new_instance, $old_instance ) {

		$instance = $old_instance;

		$instance['title']   = ThemeFns::sanitize( $new_instance['title'] ?? '' );
		$instance['address'] = ThemeFns::sanitize( $new_instance['address'] ?? '' );
		$instance['mail']    = ThemeFns::sanitize( $new_instance['mail'] ?? '' );
		$instance['phone']   = ThemeFns::sanitize( $new_instance['phone'] ?? '' );
		$instance['website'] = ThemeFns::sanitize( $new_instance['website'] ?? '' );
		$instance['show_social'] = ThemeFns::sanitize( $new_instance['show_social'] ?? '' );

		return $instance;
	}

	/**
	 * Widget
	 *
	 * @param $args
	 * @param $instance
	 *
	 * @return void
	 */
	public function widget( $args, $instance ) {

		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . $instance['title'] . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		Fns::contact_render( [
			'address' => $instance['address'],
			'mail'    => $instance['mail'],
			'phone'   => $instance['phone'],
			'website' => $instance['website'],
		] );

		if ( ! empty( $instance['show_social'] ) ) {
			listzen_get_social_html();
		}
		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
