<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Widgets;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use ListzenCore\Generator\WidgetFieldsGenerator;
use ListzenCore\Helper\Fns;
use Listzen\Helpers\Fns as ThemeFns;
use \WP_Widget;


/**
 * Post Widget Class
 */
class Post_Widget extends WP_Widget {

	/**
	 * Class constructor
	 */
	public function __construct() {
		$id    = LISTZEN_CORE_PREFIX . '_blog_post';
		$title = __( 'Listzen: Blog Post', 'listzen-core' );
		$args  = [
			'description' => esc_html__( 'Displays Blog Post', 'listzen-core' ),
		];
		parent::__construct( $id, $title, $args );
	}

	/**
	 * Form
	 *
	 * @param $instance
	 *
	 * @return void
	 */
	public function form( $instance ) {
		$defaults = [
			'title'              => __( 'Latest Post', 'listzen-core' ),
			'layout'             => 'blog-list-style',
			'query_title'        => '',
			'posts_type'         => 'post',
			'posts_per_page'     => 5,
			'orderby'            => 'date',
			'order'              => 'DESC',
			'post_id'            => '',
			'meta_title'         => '',
			'category'           => 'category',
			'tag'                => '',
			'author'             => '',
			'date'               => '',
			'content_visibility' => 'first',
			'meta_style'         => 'default',
		];

		$instance = wp_parse_args( (array) $instance, $defaults );

		$fields = [
			'title'              => [
				'label' => esc_html__( 'Title', 'listzen-core' ),
				'type'  => 'text',
			],
			'layout'             => [
				'label'   => esc_html__( 'Layout Style', 'listzen-core' ),
				'type'    => 'select',
				'options' => [
					'blog-list-style'             => __( 'List', 'listzen-core' ),
					'blog-grid-style'             => __( 'Grid', 'listzen-core' ),
					'blog-big-first-style'        => __( '1st Big Other\'s list - 1', 'listzen-core' ),
					'blog-big-first-style style2' => __( '1st Big Other\'s list - 2', 'listzen-core' ),
				],
			],
			'query_title'        => [
				'label' => esc_html__( 'QUERY', 'listzen-core' ),
				'type'  => 'heading',
			],
			'posts_type'         => [
				'label'   => esc_html__( 'Post Type', 'listzen-core' ),
				'type'    => 'select',
				'options' => ThemeFns::get_post_types(),
			],
			'posts_per_page'     => [
				'label' => esc_html__( 'Posts Per Page', 'listzen-core' ),
				'type'  => 'number',
			],
			'orderby'            => [
				'label'   => esc_html__( 'Order by', 'listzen-core' ),
				'type'    => 'select',
				'options' => [
					'date'          => __( 'Date', 'listzen-core' ),
					'author'        => __( 'Author', 'listzen-core' ),
					'title'         => __( 'Title', 'listzen-core' ),
					'modified'      => __( 'Last modified date', 'listzen-core' ),
					'parent'        => __( 'Post parent ID', 'listzen-core' ),
					'comment_count' => __( 'Number of comments', 'listzen-core' ),
					'menu_order'    => __( 'Menu order', 'listzen-core' ),
					'rand'          => __( 'Random order', 'listzen-core' ),
					'popular'       => __( 'Popular Post', 'listzen-core' ),
				],
			],
			'order'              => [
				'label'   => esc_html__( 'Order', 'listzen-core' ),
				'type'    => 'select',
				'options' => [
					'ASC'  => __( 'ASC', 'listzen-core' ),
					'DESC' => __( 'DESC', 'listzen-core' ),
				],
			],
			'post_id'            => [
				'label' => esc_html__( 'Post by ID', 'listzen-core' ),
				'type'  => 'text',
				'desc'  => esc_html__( 'Enter post id by comma (,) separator.', 'listzen-core' ),
			],
			'meta_title'         => [
				'label' => esc_html__( 'Choose Meta', 'listzen-core' ),
				'type'  => 'heading',
			],
			'category'           => [
				'label' => esc_html__( 'Category', 'listzen-core' ),
				'type'  => 'checkbox',
			],
			'tag'                => [
				'label' => esc_html__( 'Tags', 'listzen-core' ),
				'type'  => 'checkbox',
			],
			'author'             => [
				'label' => esc_html__( 'Author', 'listzen-core' ),
				'type'  => 'checkbox',
			],
			'date'               => [
				'label' => esc_html__( 'Date', 'listzen-core' ),
				'type'  => 'checkbox',
			],
			'content_visibility' => [
				'label'   => esc_html__( 'Content Visibility', 'listzen-core' ),
				'type'    => 'select',
				'options' => [
					'first' => __( 'Only First Post', 'listzen-core' ),
					'all'   => __( 'All Posts', 'listzen-core' ),
					'hide'  => __( 'Hide for all', 'listzen-core' ),
				],
			],
			'meta_style'         => [
				'label'   => esc_html__( 'Meta Style', 'listzen-core' ),
				'type'    => 'select',
				'options' => ThemeFns::meta_style(),
			],
		];

		WidgetFieldsGenerator::display( $fields, $instance, $this );
	}

	/**
	 * Update
	 *
	 * @param $new_instance
	 * @param $old_instance
	 *
	 * @return array
	 */
	public function update( $new_instance, $old_instance ) {

		$instance = $old_instance;

		$instance['title']              = ThemeFns::sanitize( $new_instance['title'] ?? '', 'Latest Post' );
		$instance['layout']             = ThemeFns::sanitize( $new_instance['layout'] ?? '', 'blog-list-style' );
		$instance['query_title']        = ThemeFns::sanitize( $new_instance['query_title'] ?? '' );
		$instance['posts_type']         = ThemeFns::sanitize( $new_instance['posts_type'] ?? '', 'post' );
		$instance['posts_per_page']     = ThemeFns::sanitize( $new_instance['posts_per_page'] ?? '', '5' );
		$instance['orderby']            = ThemeFns::sanitize( $new_instance['orderby'] ?? '', 'date' );
		$instance['order']              = ThemeFns::sanitize( $new_instance['order'] ?? '', 'DESC' );
		$instance['post_id']            = ThemeFns::sanitize( $new_instance['post_id'] ?? '' );
		$instance['category']           = ThemeFns::sanitize( $new_instance['category'] ?? '', 'category' );
		$instance['tag']                = ThemeFns::sanitize( $new_instance['tag'] ?? '' );
		$instance['author']             = ThemeFns::sanitize( $new_instance['author'] ?? '' );
		$instance['date']               = ThemeFns::sanitize( $new_instance['date'] ?? '' );
		$instance['content_visibility'] = ThemeFns::sanitize( $new_instance['content_visibility'] ?? '', 'first' );
		$instance['meta_style']         = ThemeFns::sanitize( $new_instance['meta_style'] ?? '', 'default' );

		return $instance;
	}

	/**
	 * Widget
	 *
	 * @param $args
	 * @param $instance
	 *
	 * @return void
	 */
	public function widget( $args, $instance ) {

		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . $instance['title'] . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		$postArgs = [
			'post_type'           => $instance['posts_type'] ?? 'post',
			'ignore_sticky_posts' => 1,
			'posts_per_page'      => $instance['posts_per_page'] ?? 5,
			'post_status'         => 'publish',
		];

		if ( ! empty( $instance['orderby'] ) ) {
			$postArgs['orderby'] = $instance['orderby'];
		}

		if ( ! empty( $instance['order'] ) ) {
			$postArgs['order'] = $instance['order'];
		}

		if ( ! empty( $instance['post_id'] ) ) :
			$post_ids             = explode( ',', $instance['post_id'] );
			$postArgs['post__in'] = $post_ids;
		endif;

		$query = new \WP_Query( $postArgs );

		$meta_list  = [];
		$_meta_list = listzen_option( 'listzen_blog_meta', false, true );
		foreach ( $_meta_list as $meta ) {
			if ( ! empty( $instance[ $meta ] ) ) {
				$meta_list[] = $meta;
			}
		}

		$data       = [
			'content_visibility' => $instance['content_visibility'] ?? 'first',
			'meta_list'          => $meta_list,
			'meta_style'         => 'default' !== $instance['meta_style'] ? $instance['meta_style'] : '',
		];
		$layout     = $instance['layout'] ?? 'blog-list-style';
		$post_count = 1;
		if ( $query->have_posts() ) :
			echo "<div class='listzen-widdget-post " . esc_attr( $layout ) . "'>"; // phpcs:ignore Squiz.Strings.DoubleQuoteUsage.NotRequired
			while ( $query->have_posts() ) :
				$query->the_post();
				set_query_var( 'post_count', $post_count );
				Fns::get_template( 'widgets/latest-posts', $data );
				$post_count++;
			endwhile;
			echo "</div>"; // phpcs:ignore Squiz.Strings.DoubleQuoteUsage.NotRequired
			wp_reset_postdata();
		endif;

		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
