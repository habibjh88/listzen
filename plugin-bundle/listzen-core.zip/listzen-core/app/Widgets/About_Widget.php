<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace ListzenCore\Widgets;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
use Listzen\Options\Opt;
use ListzenCore\Generator\WidgetFieldsGenerator;
use Listzen\Helpers\Fns;
use \WP_Widget;

/**
 * About_Widget class
 */
class About_Widget extends WP_Widget {

	/**
	 * Class constructor
	 */
	public function __construct() {
		$id    = LISTZEN_CORE_PREFIX . '_about';
		$title = __( 'Listzen: About', 'listzen-core' );
		$args  = [
			'description' => __( 'Displays Contact Info', 'listzen-core' ),
		];
		parent::__construct( $id, $title, $args );
	}

	/**
	 * Widget
	 *
	 * @param $args
	 * @param $instance
	 *
	 * @return void
	 */
	public function widget( $args, $instance ) {
		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . $instance['title'] . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		if ( ! empty( $instance['show_logo'] ) ) { ?>
            <div class="about-logo">
				<?php
				if ( ! empty( $instance['logo'] ) ) {
					echo wp_get_attachment_image( $instance['logo'], 'full' );
				} else {
					$logo_type = 'main';
					if ( in_array( Opt::$footer_style, [ '2', '3' ] ) ) {
						$logo_type = 'light';
					}
					listzen_site_logo( $logo_type );
				}
				?>
            </div>
			<?php
		}

		if ( ! empty( $instance['description'] ) ) {
			$description = "<p class='description'>" . $instance['description'] . "</p>";
			listzen_html( $description );
		}
		$address = ! empty( $instance['show_website'] );
		$phone   = ! empty( $instance['show_phone'] );
		$email   = ! empty( $instance['show_email'] );

		listzen_contact_info( $address, $phone, $email );

		if ( ! empty( $instance['show_social'] ) ) {
			echo "<div class='about-social'>";
			listzen_get_social_html();
			echo "</div>";
		}
		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Update
	 *
	 * @param $new_instance
	 * @param $old_instance
	 *
	 * @return array
	 */
	public function update( $new_instance, $old_instance ) {
		$instance                 = [];
		$instance['title']        = ! empty( $new_instance['title'] ) ? sanitize_text_field( $new_instance['title'] ) : '';
		$instance['logo']         = ! empty( $new_instance['logo'] ) ? sanitize_text_field( $new_instance['logo'] ) : '';
		$instance['description']  = ! empty( $new_instance['description'] ) ? sanitize_textarea_field( $new_instance['description'] ) : '';
		$instance['show_social']  = ! empty( $new_instance['show_social'] ) ? sanitize_text_field( $new_instance['show_social'] ) : '';
		$instance['show_logo']    = ! empty( $new_instance['show_logo'] ) ? sanitize_text_field( $new_instance['show_logo'] ) : '';
		$instance['show_phone']   = ! empty( $new_instance['show_phone'] ) ? sanitize_text_field( $new_instance['show_phone'] ) : '';
		$instance['show_email']   = ! empty( $new_instance['show_email'] ) ? sanitize_text_field( $new_instance['show_email'] ) : '';
		$instance['show_address'] = ! empty( $new_instance['show_address'] ) ? sanitize_text_field( $new_instance['show_address'] ) : '';

		return $instance;
	}

	/**
	 * Form
	 *
	 * @param $instance
	 *
	 * @return void
	 */
	public function form( $instance ) {
		$defaults = [
			'title'       => '',
			'logo'        => '',
			'show_social' => 'on',
			'show_logo'   => 'on',
			'description' => 'Listzen, a tech giant founded in 2018, offering diverse Themes & Plugins,. It focuses on innovation and accessibility,',
		];
		$instance = wp_parse_args( (array) $instance, $defaults );

		$fields = [
			'title'        => [
				'label' => esc_html__( 'Title', 'listzen-core' ),
				'type'  => 'text',
			],
			'logo'         => [
				'label' => esc_html__( 'Logo', 'listzen-core' ),
				'type'  => 'image',
				'desc'  => esc_html__( 'Conditionally display the light or dark logo based on the chosen footer style; refrain from preselecting any logo. ', 'listzen-core' ),
			],
			'description'  => [
				'label' => esc_html__( 'Enter Description', 'listzen-core' ),
				'type'  => 'textarea',
			],
			'show_logo'    => [
				'label' => esc_html__( 'Show Site Logo', 'listzen-core' ),
				'type'  => 'checkbox',
			],
			'show_social'  => [
				'label' => esc_html__( 'Show Social Icon', 'listzen-core' ),
				'type'  => 'checkbox',
			],
			'show_phone'   => [
				'label' => esc_html__( 'Show Phone', 'listzen-core' ),
				'type'  => 'checkbox',
			],
			'show_email'   => [
				'label' => esc_html__( 'Show Email', 'listzen-core' ),
				'type'  => 'checkbox',
			],
			'show_address' => [
				'label' => esc_html__( 'Show Address', 'listzen-core' ),
				'type'  => 'checkbox',
			],

		];

		WidgetFieldsGenerator::display( $fields, $instance, $this );
	}
}
